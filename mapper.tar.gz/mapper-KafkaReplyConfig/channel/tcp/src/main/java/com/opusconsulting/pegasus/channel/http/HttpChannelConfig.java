package com.opusconsulting.pegasus.channel.http;

import io.vertx.core.http.HttpMethod;

public class HttpChannelConfig {
	int port;
	String hostName;
	String basePath;
	String url;
	HttpContentType contentType;
	String messageName;
	HttpMethod method;
	
	public int getPort() {
		return port;
	}
	public void setPort(int port) {
		this.port = port;
	}
	public String getHostName() {
		return hostName;
	}
	public void setHostName(String hostName) {
		this.hostName = hostName;
	}
	public String getBasePath() {
		return basePath;
	}
	public void setBasePath(String basePath) {
		this.basePath = basePath;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public HttpContentType getContentType() {
		return contentType;
	}
	public void setContentType(HttpContentType contentType) {
		this.contentType = contentType;
	}
	public String getMessageName() {
		return messageName;
	}
	public void setMessageName(String messageName) {
		this.messageName = messageName;
	}
	public HttpMethod getMethod() {
		return method;
	}
	public void setMethod(HttpMethod method) {
		this.method = method;
	}
	@Override
	public String toString() {
		return "HttpChannelConfig [port=" + port + ", hostName=" + hostName + ", basePath=" + basePath + ", url=" + url
				+ ", contentType=" + contentType + ", messageName=" + messageName + ", method=" + method + "]";
	}
}

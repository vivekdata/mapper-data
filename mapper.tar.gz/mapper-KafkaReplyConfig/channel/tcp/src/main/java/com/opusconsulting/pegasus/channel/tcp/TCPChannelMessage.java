package com.opusconsulting.pegasus.channel.tcp;

import com.opusconsulting.pegasus.common.channel.IChannelMessage;

import java.util.Map;

/**
 * Created by saran on 5/29/17.
 */
public class TCPChannelMessage implements IChannelMessage<byte[], Object> {
    byte[] data;
    Map<String, Object> props;
    Object protocolContext;

    public TCPChannelMessage(byte[] data, Map<String, Object> props, Object protocolContext) {
        this.data = data;
        this.props = props;
        this.protocolContext = protocolContext;
    }

    public Map<String, Object> getProps() {
        return props;
    }

    public void setProps(Map<String, Object> props) {
        this.props = props;
    }

    public byte[] getData() {
        return data;
    }

    public void setData(byte[] data) {
        this.data = data;
    }

    public Object getProtocolContext() {
        return protocolContext;
    }

    public void setProtocolContext(Object protocolContext) {
        this.protocolContext = protocolContext;
    }
}

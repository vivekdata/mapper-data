package com.opusconsulting.pegasus.channel.http;

import io.vertx.core.Vertx;

/**
 * This is the handler for server channel of HTTP method POST
 * 
 * @author 
 *
 */
public abstract class HttpPostChannel<K> extends HttpChannel<HttpChannelConfig> {

	public HttpPostChannel(Vertx vertx, HttpChannelConfig config) {
		super(vertx, config);
	}

	@Override
	public void setConfig(HttpChannelConfig config) {
		this.config = config;
	}
}

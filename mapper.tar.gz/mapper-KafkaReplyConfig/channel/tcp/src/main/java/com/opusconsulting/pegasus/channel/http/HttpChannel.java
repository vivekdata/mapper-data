package com.opusconsulting.pegasus.channel.http;

import com.opusconsulting.pegasus.common.channel.IChannel;
import com.opusconsulting.pegasus.common.channel.IChannelEvent;

import io.vertx.core.Vertx;

public abstract class HttpChannel<T> implements IChannel<T, HttpChannelMessage> {
	T config;
	private IChannelEvent<HttpChannelMessage> eventHandler;
	private Vertx vertx;
	
	public HttpChannel(Vertx vertx, T config) {
		super();
		this.config = config;
		this.vertx = vertx;
	}

	public T getConfig() {
		return config;
	}

	public IChannelEvent<HttpChannelMessage> getEventHandler() {
		return eventHandler;
	}

	@Override
	public void setEventHandler(IChannelEvent eventHandler) {
		this.eventHandler = eventHandler;
	}

	protected Vertx getVertx() {
		return vertx;
	}
	
	@Override
	public void setConfig(T config) {
		this.config = config;
	}
}

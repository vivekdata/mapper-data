package com.opusconsulting.pegasus.channel.http.handler;

import com.opusconsulting.pegasus.channel.http.HttpChannelMessage;
import com.opusconsulting.pegasus.common.channel.IChannelEvent;

import io.vertx.core.Handler;

public abstract class HttpChannelHandler<T> implements Handler<T> {
	public enum HttpMethodType{
		GET, POST, PUT, DELETE;
	}
	
	private IChannelEvent<HttpChannelMessage> eventHandler;
	public static final String REQUEST_PARAM_FIELD_KEY_IDENTIFIER = "request_param_";
	public static final String HTTP_MESSAGE_NAME_PROPS_KEY = "messageName";
	public static final String EVENT_CTX_REQUEST_PARAM ="requestParams";

	public HttpChannelHandler(IChannelEvent<HttpChannelMessage> eventHandler) {
		super();
		this.eventHandler = eventHandler;
	}

	public IChannelEvent<HttpChannelMessage> getEventHandler() {
		return eventHandler;
	}
}

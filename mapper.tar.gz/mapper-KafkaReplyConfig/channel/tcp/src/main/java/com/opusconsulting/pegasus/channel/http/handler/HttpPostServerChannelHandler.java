package com.opusconsulting.pegasus.channel.http.handler;

import com.opusconsulting.pegasus.channel.http.HttpChannelMessage;
import com.opusconsulting.pegasus.common.channel.IChannelEvent;

import io.vertx.core.buffer.Buffer;
import io.vertx.core.http.HttpServerRequest;
import io.vertx.core.logging.Logger;
import io.vertx.core.logging.LoggerFactory;
import io.vertx.ext.web.RoutingContext;

public class HttpPostServerChannelHandler extends HttpChannelHandler<RoutingContext> {
	private static final Logger _logger = LoggerFactory.getLogger(HttpGetServerChannelHandler.class);

	public HttpPostServerChannelHandler(IChannelEvent<HttpChannelMessage> eventHandler, String url) {
		super(eventHandler);
	}

	@Override
	public void handle(RoutingContext routingContext) {
		final HttpServerRequest request = routingContext.request();
		IChannelEvent eventHandler = getEventHandler();
		if (eventHandler != null) {
			// build the props for the Channel message
			Buffer data = routingContext.getBody();
			_logger.info(data.toString());
			HttpChannelMessage channelMessage = new HttpChannelMessage(data, null, routingContext);
			eventHandler.onEvent(HttpMethodType.POST.name(), channelMessage, null);
		} else {
			_logger.error("No event handler found configured for the channel. Cannot process the message.");
		}

	}

}

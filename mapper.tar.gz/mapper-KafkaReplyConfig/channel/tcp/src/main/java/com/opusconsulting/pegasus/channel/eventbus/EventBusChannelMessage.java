package com.opusconsulting.pegasus.channel.eventbus;

import java.util.Map;

import com.opusconsulting.pegasus.common.channel.IChannelMessage;

public class EventBusChannelMessage<K, L> implements IChannelMessage<K,L> {
	L data;
    Map<String, Object> props;
    K protocolContext;
    boolean publisher;
    
	public EventBusChannelMessage(L data, Map<String, Object> props, K protocolContext) {
		super();
		this.data = data;
		this.props = props;
		this.protocolContext = protocolContext;
	}

	@Override
	public Map<String, Object> getProps() {
		return props;
	}

	protected boolean isPublisher() {
		return publisher;
	}

	@Override
	public K getData() {
		return (K) data;
	}

	@Override
	public L getProtocolContext() {
		return (L) protocolContext;
	}

	protected void setData(L data) {
		this.data = data;
	}

	protected void setProtocolContext(K protocolContext) {
		this.protocolContext = protocolContext;
	}
	
}

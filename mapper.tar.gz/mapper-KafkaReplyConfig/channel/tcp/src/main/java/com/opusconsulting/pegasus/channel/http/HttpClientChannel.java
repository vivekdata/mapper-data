package com.opusconsulting.pegasus.channel.http;

import io.vertx.core.Handler;
import io.vertx.core.Vertx;

public abstract class HttpClientChannel<T, K> extends HttpChannel<T> implements Handler<K> {

	public HttpClientChannel(Vertx vertx, T config) {
		super(vertx, config);
	}

}

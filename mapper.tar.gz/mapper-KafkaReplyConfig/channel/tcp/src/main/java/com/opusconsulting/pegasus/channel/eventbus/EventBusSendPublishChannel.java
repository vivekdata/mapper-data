package com.opusconsulting.pegasus.channel.eventbus;

import java.util.concurrent.CompletableFuture;

import com.opusconsulting.pegasus.common.channel.IChannelContext;
import com.opusconsulting.pegasus.common.channel.IChannelEvent;

import io.vertx.core.AsyncResult;
import io.vertx.core.eventbus.Message;
import io.vertx.core.json.JsonObject;

@SuppressWarnings({"rawtypes", "unchecked"})
public class EventBusSendPublishChannel<T> extends AbstractEventBusChannel<EventBusConfig, AsyncResult<Message<T>>, T> {

	public EventBusSendPublishChannel(EventBusConfig config, IChannelEvent eventHandler) {
		super(config, eventHandler);
	}
	
	@Override
	public void handle(AsyncResult<Message<T>> message) {
		IChannelEvent eventHandler = getEventHandler();
        if (eventHandler != null && message.succeeded()) {
        	T data = message.result().body();
			EventBusChannelMessage<AsyncResult<Message<T>>, T> channelMessage = new EventBusChannelMessage<AsyncResult<Message<T>>, T>(
					data, null, message);
            eventHandler.onEvent("MSG", channelMessage, null);
        }
	}

	@Override
	public CompletableFuture<Boolean> send(EventBusChannelMessage message, IChannelContext ctx) throws Exception {
		CompletableFuture<Boolean> retVal = new CompletableFuture<>();
		if(getConfig().isPublisher()){
			getEventBus().publish(getConfig().getOutboundAddress(), message.getData());
		} else {
			getEventBus().send(getConfig().getOutboundAddress(), message.getData(), this);
		}
		return retVal;
	}

	

}

package com.opusconsulting.pegasus.channel.tcp;

import com.opusconsulting.pegasus.common.channel.IChannelContext;
import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelHandler;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.logging.LogLevel;
import io.netty.handler.logging.LoggingHandler;

import java.util.concurrent.CompletableFuture;

/**
 * Created by saran on 5/29/17.
 */
@ChannelHandler.Sharable
public class TCPServerChannel extends TCPChannel<TCPServerConfig> {
    TCPServerConfig serverConfig;

    public TCPServerChannel(TCPServerConfig serverConfig) {
        this.serverConfig = serverConfig;
    }

    public CompletableFuture<Boolean> start() throws Exception {
        return startServer();
    }

    private CompletableFuture<Boolean> startServer() throws InterruptedException {
        EventLoopGroup bossGroup = new NioEventLoopGroup();
        EventLoopGroup workerGroup = new NioEventLoopGroup();
        try {
            ServerBootstrap b = new ServerBootstrap();
            b.group(bossGroup, workerGroup)
                    .channel(NioServerSocketChannel.class)
                    .handler(new LoggingHandler(LogLevel.INFO))
                    .childHandler(new TCPServerInitializer(this));
            ChannelFuture bind = b.bind(serverConfig.getPort());

            CompletableFuture<Boolean> retVal = new CompletableFuture<>();
            bind.addListener(future -> {
                retVal.complete(true);
            });

            return retVal;
        } finally {
        }
    }

    public CompletableFuture<Boolean> stop() {
        return null;
    }

    public CompletableFuture<Boolean> send(TCPChannelMessage message, IChannelContext ctx) {
        return null;
    }
}

package com.opusconsulting.pegasus.channel.tcp;

/**
 * Created by saran on 5/29/17.
 */
public class TCPServerConfig {
    int port;
    String bindAddress;
    int bossThreadCount;
    int workerThreadCount;

    public int getPort() {
        return port;
    }

    public TCPServerConfig setPort(int port) {
        this.port = port;
        return this;
    }

    public String getBindAddress() {
        return bindAddress;
    }

    public TCPServerConfig setBindAddress(String bindAddress) {
        this.bindAddress = bindAddress;
        return this;
    }

    public int getBossThreadCount() {
        return bossThreadCount;
    }

    public TCPServerConfig setBossThreadCount(int bossThreadCount) {
        this.bossThreadCount = bossThreadCount;
        return this;
    }

    public int getWorkerThreadCount() {
        return workerThreadCount;
    }

    public TCPServerConfig setWorkerThreadCount(int workerThreadCount) {
        this.workerThreadCount = workerThreadCount;
        return this;
    }
}

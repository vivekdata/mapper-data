package com.opusconsulting.pegasus.channel.http.handler;

import com.opusconsulting.pegasus.channel.http.HttpChannelMessage;
import com.opusconsulting.pegasus.common.channel.IChannelEvent;

import io.vertx.core.Handler;
import io.vertx.core.http.HttpMethod;
import io.vertx.ext.web.RoutingContext;

public class HttpServerChannelHandlerFactory {

	public static Handler<RoutingContext> getInstance(HttpMethod method, String url,String messageName,
			IChannelEvent<HttpChannelMessage> eventHandler) {
		switch (method) {
		case GET:
			return new HttpGetServerChannelHandler(eventHandler, url, messageName);
		case POST:
			return new HttpPostServerChannelHandler(eventHandler, url);
		case DELETE:
			return new HttpDeleteServerChannelHandler(eventHandler, url, messageName);
		case PUT:
			return new HttpPutServerChannelHandler(eventHandler, url);		
		
		default:
			return null;
		}
	}

}

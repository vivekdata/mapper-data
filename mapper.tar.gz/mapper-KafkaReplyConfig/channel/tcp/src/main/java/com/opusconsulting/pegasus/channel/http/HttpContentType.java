package com.opusconsulting.pegasus.channel.http;

public enum HttpContentType {
	JSON("application/json"), XML("application/xml");
	String type;

	private HttpContentType(String type) {
		this.type = type;
	}

	public String getType() {
		return type;
	}
}

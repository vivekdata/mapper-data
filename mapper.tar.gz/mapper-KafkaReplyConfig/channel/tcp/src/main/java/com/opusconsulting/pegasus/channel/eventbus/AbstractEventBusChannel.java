package com.opusconsulting.pegasus.channel.eventbus;

import java.util.concurrent.CompletableFuture;

import com.opusconsulting.pegasus.common.channel.IChannel;
import com.opusconsulting.pegasus.common.channel.IChannelEvent;

import io.vertx.core.Handler;
import io.vertx.core.Vertx;
import io.vertx.core.eventbus.EventBus;
import io.vertx.ext.web.Router;
import io.vertx.ext.web.handler.sockjs.BridgeOptions;
import io.vertx.ext.web.handler.sockjs.PermittedOptions;
import io.vertx.ext.web.handler.sockjs.SockJSHandler;

/**
 * 
 * @author Anup.Warke
 *
 * @param <T> - Configuration object type
 * @param <K> - Protocol context type
 * @param <L> - Request-Response body type
 */
@SuppressWarnings({"rawtypes", "deprecation"})
public abstract class AbstractEventBusChannel<T extends EventBusConfig, K, L> implements Handler<K>,IChannel<T, EventBusChannelMessage<K, L>> {
	private static final String EVENTBUS_BASE_URL = "/eventbus/*";
	
	IChannelEvent eventHandler;
	EventBusConfig config;
	EventBus eventBus;
	
	public AbstractEventBusChannel(EventBusConfig config, IChannelEvent eventHandler){
		this.config = config;
		this.eventHandler = eventHandler;
	}

	private void init(EventBusConfig config) {
		Vertx vertx = Vertx.vertx();
		/* Create vertx web router. */
        final Router router = Router.router(vertx );
        /* Allow service to be exposed */
        final BridgeOptions options = new BridgeOptions()
                .addInboundPermitted(
                        new PermittedOptions().setAddress(config.getInboundAddress()))
                .addOutboundPermitted(
                        new PermittedOptions().setAddress(config.getOutboundAddress()));
        /* Configure bridge at this HTTP/WebSocket URI. */
        router.route(EVENTBUS_BASE_URL).handler(SockJSHandler.create(vertx).bridge(options));
        this.eventBus = vertx.eventBus();
        /* Install router into vertx. */
        vertx.createHttpServer()
                .requestHandler(router::accept)
                .listen(config.getPort());
	}

	public IChannelEvent getEventHandler() {
		return eventHandler;
	}
	
	protected EventBus getEventBus() {
		return eventBus;
	}

	@Override
	public void setConfig(T config) {
		this.config = config;
	}

	@Override
	public void setEventHandler(IChannelEvent eventHandler) {
		this.eventHandler = eventHandler;
	}

	@Override
	public CompletableFuture<Boolean> start() throws Exception {
		CompletableFuture<Boolean> retVal = new CompletableFuture<>();
		init(config);
		retVal.complete(true);
		return retVal;
	}

	@Override
	public CompletableFuture<Boolean> stop() throws Exception {
		CompletableFuture<Boolean> retVal = new CompletableFuture<>();
		retVal.complete(false);
		return retVal;
	}

	public EventBusConfig getConfig() {
		return config;
	}
	
}


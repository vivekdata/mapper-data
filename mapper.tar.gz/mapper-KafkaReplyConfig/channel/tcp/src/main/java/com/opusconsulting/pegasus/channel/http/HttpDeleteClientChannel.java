package com.opusconsulting.pegasus.channel.http;

import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import com.opusconsulting.pegasus.common.channel.IChannelContext;
import com.opusconsulting.pegasus.common.channel.IChannelEvent;

import io.vertx.core.Vertx;
import io.vertx.core.http.HttpClient;
import io.vertx.core.http.HttpClientOptions;
import io.vertx.core.http.HttpClientRequest;
import io.vertx.core.http.HttpClientResponse;
import io.vertx.core.logging.Logger;
import io.vertx.core.logging.LoggerFactory;

/**
 * 
 * @author Pranali.Pagariya
 *
 */
public class HttpDeleteClientChannel extends HttpClientChannel<HttpChannelConfig, HttpClientResponse> {
	private static final Logger _logger = LoggerFactory.getLogger(HttpDeleteClientChannel.class);
	private HttpClient client;
	private List<String> requestParams;
	
	public HttpDeleteClientChannel(Vertx vertx, HttpChannelConfig config) {
		super(vertx, config);
	}

	private boolean connect() {
		//analyze the URL and identify the request parameter names
		this.requestParams = HttpChannelUtility.identifyAndNoteRequestParams(getConfig().getUrl());
		this.client = getVertx().createHttpClient(buildClientOptions(config));
		return true;
	}
	
	private HttpClientOptions buildClientOptions(HttpChannelConfig config) {
		final HttpClientOptions clientOptions = new HttpClientOptions();
		clientOptions.setDefaultHost(config.getHostName());
		clientOptions.setDefaultPort(config.getPort());
		return clientOptions;
	}

	@Override
	public void handle(HttpClientResponse response) {
		if(response.statusCode() == 200){
			response.bodyHandler(buffer ->{
				IChannelEvent eventHandler = getEventHandler();
				if (eventHandler != null) {
					HttpChannelMessage channelMessage = new HttpChannelMessage(buffer, null, config);
			        eventHandler.onEvent("RESP_MSG", channelMessage, null);
		        }
			});
		} else {
			_logger.error("{} received from the third party. Status Message: {}", response.statusCode() , response.statusMessage());
			//TODO need to think about the failure http request
		}
	}

	@Override
	public CompletableFuture<Boolean> start() throws Exception {
		CompletableFuture<Boolean> result = new CompletableFuture<>();
		boolean status = connect();
		result.complete(status);
		return result;
	}

	@Override
	public CompletableFuture<Boolean> stop() throws Exception {
		final CompletableFuture<Boolean> future = new CompletableFuture<Boolean>();
		this.client.close();
		future.complete(true);
		return future;
	}

	@Override
	public CompletableFuture<Boolean> send(HttpChannelMessage message, IChannelContext ctx) throws Exception {
		final CompletableFuture<Boolean> future = new CompletableFuture<Boolean>();
		if(message == null){
			_logger.error("No message received to send. Please check the logs for any previous errors.");
			future.complete(false);
		} else {
			final Map<String, Object> props = message.getProps();
			String endPointUrl = getConfig().getUrl();
			//get the URL from the end-point			
			for (String param : getRequestParams()) {
				final StringBuilder builder = new StringBuilder();
				builder.append(":");
				builder.append(param);
				endPointUrl = endPointUrl.replace(builder.toString(), (props.get(param) == null ? "" : (String)props.get(param)));
			}
			final HttpClientRequest request = this.client.delete(endPointUrl, this);
			request.end();
			
			future.complete(true);
		}
		return future;
	}

	public List<String> getRequestParams() {
		return requestParams;
	}
}

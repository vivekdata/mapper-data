package com.opusconsulting.pegasus.channel.http;

import java.util.List;

import io.vertx.core.http.HttpMethod;

public class HttpServerChannelConfig {
	public class HttpUrlInfo {
		String url;
		String messageName;
		HttpMethod method;
		
		
		
		public HttpUrlInfo(String url, String messageName, String method) {
			super();
			this.url = url;
			this.messageName = messageName;
			this.method = HttpMethod.valueOf(method);
		}
		public String getUrl() {
			return url;
		}
		public String getMessageName() {
			return messageName;
		}
		public HttpMethod getMethod() {
			return method;
		}
		@Override
		public String toString() {
			return "HttpUrlInfo [url=" + url + ", messageName=" + messageName + ", method=" + method + "]";
		}
	}
	
	int port;
	String hostName;
	String basePath;
	List<HttpUrlInfo> urlInfos;
	HttpContentType contentType;
	
	public int getPort() {
		return port;
	}
	public void setPort(int port) {
		this.port = port;
	}
	public String getHostName() {
		return hostName;
	}
	public void setHostName(String hostName) {
		this.hostName = hostName;
	}
	public String getBasePath() {
		return basePath;
	}
	public void setBasePath(String basePath) {
		this.basePath = basePath;
	}
	public HttpContentType getContentType() {
		return contentType;
	}
	public void setContentType(HttpContentType contentType) {
		this.contentType = contentType;
	}
	public List<HttpUrlInfo> getUrlInfos() {
		return urlInfos;
	}
	public void setUrlInfos(List<HttpUrlInfo> urlInfos) {
		this.urlInfos = urlInfos;
	}
	@Override
	public String toString() {
		return "HttpServerChannelConfig [port=" + port + ", hostName=" + hostName + ", basePath=" + basePath
				+ ", urlInfos=" + urlInfos + ", contentType=" + contentType + "]";
	}
	
}

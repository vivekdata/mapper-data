package com.opusconsulting.pegasus.channel.tcp;

/**
 * Created by saran on 5/29/17.
 */
public class TCPClientConfig {
    String ipAddress;
    int port;
    String nodeName;

    public TCPClientConfig(String ipAddress, int port) {
        this.ipAddress = ipAddress;
        this.port = port;
    }
    
    
    public TCPClientConfig(String ipAddress, int port,String nodeName) {
        this.ipAddress = ipAddress;
        this.port = port;
        this.nodeName=nodeName;
    }

    public String getIpAddress() {
        return ipAddress;
    }

    public void setIpAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

	public String getNodeName() {
		return nodeName;
	}

	public void setNodeName(String nodeName) {
		this.nodeName = nodeName;
	}
    
    
}

package com.opusconsulting.pegasus.channel.eventbus;

public class EventBusConfig {
	int port;
	String hostName;
	String inboundAddress;
	String outboundAddress;
	boolean publisher;
	
	public int getPort() {
		return port;
	}
	public void setPort(int port) {
		this.port = port;
	}
	public String getHostName() {
		return hostName;
	}
	public void setHostName(String hostName) {
		this.hostName = hostName;
	}
	public String getInboundAddress() {
		return inboundAddress;
	}
	public void setInboundAddress(String inboundAddress) {
		this.inboundAddress = inboundAddress;
	}
	public String getOutboundAddress() {
		return outboundAddress;
	}
	public void setOutboundAddress(String outboundAddress) {
		this.outboundAddress = outboundAddress;
	}
	public boolean isPublisher() {
		return publisher;
	}
	public void setPublisher(boolean publisher) {
		this.publisher = publisher;
	}
}

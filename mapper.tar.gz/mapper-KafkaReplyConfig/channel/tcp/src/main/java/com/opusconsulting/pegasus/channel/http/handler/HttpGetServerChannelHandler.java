package com.opusconsulting.pegasus.channel.http.handler;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.opusconsulting.pegasus.channel.http.HttpChannelMessage;
import com.opusconsulting.pegasus.channel.http.HttpChannelUtility;
import com.opusconsulting.pegasus.common.channel.IChannelEvent;

import io.vertx.core.http.HttpServerRequest;
import io.vertx.core.logging.Logger;
import io.vertx.core.logging.LoggerFactory;
import io.vertx.ext.web.RoutingContext;

public class HttpGetServerChannelHandler extends HttpChannelHandler<RoutingContext> {
	private static final Logger _logger = LoggerFactory.getLogger(HttpGetServerChannelHandler.class);
	private List<String> requestParams;
	private String messageName;
	
	public HttpGetServerChannelHandler(IChannelEvent<HttpChannelMessage> eventHandler, final String url, final String messageName) {
		super(eventHandler);
		//analyze the URL and identify the request parameter names
		this.requestParams = HttpChannelUtility.identifyAndNoteRequestParams(url);
		this.messageName = messageName;
	}
	
	@Override
	public void handle(RoutingContext routingContext) {
		final HttpServerRequest request = routingContext.request();
		IChannelEvent eventHandler = getEventHandler();
		if (eventHandler != null) {
			//build the props for the Channel message
			final Map<String, Object> props = new HashMap<>();
			Map<String,Object> requestParams = new HashMap<String,Object>();
			getRequestParams().stream().forEach(param -> {
				requestParams.put(param, request.getParam(param));
			});
			
			props.put(EVENT_CTX_REQUEST_PARAM,requestParams);
			props.put(HTTP_MESSAGE_NAME_PROPS_KEY, messageName);
			
			HttpChannelMessage channelMessage = new HttpChannelMessage(null, props, routingContext);
	        eventHandler.onEvent(HttpMethodType.GET.name(), channelMessage, null);
        } else {
        	_logger.error("No event handler found configured for the channel. Cannot process the message.");
        }
	}

	public List<String> getRequestParams() {
		return requestParams;
	}
}

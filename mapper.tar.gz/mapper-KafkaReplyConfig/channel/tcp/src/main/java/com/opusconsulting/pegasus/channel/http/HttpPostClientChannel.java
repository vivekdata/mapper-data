package com.opusconsulting.pegasus.channel.http;


import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import com.opusconsulting.pegasus.channel.tcp.TCPServerChannel;
import com.opusconsulting.pegasus.common.channel.IChannelContext;
import com.opusconsulting.pegasus.common.channel.IChannelEvent;

import io.vertx.core.Vertx;
import io.vertx.core.buffer.Buffer;
import io.vertx.core.http.HttpClient;
import io.vertx.core.http.HttpClientOptions;
import io.vertx.core.http.HttpClientRequest;
import io.vertx.core.http.HttpClientResponse;
import io.vertx.core.logging.Logger;
import io.vertx.core.logging.LoggerFactory;

/**
 * 
 * @author 
 *
 */
public class HttpPostClientChannel extends HttpClientChannel<HttpChannelConfig, HttpClientResponse> {
	private static final Logger _logger = LoggerFactory.getLogger(HttpPostClientChannel.class);
	private HttpClient client;
	
	public HttpPostClientChannel(Vertx vertx, HttpChannelConfig config) {
		super(vertx, config);
	}

	private boolean connect() {
		this.client = getVertx().createHttpClient(buildClientOptions(config));
		return true;
	}
	
	private HttpClientOptions buildClientOptions(HttpChannelConfig config) {
		final HttpClientOptions clientOptions = new HttpClientOptions();
		clientOptions.setDefaultHost(config.getHostName());
		clientOptions.setDefaultPort(config.getPort());
		return clientOptions;
	}

	@Override
	public void handle(HttpClientResponse response) {
		if(response.statusCode() == 200){
			response.bodyHandler(buffer ->{
				IChannelEvent eventHandler = getEventHandler();
				if (eventHandler != null) {
					HttpChannelMessage channelMessage = new HttpChannelMessage(buffer, null, config);
			        eventHandler.onEvent("RESP_MSG", channelMessage, null);
		        }
			});
		} else {
			_logger.error("{} received from the third party. Status Message: {}", response.statusCode() , response.statusMessage());
			
		}
	}

	@Override
	public CompletableFuture<Boolean> start() throws Exception {
		CompletableFuture<Boolean> result = new CompletableFuture<>();
		boolean status = connect();
		result.complete(status);
		return result;
	}

	@Override
	public CompletableFuture<Boolean> stop() throws Exception {
		final CompletableFuture<Boolean> future = new CompletableFuture<Boolean>();
		this.client.close();
		future.complete(true);
		return future;
	}

	@Override
	public CompletableFuture<Boolean> send(HttpChannelMessage message, IChannelContext ctx) throws Exception {
		final CompletableFuture<Boolean> future = new CompletableFuture<Boolean>();
		if(message == null){
			_logger.error("No message received to send. Please check the logs for any previous errors.");
			future.complete(false);
		} else {
			final Buffer data= message.getData();
			//get the URL from the end-point
			final String endPointUrl = getConfig().getUrl();
			HttpClientRequest httpClientRequest= this.client.post(endPointUrl, this);
			httpClientRequest.setChunked(true);
			httpClientRequest.write(data);
			httpClientRequest.end();
			_logger.info("Request sending to client : " + message.getData().toString());
		}
		return future;
	}
}

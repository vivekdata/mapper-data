package com.opusconsulting.pegasus.channel.http;

import io.vertx.core.Vertx;

/**
 * This is the handler for server channel of HTTP method POST
 * 
 * @author 
 *
 */
public abstract class HttpPutChannel<K> extends HttpChannel<HttpChannelConfig> {

	public HttpPutChannel(Vertx vertx, HttpChannelConfig config) {
		super(vertx, config);
	}

	@Override
	public void setConfig(HttpChannelConfig config) {
		this.config = config;
	}
}

package com.opusconsulting.pegasus.channel.eventbus;

import java.util.concurrent.CompletableFuture;

import com.opusconsulting.pegasus.common.channel.IChannelContext;
import com.opusconsulting.pegasus.common.channel.IChannelEvent;

import io.vertx.core.eventbus.Message;

@SuppressWarnings({"rawtypes", "unchecked"})
public class EventBusConsumerChannel<T> extends AbstractEventBusChannel<EventBusConfig, Message<T>, T> {

	public EventBusConsumerChannel(EventBusConfig config, IChannelEvent eventHandler) {
		super(config, eventHandler);
	}
	
	@Override
	public CompletableFuture<Boolean> start() throws Exception {
		CompletableFuture<Boolean> result = super.start();
		getEventBus().consumer(getConfig().getInboundAddress(), this);
		return result;
	}

	@Override
	public void handle(Message<T> message) {
		IChannelEvent eventHandler = getEventHandler();
        if (eventHandler != null) {
        	T data = message.body();
            EventBusChannelMessage<Message<T>, T> channelMessage = new EventBusChannelMessage<>(data, null, message);
            eventHandler.onEvent("MSG", channelMessage, null);
        }
	}

	@Override
	public CompletableFuture<Boolean> send(EventBusChannelMessage message, IChannelContext ctx) throws Exception {
		throw new UnsupportedOperationException("This method is not supported for this channel");
	}

}

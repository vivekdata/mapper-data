package com.opusconsulting.pegasus.channel.http.handler;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.opusconsulting.pegasus.channel.http.HttpChannelMessage;
import com.opusconsulting.pegasus.channel.http.HttpChannelUtility;
import com.opusconsulting.pegasus.channel.http.handler.HttpChannelHandler.HttpMethodType;
import com.opusconsulting.pegasus.common.channel.IChannelEvent;

import io.vertx.core.buffer.Buffer;
import io.vertx.core.http.HttpMethod;
import io.vertx.core.http.HttpServerRequest;
import io.vertx.core.logging.Logger;
import io.vertx.core.logging.LoggerFactory;
import io.vertx.ext.web.RoutingContext;

public class HttpPutServerChannelHandler extends HttpChannelHandler<RoutingContext> {
	
	public HttpPutServerChannelHandler(IChannelEvent<HttpChannelMessage> eventHandler, final String url) {
		
		super(eventHandler);
		this.requestParams = HttpChannelUtility.identifyAndNoteRequestParams(url);
	}
	
	private static final Logger _logger = LoggerFactory.getLogger(HttpPutServerChannelHandler.class);
	private List<String> requestParams;
	
	
	@Override
	public void handle(RoutingContext routingContext) {
		// TODO Auto-generated method stub

		final HttpServerRequest request = routingContext.request();

		IChannelEvent eventHandler = getEventHandler();

		if (eventHandler != null) {
			// get the messsage body
			Buffer data = routingContext.getBody();

			// build the props for the Channel message
			final Map<String, Object> props = new HashMap<>();
			Map<String,Object> requestParams = new HashMap<String,Object>();
			getRequestParams().stream().forEach(param -> {
				requestParams.put(param, request.getParam(param));
			});
			
			props.put(EVENT_CTX_REQUEST_PARAM,requestParams);

			HttpChannelMessage channelMessage = new HttpChannelMessage(data, props, routingContext);
			eventHandler.onEvent(HttpMethodType.PUT.name(), channelMessage, null);

		} else {
			_logger.error("No event handler found configured for the channel. Cannot process the message.");
		}

	}
	
	public List<String> getRequestParams() {
		return requestParams;
	}

}

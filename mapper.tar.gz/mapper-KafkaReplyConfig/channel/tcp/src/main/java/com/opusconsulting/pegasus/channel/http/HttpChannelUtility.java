package com.opusconsulting.pegasus.channel.http;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class HttpChannelUtility {
	/**
	 * Analyze and identify the request param names from the URL of the endpoint
	 * 
	 * @param url
	 * @return
	 */
	public static List<String> identifyAndNoteRequestParams(String url) {
		final String requestParamUrlRegEx = "\\/\\:[a-zA-Z]*_?[0-9]*";
		final Pattern requestParamUrlRegExPattern = Pattern.compile(requestParamUrlRegEx, Pattern.MULTILINE);
		
		
		final List<String> requestParamNames = new ArrayList<>();
		final Matcher matcher = requestParamUrlRegExPattern.matcher(url);
		while (matcher.find()) {
		    final String requestParamMatchFromUrl = matcher.group(0);
			//skip the '/:' character
		    requestParamNames.add(requestParamMatchFromUrl.substring(2));
		}
		return requestParamNames;
	}
}
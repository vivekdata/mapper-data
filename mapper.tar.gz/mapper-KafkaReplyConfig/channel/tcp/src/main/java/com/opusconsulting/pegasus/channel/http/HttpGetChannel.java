package com.opusconsulting.pegasus.channel.http;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.opusconsulting.pegasus.common.channel.IChannelContext;

import io.vertx.core.Vertx;

/**
 * This is the handler for server channel of HTTP method GET
 * @author Anup.Warke
 *
 */
public abstract class HttpGetChannel<K> extends HttpChannel<HttpChannelConfig> {

	public HttpGetChannel(Vertx vertx, HttpChannelConfig config) {
		super(vertx, config);
	}
	
	@Override
	public void setConfig(HttpChannelConfig config) {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public CompletableFuture<Boolean> send(HttpChannelMessage message, IChannelContext ctx) throws Exception {
		CompletableFuture<Boolean> result = new CompletableFuture<>();
		result.complete(false);
		return result;
	}
}

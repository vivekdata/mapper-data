package com.opusconsulting.pegasus.channel.http;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import io.vertx.core.Vertx;
@Component
public class HttpClientChannelFactory {
	
	@Autowired
	private Vertx vertx;
	
	public HttpClientChannel<?, ?> getHttpClientChannel(HttpChannelConfig config) throws Exception{
		HttpClientChannel<?, ?> clientChannel = null;
		switch (config.getMethod()) {
		case GET:
			clientChannel = new HttpGetClientChannel(vertx, config);
			clientChannel.start();
			break;
		
		case POST:
			clientChannel = new HttpPostClientChannel(vertx, config);
			clientChannel.start();
			break;
			
		case DELETE:
			clientChannel = new HttpDeleteClientChannel(vertx, config);
			clientChannel.start();
			break;
			
		case PUT:
			clientChannel = new HttpPutClientChannel(vertx, config);
			clientChannel.start();
			break;
			
		default:
			break;
		}
		return clientChannel;
	}

	public Vertx getVertx() {
		return vertx;
	}

	public void setVertx(Vertx vertx) {
		this.vertx = vertx;
	}
}

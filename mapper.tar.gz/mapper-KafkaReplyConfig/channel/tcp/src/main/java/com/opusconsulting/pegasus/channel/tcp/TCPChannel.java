package com.opusconsulting.pegasus.channel.tcp;

import com.opusconsulting.pegasus.common.channel.IChannel;
import com.opusconsulting.pegasus.common.channel.IChannelEvent;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;

/**
 * Created by saran on 5/28/17.
 */
public abstract class TCPChannel<T> extends SimpleChannelInboundHandler<ByteBuf> implements IChannel<T, TCPChannelMessage> {
    T config;
    IChannelEvent eventHandler;

    public void setConfig(T config) {
        this.config = config;
    }

    public T getConfig() {
        return config;
    }

    public IChannelEvent getEventHandler() {
        return eventHandler;
    }

    public void setEventHandler(IChannelEvent eventHandler) {
        this.eventHandler = eventHandler;
    }

    protected void channelRead0(ChannelHandlerContext ctx, ByteBuf msg) throws Exception {
        IChannelEvent eventHandler = getEventHandler();
        if (eventHandler != null) {
            byte[] data = new byte[msg.readableBytes()];
            msg.readBytes(data);

            TCPChannelMessage channelMessage = new TCPChannelMessage(data, null, ctx);
            eventHandler.onEvent("MSG", channelMessage, null);
        }
    }

}

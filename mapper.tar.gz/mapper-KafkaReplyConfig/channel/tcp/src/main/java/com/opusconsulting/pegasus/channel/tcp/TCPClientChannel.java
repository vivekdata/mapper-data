package com.opusconsulting.pegasus.channel.tcp;

import java.util.concurrent.CompletableFuture;

import com.opusconsulting.pegasus.common.channel.IChannelContext;

import io.netty.bootstrap.Bootstrap;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelHandler;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioSocketChannel;

/**
 * Created by saran on 5/29/17.
 */
@ChannelHandler.Sharable
public class TCPClientChannel extends TCPChannel<TCPClientConfig> {
    
    io.netty.channel.Channel socketChannel;
    
    public TCPClientChannel(TCPClientConfig config) {
    	super();
        this.config = config;
    }
    
	public CompletableFuture<Boolean> start() throws Exception {
    	return startClient();
    }

    private CompletableFuture<Boolean> startClient() throws InterruptedException {
        EventLoopGroup group = new NioEventLoopGroup();
        try {
            Bootstrap b = new Bootstrap();
            b.group(group)
                    .channel(NioSocketChannel.class)
                    .handler(new TCPClientInitializer(this));

            ChannelFuture channelFuture = b.connect(config.getIpAddress(), config.getPort());

            CompletableFuture<Boolean> result = new CompletableFuture<>();
            channelFuture.addListener(future -> {
                socketChannel = channelFuture.channel();
                result.complete(true);
            });
            return result;
        } finally {
        }
    }

    public CompletableFuture<Boolean> stop() {
        return null;
    }

    @Override
    public CompletableFuture<Boolean> send(TCPChannelMessage message, IChannelContext ctx) throws Exception {
    	CompletableFuture<Boolean> result = new CompletableFuture<>();
    	if (socketChannel != null) {
            final ChannelFuture messageSentFuture = socketChannel.writeAndFlush(Unpooled.copiedBuffer(message.getData()));
            messageSentFuture.addListener(future -> {
            	if(future.get() != null){
            		result.complete(true);
            	}
            });
        } else {
        	result.complete(false);
        }
        return result;
    }
    
    public boolean isTCPClientChannelOpen() {
    	if(socketChannel!=null) {
    		return socketChannel.isOpen();
    	}
    	return false;
    }
}

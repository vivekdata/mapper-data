package com.opusconsulting.pegasus.channel.http;

import java.util.Map;

import com.opusconsulting.pegasus.common.channel.IChannelMessage;

import io.vertx.core.buffer.Buffer;

/**
 * Created by anup on 4/16/18.
 */
public class HttpChannelMessage implements IChannelMessage<Buffer, Object> {
    public static final String ENDPOINT_MESSAGE_NAME_PROP_KEY = "endPointMessageName";
	
	Buffer data;
    Map<String, Object> props;
    Object protocolContext;

    public HttpChannelMessage(Buffer data, Map<String, Object> props, Object protocolContext) {
        this.data = data;
        this.props = props;
        this.protocolContext = protocolContext;
    }

    public Map<String, Object> getProps() {
        return props;
    }

    public void setProps(Map<String, Object> props) {
        this.props = props;
    }

    public Buffer getData() {
        return data;
    }

    public void setData(Buffer data) {
        this.data = data;
    }

    public Object getProtocolContext() {
        return protocolContext;
    }

    public void setProtocolContext(Object protocolContext) {
        this.protocolContext = protocolContext;
    }
}

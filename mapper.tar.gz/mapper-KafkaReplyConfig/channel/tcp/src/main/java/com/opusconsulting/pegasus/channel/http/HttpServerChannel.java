package com.opusconsulting.pegasus.channel.http;

import java.util.concurrent.CompletableFuture;

import com.opusconsulting.pegasus.channel.http.handler.HttpServerChannelHandlerFactory;
import com.opusconsulting.pegasus.common.channel.IChannelContext;

import io.vertx.core.Vertx;
import io.vertx.core.http.HttpServer;
import io.vertx.core.http.HttpServerOptions;
import io.vertx.core.logging.Logger;
import io.vertx.core.logging.LoggerFactory;
import io.vertx.ext.web.Route;
import io.vertx.ext.web.Router;
import io.vertx.ext.web.handler.BodyHandler;

public class HttpServerChannel extends HttpChannel<HttpServerChannelConfig> {
	private static final Logger _logger = LoggerFactory.getLogger(HttpServerChannel.class);
	private HttpServer httpServer;
	
	public HttpServerChannel(Vertx vertx, HttpServerChannelConfig config) {
		super(vertx, config);
	}
	
	private boolean startServer() {
		Router httpRouter = registerRouters(getVertx());
		if(httpRouter != null){
			final HttpServerOptions serverOptions = buildServerOptions(getConfig());
			this.httpServer = getVertx().createHttpServer(serverOptions);
			httpServer.requestHandler(httpRouter::accept).listen();
			return true;	
		} else {
			_logger.error("No router registered for the APIs.");
			return false;
		}
	}
	
	private HttpServerOptions buildServerOptions(HttpServerChannelConfig config) {
		final HttpServerOptions options = new HttpServerOptions();
		options.setPort(config.getPort());
		return options;
	}

	private Router registerRouters(final Vertx vertx) {
		Router httpRouter = Router.router(vertx);
		if (getConfig() == null) {
			_logger.error(
					"No endpoints provided to bring up the HTTP API(s). Cannot strat the server. Please check with administrator.");
			return null;
		}
		getConfig().getUrlInfos().stream().forEach(urlInfo -> {
			Route httpRoute = httpRouter.route(urlInfo.getUrl()).handler(BodyHandler.create())
					.method(urlInfo.getMethod()).handler(HttpServerChannelHandlerFactory
							.getInstance(urlInfo.getMethod(), urlInfo.getUrl(), urlInfo.getMessageName() , getEventHandler()));
			if (getConfig().getContentType() != null) {
				httpRoute.consumes(getConfig().getContentType().getType());
			}
		});
		return httpRouter;
	}

	@Override
	public CompletableFuture<Boolean> start() throws Exception {
		CompletableFuture<Boolean> result = new CompletableFuture<>();
		boolean status = startServer();
		result.complete(status);
		return result;
	}

	@Override
	public CompletableFuture<Boolean> stop() throws Exception {
		final CompletableFuture<Boolean> future = new CompletableFuture<Boolean>();
		this.httpServer.close();
		future.complete(true);
		return future;
	}

	@Override
	public CompletableFuture<Boolean> send(HttpChannelMessage message, IChannelContext ctx) throws Exception {
		CompletableFuture<Boolean> result = new CompletableFuture<>();
		result.complete(false);
		return result;
	}

	

}

package com.opusconsulting.pegasus.channel.tcp;

import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.socket.SocketChannel;
import io.netty.handler.codec.LengthFieldBasedFrameDecoder;
import io.netty.handler.codec.LengthFieldPrepender;

/**
 * Created by saran on 5/29/17.
 */
public class TCPClientInitializer extends ChannelInitializer<SocketChannel> {
    TCPClientChannel clientChannel;

    public TCPClientInitializer(TCPClientChannel clientChannel) {
        this.clientChannel = clientChannel;
    }

    protected void initChannel(SocketChannel ch) throws Exception {
        ChannelPipeline pipeline = ch.pipeline();
        pipeline.addLast(new LengthFieldBasedFrameDecoder(Integer.MAX_VALUE, 0, 2, 0, 2));
        pipeline.addLast(new LengthFieldPrepender(2, 0, false));
        pipeline.addLast(clientChannel);
    }
}

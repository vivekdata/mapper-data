package com.opusconsulting.pegasus.channel.tcp;

import com.opusconsulting.pegasus.common.channel.IChannelEvent;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelHandlerContext;

/**
 * Created by saran on 5/29/17.
 */
public class ServerMain {
    public static void main(String[] args) throws Exception {
        TCPServerConfig config = new TCPServerConfig().setPort(9910);
        TCPServerChannel serverChannel = new TCPServerChannel(config);
        serverChannel.setEventHandler(new IChannelEvent<TCPChannelMessage>() {
            public void onEvent(String type, TCPChannelMessage message, Object additionalInfo) {
                String request = new String(message.getData());
                System.out.println("Message received : " + request);

                ChannelHandlerContext ctx = (ChannelHandlerContext) message.getProtocolContext();
                ByteBuf response = Unpooled.buffer(1024);
                response.writeBytes(("Resp " + request).getBytes());
                ctx.channel().writeAndFlush(response);
            }
        });

        serverChannel.start();
    }
}

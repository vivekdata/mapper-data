package com.opusconsulting.pegasus.channel.tcp;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Future;

/**
 * Created by saran on 5/29/17.
 */
public class ClientMain {
    public static void main(String[] args) throws Exception {
        TCPClientConfig config = new TCPClientConfig("localhost", 9910);
        TCPClientChannel clientChannel = new TCPClientChannel(config);
        Future<Boolean> start = clientChannel.start();
        start.get();

//        ByteBuf buffer = Unpooled.buffer(1024);
//        buffer.writeCharSequence("Hello", Charset.defaultCharset());
        clientChannel.send(new TCPChannelMessage("Hello".getBytes(), null, null), null);
    }
}

package com.opusconsulting.pegasus.formula;

import com.google.inject.Guice;
import com.google.inject.Inject;
import com.google.inject.Injector;
import com.opusconsulting.spartan.formula.ExcelRuntimeModule;
import com.opusconsulting.spartan.formula.ExcelStandaloneSetup;
import org.eclipse.xtext.parser.IParseResult;
import org.eclipse.xtext.parser.IParser;

import java.io.StringReader;

public class Main {

    @Inject
    private IParser parser;

    protected Injector injector;

    public Injector getInjector() {
        if (injector == null) {
            this.injector = internalCreateInjector();
        }
        return injector;
    }

    protected Injector internalCreateInjector() {
        return new ExcelStandaloneSetup() {
            @Override
            public Injector createInjector() {
                return Guice.createInjector(new ExcelRuntimeModule());
            }
        }.createInjectorAndDoEMFRegistration();
    }

    public IParseResult parse(String code) {
        return parser.parse(new StringReader(code));
    }

    public static void main(String[] args) {
        Main main = new Main();

        long startTime = System.currentTimeMillis();
        Injector injector = main.getInjector();
        System.out.println("Inject time : " + (System.currentTimeMillis() - startTime));

        startTime = System.currentTimeMillis();
        injector.injectMembers(main);
        System.out.println("Inject member : " + (System.currentTimeMillis() - startTime));

        startTime = System.currentTimeMillis();
        IParseResult parse = main.parse("STR(v1.v2, v1.v3, \"Test\")");
        System.out.println("Parse time : " + (System.currentTimeMillis() - startTime));

        startTime = System.currentTimeMillis();
        parse = main.parse("STR(CONCAT(v1.v2, v1.v3), \"Test\")");
        System.out.println("Parse time : " + (System.currentTimeMillis() - startTime));

        System.out.println(parse.hasSyntaxErrors());
    }

}

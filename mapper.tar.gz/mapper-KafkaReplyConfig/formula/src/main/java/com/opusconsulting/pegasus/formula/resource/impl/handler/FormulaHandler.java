package com.opusconsulting.pegasus.formula.resource.impl.handler;

import com.opusconsulting.pegasus.common.resource.ResourceHandler;
import com.opusconsulting.pegasus.common.resource.ResourceInfo;
import com.opusconsulting.pegasus.formula.codegen.CodeMetaData;
import com.opusconsulting.pegasus.formula.codegen.FormulaCodeInfo;
import com.opusconsulting.pegasus.formula.codegen.ICodeProvider;
import com.opusconsulting.pegasus.formula.codegen.impl.FormulaCodeGenerator;
import com.opusconsulting.pegasus.formula.compiler.JavaCodeCompiler;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.util.HashMap;
import java.util.Map;

@Component
public class FormulaHandler<T> implements ResourceHandler<T> {
    public static String RESOURCE_TYPE = "formula";

    @Inject
    FormulaCodeGenerator codeGenerator;

    @Inject
    JavaCodeCompiler codeCompiler;

    Map<String, CodeMetaData> codeMetaDatas = new HashMap<>();
    Map<String, ICodeProvider> codeProviders = new HashMap<>();

    public void register(String type, CodeMetaData codeMetaData, ICodeProvider codeProvider) {
        codeMetaDatas.put(type, codeMetaData);
        codeProviders.put(type, codeProvider);
    }

    @Override
    public <T> T getResource(ResourceInfo lrInfo) throws Exception {
        String data = lrInfo.getData();
        int matchIndex = data.indexOf("/");

        if (matchIndex == -1) {
            throw new Exception("Invalid formula resource : " + data);
        }

        String type = data.substring(0, matchIndex);
        String expression = data.substring(matchIndex + 1);
        CodeMetaData codeMetaData = codeMetaDatas.get(type);
        ICodeProvider codeProvider = codeProviders.get(type);

        FormulaCodeInfo formulaCodeInfo = codeGenerator.create(expression, codeMetaData, codeProvider);
        return (T) formulaCodeInfo;
    }

    @Override
    public T getRunnable(ResourceInfo baseResourceInfo) throws Exception {
        FormulaCodeInfo resource = getResource(baseResourceInfo);
        Class<?> clzz = codeCompiler.compile(resource.getClassName(), resource.getCode());
        return (T) clzz.newInstance();
    }
}

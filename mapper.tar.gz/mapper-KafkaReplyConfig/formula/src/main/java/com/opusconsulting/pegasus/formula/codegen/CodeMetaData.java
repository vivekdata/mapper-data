package com.opusconsulting.pegasus.formula.codegen;

import java.util.ArrayList;
import java.util.List;

public class CodeMetaData {
    String packageName;
    List<String> imports = new ArrayList<>();
    List<String> implementClasses = new ArrayList<>();
    String extendClass;
    String className;

    FunctionMetaData callFunctionMetaData;
    List<String> embeddedCodeBlock;

    public String getPackageName() {
        return packageName;
    }

    public void setPackageName(String packageName) {
        this.packageName = packageName;
    }

    public List<String> getImports() {
        return imports;
    }

    public void addImport(String importString) {
        this.imports.add(importString);
    }

    public List<String> getImplementClasses() {
        return implementClasses;
    }

    public void setImplementClasses(List<String> implementClasses) {
        this.implementClasses = implementClasses;
    }

    public String getExtendClass() {
        return extendClass;
    }

    public void setExtendClass(String extendClass) {
        this.extendClass = extendClass;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public FunctionMetaData getCallFunctionMetaData() {
        return callFunctionMetaData;
    }

    public void setCallFunctionMetaData(FunctionMetaData callFunctionMetaData) {
        this.callFunctionMetaData = callFunctionMetaData;
    }

    public List<String> getEmbeddedCodeBlock() {
        return embeddedCodeBlock;
    }

    public void setEmbeddedCodeBlock(List<String> embeddedCodeBlock) {
        this.embeddedCodeBlock = embeddedCodeBlock;
    }
}
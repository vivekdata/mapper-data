package com.opusconsulting.pegasus.formula.codegen;

import java.util.ArrayList;
import java.util.List;

public class FunctionMetaData {
    String name;
    String returnType;
    List<ParamMetaData> params = new ArrayList<>();

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getReturnType() {
        return returnType;
    }

    public void setReturnType(String returnType) {
        this.returnType = returnType;
    }

    public List<ParamMetaData> getParams() {
        return params;
    }

    public void setParams(List<ParamMetaData> params) {
        this.params = params;
    }
}
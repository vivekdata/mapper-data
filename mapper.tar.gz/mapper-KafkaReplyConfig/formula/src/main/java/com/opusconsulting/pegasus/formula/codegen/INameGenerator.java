package com.opusconsulting.pegasus.formula.codegen;

public interface INameGenerator {
    String getNewName();
}
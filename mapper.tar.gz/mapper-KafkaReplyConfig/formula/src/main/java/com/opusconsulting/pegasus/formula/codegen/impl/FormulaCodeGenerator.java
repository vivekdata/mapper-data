package com.opusconsulting.pegasus.formula.codegen.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.inject.Inject;

import org.apache.commons.lang.StringUtils;
import org.eclipse.emf.common.util.EList;
import org.eclipse.xtext.parser.IParseResult;
import org.springframework.stereotype.Component;

import com.opusconsulting.pegasus.formula.codegen.CodeMetaData;
import com.opusconsulting.pegasus.formula.codegen.FormulaCodeInfo;
import com.opusconsulting.pegasus.formula.codegen.FunctionMetaData;
import com.opusconsulting.pegasus.formula.codegen.GetterCode;
import com.opusconsulting.pegasus.formula.codegen.ICodeProvider;
import com.opusconsulting.pegasus.formula.codegen.INameGenerator;
import com.opusconsulting.pegasus.formula.parser.FormulaParser;
import com.opusconsulting.pegasus.formula.parser.ParseException;
import com.opusconsulting.pegasus.formula.velocity.VelocityCodeGenInfo;
import com.opusconsulting.pegasus.formula.velocity.VelocityFunctionMetaData;
import com.opusconsulting.pegasus.formula.velocity.VelocityUtil;
import com.opusconsulting.spartan.formula.excel.Constant;
import com.opusconsulting.spartan.formula.excel.ConstantValue;
import com.opusconsulting.spartan.formula.excel.Expression;
import com.opusconsulting.spartan.formula.excel.ExpressionType;
import com.opusconsulting.spartan.formula.excel.Function;
import com.opusconsulting.spartan.formula.excel.Model;
import com.opusconsulting.spartan.formula.excel.NumberConstant;
import com.opusconsulting.spartan.formula.excel.StringConstant;
import com.opusconsulting.spartan.formula.excel.Variable;

@Component
public class FormulaCodeGenerator {

    private final static String FILENAME = "template/excel.vm";

    @Inject
    FormulaParser parser;

    @Inject
    VelocityUtil velocityUtil;

    @Inject
    INameGenerator nameGenerator;

    public FormulaCodeInfo create(String formula, CodeMetaData codeMetaData, ICodeProvider provider) throws Exception {
        VelocityCodeGenInfo velocityCodeGenInfo = new VelocityCodeGenInfo();
        velocityCodeGenInfo.setPackageName(codeMetaData.getPackageName());

        String className = codeMetaData.getClassName();
        className = StringUtils.isEmpty(className) ? nameGenerator.getNewName() : className;
        velocityCodeGenInfo.setClassName(className);

        codeMetaData.getImplementClasses().forEach(velocityCodeGenInfo::addImplementClass);
        codeMetaData.getImports().forEach(velocityCodeGenInfo::addImport);
        velocityCodeGenInfo.setExtendClass(codeMetaData.getExtendClass());

        FunctionMetaData callFunctionMetaData = codeMetaData.getCallFunctionMetaData();
        velocityCodeGenInfo.setCallFunctionMetaData(new VelocityFunctionMetaData(callFunctionMetaData.getName(), "T".equals(callFunctionMetaData.getReturnType()) ? "<T> T" : callFunctionMetaData.getReturnType(),
                callFunctionMetaData.getParams().stream().map((param) -> param.type + " " + param.name).collect(Collectors.toList()),
                callFunctionMetaData.getParams().stream().map((param) -> param.name).collect(Collectors.toList())));

        IParseResult parseResult = parser.parse(formula);
        if (parseResult.hasSyntaxErrors()) {
            throw new ParseException(parseResult.getSyntaxErrors());
        }

        Model model = (Model) parseResult.getRootASTElement();

        Expression expression = model.getExpression();
        String expressionCode = processExpression(expression, velocityCodeGenInfo, provider);
        velocityCodeGenInfo.setExpressionCode("return " + ("T".equals(callFunctionMetaData.getReturnType()) ? "(T) " : "") + expressionCode + ";");

        Map<String, Object> variables = new HashMap<>();
        variables.put("_", velocityCodeGenInfo);
        String code = velocityUtil.execute(FILENAME, variables);

        String qualifiedClassName = StringUtils.isEmpty(codeMetaData.getPackageName()) ? className : codeMetaData.getPackageName() + "." + className;

        return new FormulaCodeInfo(qualifiedClassName, code, codeMetaData);
    }

    private String processExpression(Expression expression, VelocityCodeGenInfo velocityCodeGenInfo, ICodeProvider provider)
            throws RuntimeException {
        return processExpressionType(expression.getType(), velocityCodeGenInfo, provider);
    }

    private String processExpressionType(ExpressionType type, VelocityCodeGenInfo velocityCodeGenInfo, ICodeProvider provider) throws RuntimeException {
        if (type instanceof Function) {
            return processFunction((Function) type, velocityCodeGenInfo, provider);
        } else if (type instanceof Variable) {
            return processVariable((Variable) type, velocityCodeGenInfo, provider);
        } else if (type instanceof Constant) {
            return processConstant((Constant) type, velocityCodeGenInfo, provider);
        } else {
            throw new RuntimeException("Invalid expression type ... " + type.getClass());
        }
    }

    private String processConstant(Constant type, VelocityCodeGenInfo velocityCodeGenInfo, ICodeProvider provider) throws RuntimeException {
        ConstantValue value = type.getValue();
        if (value instanceof StringConstant) {
            return processStringConstant((StringConstant) value, velocityCodeGenInfo);
        } else if (value instanceof NumberConstant) {
            return processNumberConstant((NumberConstant) value, velocityCodeGenInfo);
        } else {
            throw new RuntimeException("Invalid Constant type ... " + type.getClass());
        }
    }

    private String processNumberConstant(NumberConstant value, VelocityCodeGenInfo velocityCodeGenInfo) {
        String newName = nameGenerator.getNewName().toUpperCase();
        if (value.getFraction() > 0) {
            velocityCodeGenInfo.addConstantCode(getConstantCode("float", newName, value.getInteger() + "." + value.getFraction(), false));
        } else {
            velocityCodeGenInfo.addConstantCode(getConstantCode("int", newName, String.valueOf(value.getInteger()), false));
        }
        return newName;
    }

    private String processStringConstant(StringConstant value, VelocityCodeGenInfo velocityCodeGenInfo) {
        String newName = nameGenerator.getNewName().toUpperCase();
        velocityCodeGenInfo.addConstantCode(getConstantCode("String", newName, value.getValue(), true));
        return newName;
    }

    private String getConstantCode(String type, String key, String value, boolean withQuote) {
        return "private final static " + type + " " + key + " = " +
                ((withQuote) ? "\"" : "") +
                value +
                ((withQuote) ? "\"" : "") + ";";
    }

    private String processVariable(Variable type, VelocityCodeGenInfo velocityCodeGenInfo, ICodeProvider provider) {
        GetterCode getterCode = provider.getGetterCode(type.getIds().toArray(new String[]{}));
        return getterCode.getCode();
    }

    private String processFunction(Function type, VelocityCodeGenInfo velocityCodeGenInfo, ICodeProvider provider) throws RuntimeException {
        if (type.getName().equals("IF") == true) {
            return processIFFunction(type, velocityCodeGenInfo, provider);
        } else if(type.getName().equals("AND")){
        	return processANDFunction(type, velocityCodeGenInfo, provider);
        }else if (type.getName().equals("OR")) {
			return processORFunction(type,velocityCodeGenInfo,provider);
		} else if(type.getName().equalsIgnoreCase("CONTEXT")){
			return processCONTEXTFunction(type, velocityCodeGenInfo, provider);
		} else if(type.getName().equalsIgnoreCase("FIND_XPATH_VALUE")){
			return processFIND_XPATH_VALUEFunction(type, velocityCodeGenInfo, provider);
		}

        String code = type.getName();
        List<String> paramCodes = type.getParams().stream().map((param) -> processExpression(param, velocityCodeGenInfo, provider)).collect(Collectors.toList());
        return code + "(" + String.join(", ", paramCodes) + ")";
    }
    
    private String processFIND_XPATH_VALUEFunction(Function type, VelocityCodeGenInfo velocityCodeGenInfo,
			ICodeProvider provider) {
    	velocityCodeGenInfo.setXpathReaderRequired(true);
    	velocityCodeGenInfo.setLambdaSupported(true);
    	
    	EList<Expression> params = type.getParams();
        if (params.size() != 1) {
            throw new RuntimeException("FIND_XPATH_VALUE should have 1 parameter instead it has " + params.size());
        }
        List<String> baseFunctionParamsWithType = velocityCodeGenInfo.getCallFunctionMetaData().getParamsWithType();
        List<String> baseFunctionParams = velocityCodeGenInfo.getCallFunctionMetaData().getParams();
        
        final StringBuilder andExpresssionBuilder = new StringBuilder("FIND_XPATH_VALUE(");
        andExpresssionBuilder.append(baseFunctionParams.stream().map((paramWithType) -> paramWithType).collect(Collectors.joining(",")));
        andExpresssionBuilder.append(",");
        andExpresssionBuilder.append(
        	params.stream().map((expression) -> {
	        	final StringBuilder andIndividualExpresssionBuilder = new StringBuilder();
	        	String conditionFn = nameGenerator.getNewName();
	        	andIndividualExpresssionBuilder.append("this::");
	        	andIndividualExpresssionBuilder.append(conditionFn);
	            
	        	VelocityFunctionMetaData conditionMetaData = new VelocityFunctionMetaData(conditionFn, "String", baseFunctionParamsWithType,
	                    baseFunctionParams,
	                    "return (" + processExpression(expression, velocityCodeGenInfo, provider) + ");");
	            velocityCodeGenInfo.addSupportFunction(conditionMetaData);
	            
	            return andIndividualExpresssionBuilder.toString();
	        }).collect(Collectors.joining(",")));
        
        
        andExpresssionBuilder.append(")");
        return andExpresssionBuilder.toString();
	}

	private String processANDFunction(Function type, VelocityCodeGenInfo velocityCodeGenInfo, ICodeProvider provider) throws RuntimeException {
    	velocityCodeGenInfo.setLambdaSupported(true);
        velocityCodeGenInfo.setFunctionName(type.getName());
        velocityCodeGenInfo.setLogicalOperationRequired(true);
        
        EList<Expression> params = type.getParams();
        if (params.size() < 2) {
            throw new RuntimeException("AND should have atleast 2 parameters instead it has " + params.size());
        }

        List<String> baseFunctionParamsWithType = velocityCodeGenInfo.getCallFunctionMetaData().getParamsWithType();
        List<String> baseFunctionParams = velocityCodeGenInfo.getCallFunctionMetaData().getParams();
        
        final StringBuilder andExpresssionBuilder = new StringBuilder("AND(");
        andExpresssionBuilder.append(baseFunctionParams.stream().map((paramWithType) -> paramWithType).collect(Collectors.joining(",")));
        andExpresssionBuilder.append(",");
        andExpresssionBuilder.append(
        	params.stream().map((expression) -> {
	        	final StringBuilder andIndividualExpresssionBuilder = new StringBuilder();
	        	String conditionFn = nameGenerator.getNewName();
	        	andIndividualExpresssionBuilder.append("this::");
	        	andIndividualExpresssionBuilder.append(conditionFn);
	            
	        	VelocityFunctionMetaData conditionMetaData = new VelocityFunctionMetaData(conditionFn, "boolean", baseFunctionParamsWithType,
	                    baseFunctionParams,
	                    "return (" + processExpression(expression, velocityCodeGenInfo, provider) + ");");
	            velocityCodeGenInfo.addSupportFunction(conditionMetaData);
	            
	            return andIndividualExpresssionBuilder.toString();
	        }).collect(Collectors.joining(",")));
        
        
        andExpresssionBuilder.append(")");
        return andExpresssionBuilder.toString();
    }

    private String processIFFunction(Function type, VelocityCodeGenInfo velocityCodeGenInfo, ICodeProvider provider) throws RuntimeException {
        velocityCodeGenInfo.setLambdaSupported(true);
        velocityCodeGenInfo.setIfSupportedRequired(true);
        
        EList<Expression> params = type.getParams();
        if (params.size() != 3) {
            throw new RuntimeException("IF should have 3 parameters instead it has " + params.size());
        }

        List<String> baseFunctionParamsWithType = velocityCodeGenInfo.getCallFunctionMetaData().getParamsWithType();
        List<String> baseFunctionParams = velocityCodeGenInfo.getCallFunctionMetaData().getParams();

        String conditionFn = nameGenerator.getNewName();
        VelocityFunctionMetaData conditionMetaData = new VelocityFunctionMetaData(conditionFn, "boolean", baseFunctionParamsWithType,
                baseFunctionParams,
                "return (" + processExpression(params.get(0), velocityCodeGenInfo, provider) + ");");
        velocityCodeGenInfo.addSupportFunction(conditionMetaData);

        String trueFn = nameGenerator.getNewName();
        VelocityFunctionMetaData trueMetaData = new VelocityFunctionMetaData(trueFn, "<T> T", baseFunctionParamsWithType,
                baseFunctionParams,
                "return (T)(" + processExpression(params.get(1), velocityCodeGenInfo, provider) + ");");
        velocityCodeGenInfo.addSupportFunction(trueMetaData);

        String falseFn = nameGenerator.getNewName();
        VelocityFunctionMetaData falseMetaData = new VelocityFunctionMetaData(falseFn, "<T> T", baseFunctionParamsWithType,
                baseFunctionParams,
                "return (T)(" + processExpression(params.get(2), velocityCodeGenInfo, provider) + ");");
        velocityCodeGenInfo.addSupportFunction(falseMetaData);
        
		return "IF(this::" + conditionFn + ", this::" + trueFn + ", this::" + falseFn + ","
				+ baseFunctionParams.stream().map((paramWithType) -> paramWithType).collect(Collectors.joining(","))
				+ ")";
    }
    
    private String processORFunction(Function type, VelocityCodeGenInfo velocityCodeGenInfo, ICodeProvider provider) {
    	velocityCodeGenInfo.setLambdaSupported(true);
        velocityCodeGenInfo.setFunctionName(type.getName());
        velocityCodeGenInfo.setLogicalOperationRequired(true);
        
        EList<Expression> params = type.getParams();
        if (params.size() < 2) {
            throw new RuntimeException("OR should have atleast 2 parameters instead it has " + params.size());
        }
        List<String> baseFunctionParamsWithType = velocityCodeGenInfo.getCallFunctionMetaData().getParamsWithType();
        List<String> baseFunctionParams = velocityCodeGenInfo.getCallFunctionMetaData().getParams();
        
        final StringBuilder orExpresssionBuilder = new StringBuilder("OR(");
        orExpresssionBuilder.append(baseFunctionParams.stream().map((paramWithType) -> paramWithType).collect(Collectors.joining(",")));
        orExpresssionBuilder.append(",");
        orExpresssionBuilder.append(
        	params.stream().map((expression) -> {
	        	final StringBuilder orIndividualExpresssionBuilder = new StringBuilder();
	        	String conditionFn = nameGenerator.getNewName();
	        	orIndividualExpresssionBuilder.append("this::");
	        	orIndividualExpresssionBuilder.append(conditionFn);
	            
	        	VelocityFunctionMetaData conditionMetaData = new VelocityFunctionMetaData(conditionFn, "boolean", baseFunctionParamsWithType,
	                    baseFunctionParams,
	                    "return (" + processExpression(expression, velocityCodeGenInfo, provider) + ");");
	            velocityCodeGenInfo.addSupportFunction(conditionMetaData);
	            
	            return orIndividualExpresssionBuilder.toString();
	        }).collect(Collectors.joining(",")));
        
        orExpresssionBuilder.append(")");
        return orExpresssionBuilder.toString();
	}

    private String processCONTEXTFunction(Function type, VelocityCodeGenInfo velocityCodeGenInfo, ICodeProvider provider) {
    	velocityCodeGenInfo.setLambdaSupported(true);
    	velocityCodeGenInfo.setContextFunction(true);
    	velocityCodeGenInfo.addImport("com.opusconsulting.pegasus.runtime.IConstants");
        
        EList<Expression> params = type.getParams();
        if (params.size() != 1) {
            throw new RuntimeException("CONTEXT should have 1 parameters instead it has " + params.size());
        }
        List<String> baseFunctionParamsWithType = velocityCodeGenInfo.getCallFunctionMetaData().getParamsWithType();
        List<String> baseFunctionParams = velocityCodeGenInfo.getCallFunctionMetaData().getParams();
        
        final StringBuilder orExpresssionBuilder = new StringBuilder("CONTEXT(");
        orExpresssionBuilder.append(baseFunctionParams.stream().map((paramWithType) -> paramWithType).collect(Collectors.joining(",")));
        orExpresssionBuilder.append(",");
        orExpresssionBuilder.append(
        	params.stream().map((expression) -> {
	        	final StringBuilder orIndividualExpresssionBuilder = new StringBuilder();
	        	String conditionFn = nameGenerator.getNewName();
	    		orIndividualExpresssionBuilder.append("this::");
	    		orIndividualExpresssionBuilder.append(conditionFn);
	    		
	    		VelocityFunctionMetaData conditionMetaData = new VelocityFunctionMetaData(conditionFn, "Object", baseFunctionParamsWithType,
	    		        baseFunctionParams,
	    		        "return (" + processExpression(expression, velocityCodeGenInfo, provider) + ");");
	    		velocityCodeGenInfo.addSupportFunction(conditionMetaData);
	            return orIndividualExpresssionBuilder.toString();
	        }).collect(Collectors.joining(",")));
        
        orExpresssionBuilder.append(")");
        return orExpresssionBuilder.toString();
	}
}
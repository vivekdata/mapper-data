package com.opusconsulting.pegasus.formula.parser;

import com.google.inject.Guice;
import com.google.inject.Inject;
import com.google.inject.Injector;
import com.opusconsulting.spartan.formula.ExcelRuntimeModule;
import com.opusconsulting.spartan.formula.ExcelStandaloneSetup;
import org.eclipse.xtext.parser.IParseResult;
import org.eclipse.xtext.parser.IParser;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.io.StringReader;

@Component
public class FormulaParser {

    /* Google inject - Spring will ignores this annotation */
    @Inject
    private IParser parser;

    protected Injector injector;

    @PostConstruct
    private void init() {
        injector = internalCreateInjector();
        injector.injectMembers(this);
    }

    protected Injector internalCreateInjector() {
        return new ExcelStandaloneSetup() {
            @Override
            public Injector createInjector() {
                return Guice.createInjector(new ExcelRuntimeModule());
            }
        }.createInjectorAndDoEMFRegistration();
    }

    public IParseResult parse(String code) {
        return parser.parse(new StringReader(code));
    }

}

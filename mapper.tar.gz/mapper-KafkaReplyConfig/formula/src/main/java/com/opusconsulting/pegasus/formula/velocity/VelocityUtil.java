package com.opusconsulting.pegasus.formula.velocity;

import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.runtime.RuntimeConstants;
import org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.io.StringWriter;
import java.util.Map;
import java.util.Properties;

@Component
public class VelocityUtil {
    VelocityEngine ve;

    @Lazy
    @PostConstruct
    public void init() {
        ve = new VelocityEngine();
        Properties prop = new Properties();

        prop.setProperty(RuntimeConstants.RESOURCE_LOADER, "classpath");
        prop.setProperty("classpath.resource.loader.class", ClasspathResourceLoader.class.getName());
        ve.setProperty("directive.set.null.allowed", true);
        ve.init(prop);
    }


    public String execute(String fileName, Map<String, Object> variables) {
        Template t = ve.getTemplate(fileName);
        VelocityContext context = new VelocityContext();

        for (Map.Entry<String, Object> variableEntry : variables.entrySet()) {
            context.put(variableEntry.getKey(), variableEntry.getValue());
        }

        context.put("String", String.class);
        context.put("NEWLINE", "\n");

/*
        context.put("_t_date", new DateTool());
        context.put("_t_convert", new ConversionTool());
        context.put("_t_math", new MathTool());
        context.put("_t_number", new NumberTool());
*/

        StringWriter writer = new StringWriter();
        t.merge(context, writer);
        return writer.toString();
    }

}

package com.opusconsulting.pegasus.formula;

public interface IContext {
}

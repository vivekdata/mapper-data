package com.opusconsulting.pegasus.formula;

import com.opusconsulting.pegasus.flow.IFlowContext;

import java.util.Map;

public interface ICondition {
    boolean check(IMessage message, IFlowContext ctx, Map<String, Object> params);
}

package com.opusconsulting.pegasus.formula;

public interface IMessage {
    public String getField1();
}

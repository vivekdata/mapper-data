package com.opusconsulting.pegasus.formula;

import com.opusconsulting.pegasus.formula.codegen.GetterCode;
import com.opusconsulting.pegasus.formula.codegen.ICodeProvider;
import com.opusconsulting.pegasus.formula.codegen.SetterCode;
import org.springframework.util.StringUtils;

public class CodeProvider implements ICodeProvider {

    String objectName;

    public CodeProvider(String objectName) {
        this.objectName = objectName;
    }

    @Override
    public GetterCode getGetterCode(String[] names) {
        GetterCode getterCode = new GetterCode();
        getterCode.setCode(objectName + ".getValue" + StringUtils.capitalize(names[0]) + "()");
        return getterCode;
    }

    @Override
    public SetterCode getSetterCode(String[] names) {
        return null;
    }
}

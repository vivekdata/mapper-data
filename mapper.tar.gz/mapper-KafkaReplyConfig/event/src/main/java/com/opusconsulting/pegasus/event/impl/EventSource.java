package com.opusconsulting.pegasus.event.impl;

import com.opusconsulting.pegasus.common.event.IEventContext;
import com.opusconsulting.pegasus.common.event.IEventHandler;
import com.opusconsulting.pegasus.common.event.IEventSource;
import com.opusconsulting.pegasus.common.event.ReplyType;

import java.io.Serializable;

public abstract class EventSource implements IEventSource {

    long id;
    EventManager eventManager;
    IEventHandler handler;

    EventSource(long id, EventManager eventManager, IEventHandler handler) {
        this.id = id;
        this.eventManager = eventManager;
        this.handler = handler;
    }

    public long getId() {
        return id;
    }

    protected <T extends Serializable> void publish(T data, IEventContext context) {
        eventManager.dispatch(this, getSubject(), data, ReplyType.None, context);
    }

    public abstract String getSubject();

    public abstract String getReplySubject();

    public IEventHandler getHandler() {
        return handler;
    }

    @Override
    public <T extends Serializable> void send(IEventSource source, T data, ReplyType replyType) {
        send(source, data, replyType, null);
    }

    @Override
    public <T extends Serializable> void send(IEventSource source, T data, ReplyType replyType,
                                              IEventContext context) {
        eventManager.dispatch(source, this, data, replyType, context);
    }
}

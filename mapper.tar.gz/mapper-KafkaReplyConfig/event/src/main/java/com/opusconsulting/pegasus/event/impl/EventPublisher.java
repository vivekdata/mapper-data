package com.opusconsulting.pegasus.event.impl;

import com.opusconsulting.pegasus.common.event.IEventContext;
import com.opusconsulting.pegasus.common.event.IEventHandler;
import com.opusconsulting.pegasus.common.event.IEventPublisher;

import java.io.Serializable;

public class EventPublisher extends EventSource implements IEventPublisher {
    EventManager eventManager;
    String subject;
    String replySubject;

    EventPublisher(long id, EventManager eventManager, String subject, String replySubject, IEventHandler handler) {
        super(id, eventManager, handler);

        this.eventManager = eventManager;
        this.subject = subject;
        this.replySubject = replySubject;
    }

    @Override
    public String getSubject() {
        return subject;
    }

    @Override
    public String getReplySubject() {
        return replySubject;
    }

    @Override
    public <T extends Serializable> void publish(T data) {
        publish(data, null);
    }

    @Override
    public <T extends Serializable> void publish(T data, IEventContext context) {
        super.publish(data, context);
    }
}

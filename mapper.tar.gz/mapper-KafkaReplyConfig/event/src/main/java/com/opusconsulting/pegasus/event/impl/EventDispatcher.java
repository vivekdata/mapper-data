package com.opusconsulting.pegasus.event.impl;

import com.opusconsulting.pegasus.common.event.IEventContext;
import org.springframework.scheduling.concurrent.CustomizableThreadFactory;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class EventDispatcher {

    ExecutorService executorService;

    EventDispatcher(String name, int minThread, int maxThread) {
        ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(minThread, maxThread,
                60L, TimeUnit.SECONDS,
                new SynchronousQueue<Runnable>());
        threadPoolExecutor.setThreadFactory(new CustomizableThreadFactory(name));

        executorService = threadPoolExecutor;
    }

    public void dispatch(EventSource target, EventMessage eventMessage, IEventContext context) {
        executorService.submit(() -> target.getHandler().handle(eventMessage.setTarget(target), context));
    }

    public void dispatch(List<EventSource> targets, EventMessage eventMessage, IEventContext context) {
        targets.forEach(consumer -> dispatch(consumer, eventMessage.createWithNewTarget(consumer), context));
    }

    public void shutdown() {
        executorService.shutdown();
    }
}

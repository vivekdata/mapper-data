package com.opusconsulting.pegasus.event.impl;

import com.opusconsulting.pegasus.common.event.IEventContext;
import com.opusconsulting.pegasus.common.event.IEventMessage;
import com.opusconsulting.pegasus.common.event.IEventSource;
import com.opusconsulting.pegasus.common.event.ReplyType;

import java.io.Serializable;

public class EventMessage implements IEventMessage {
    IEventSource source;
    IEventSource target;
    Serializable data;
    ReplyType replyType = ReplyType.None;

    IEventContext context;

    public EventMessage(Serializable data, IEventContext context) {
        this.data = data;
        this.context = context;
    }

    public EventMessage(Serializable data, ReplyType replyType, IEventContext context) {
        this.data = data;
        this.replyType = replyType;
        this.context = context;
    }

    @Override
    public IEventSource getSource() {
        return source;
    }

    public EventMessage setSource(IEventSource source) {
        this.source = source;
        return this;
    }

    public IEventSource getTarget() {
        return target;
    }

    public EventMessage setTarget(IEventSource target) {
        this.target = target;
        return this;
    }

    @Override
    public <T extends Serializable> T getData() {
        return (T) data;
    }

    @Override
    public ReplyType getReplyType() {
        return replyType;
    }

    @Override
    public boolean isReply() {
        return (replyType == null || replyType.equals(ReplyType.None)) ? false : true;
    }

    public IEventContext getContext() {
        return context;
    }

    @Override
    public <T extends Serializable> void reply(T data, boolean isSuccess) {
        // sending the message to source and making target as source
        reply(data, isSuccess, null);
    }

    @Override
    public <T extends Serializable> void reply(T data, boolean isSuccess, IEventContext replyContext) {
        ReplyEventContext replyEventContext = (context == null && replyContext == null) ? null : new ReplyEventContext(replyContext, context);

        // sending the message to source and making target as source
        source.send(target, data, (isSuccess) ? ReplyType.Success : ReplyType.Failure, replyEventContext);
    }

    public EventMessage createWithNewTarget(IEventSource target) {
        EventMessage eventMessage = new EventMessage(data, replyType, context);
        eventMessage.source = source;
        eventMessage.target = target;
        return eventMessage;
    }

}

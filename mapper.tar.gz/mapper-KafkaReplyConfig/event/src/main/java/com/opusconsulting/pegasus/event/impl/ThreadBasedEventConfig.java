package com.opusconsulting.pegasus.event.impl;

import java.util.List;

public class ThreadBasedEventConfig extends EventConfig {
    private final static int DEFAULT_THREAD = 10;

    private int minThread;
    private int maxThread;

    private EventDispatcher dispatcher;

    public ThreadBasedEventConfig(String name, EventUseType useType) {
        this(name, useType, DEFAULT_THREAD, DEFAULT_THREAD);
    }

    public ThreadBasedEventConfig(String name, EventUseType useType, List<String> subjects) {
        this(name, useType, subjects, DEFAULT_THREAD, DEFAULT_THREAD);
    }

    public ThreadBasedEventConfig(String name, EventUseType useType, int minThread, int maxThread) {
        super(name, useType);
        this.minThread = minThread;
        this.maxThread = maxThread;

        init();
    }

    public ThreadBasedEventConfig(String name, EventUseType useType, List<String> subjects, int minThread, int maxThread) {
        super(name, useType, subjects);
        this.minThread = minThread;
        this.maxThread = maxThread;

        init();
    }

    private void init() {
        dispatcher = createDispatcher();
    }

    private EventDispatcher createDispatcher() {
        return new EventDispatcher(getName()+"-event-dispatcher", minThread, maxThread);
    }

    @Override
    EventDispatcher getDispatcher() {
        return dispatcher;
    }

    public int getMinThread() {
        return minThread;
    }

    public int getMaxThread() {
        return maxThread;
    }
}

package com.opusconsulting.pegasus.event.impl;

import com.opusconsulting.pegasus.common.event.IEventConsumer;
import com.opusconsulting.pegasus.common.event.IEventHandler;

public class EventConsumer extends EventSource implements IEventConsumer {
    String subject;
    String replySubject;

    EventConsumer(long id, EventManager eventManager, String subject, String replySubject, IEventHandler handler) {
        super(id, eventManager, handler);

        this.subject = subject;
        this.replySubject = replySubject;
    }

    @Override
    public void unSubscribe() {
        eventManager.unSubscribe(subject, this);
    }


    @Override
    public String getSubject() {
        return subject;
    }

    @Override
    public String getReplySubject() {
        return replySubject;
    }
}

package com.opusconsulting.pegasus.event.impl;

import java.util.ArrayList;
import java.util.List;

public abstract class EventConfig {
    private String name;
    private List<String> subjects;
    EventUseType useType;

    public EventConfig(String name, EventUseType useType) {
        this(name, useType, new ArrayList<>());
    }

    public EventConfig(String name, EventUseType useType, List<String> subjects) {
        this.name = name;
        this.useType = useType;
        this.subjects = subjects;
    }

    public String getName() {
        return name;
    }

    public List<String> getSubjects() {
        return subjects;
    }

    public EventConfig addSubject(String subject) {
        subjects.add(subject);
        return this;
    }

    public EventUseType getUseType() {
        return useType;
    }

    abstract EventDispatcher getDispatcher();
}

package com.opusconsulting.pegasus.event.impl;

import com.opusconsulting.pegasus.common.Context;
import com.opusconsulting.pegasus.common.event.IEventContext;

public class EventContext extends Context implements IEventContext {
}

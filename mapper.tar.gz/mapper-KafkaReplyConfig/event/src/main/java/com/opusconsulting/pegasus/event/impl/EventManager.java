package com.opusconsulting.pegasus.event.impl;

import com.opusconsulting.pegasus.common.event.*;
import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Collectors;

@Component
public class EventManager implements IEventManager {

    EventConfig defaultEventConfig;

    Map<String, List<EventSource>> subjectBasedConsumers = new ConcurrentHashMap<>();
    Map<String, EventSource> replyHandlers = new ConcurrentHashMap<>();

    Map<String, EventConfig> subjectBasedConfigs = new ConcurrentHashMap<>();
    EventDispatcher defaultDispatcher;
    List<EventConfig> eventConfigs = new ArrayList<>();

    AtomicLong eventSourceId = new AtomicLong(0);

    public void addConfig(EventConfig config) {
        eventConfigs.add(config);
    }

    public boolean addSubjectToConfig(String subject, String configName) {
        List<EventConfig> collect = eventConfigs.stream()
                .filter(config -> config.getName().equals(configName)).collect(Collectors.toList());
        if (collect.isEmpty()) {
            return false;
        }

        collect.get(0).addSubject(subject);

        return true;
    }

    public void setDefaultEventConfig(EventConfig defaultEventConfig) {
        this.defaultEventConfig = defaultEventConfig;
    }

    private EventConfig getDefaultEventConfig() {
        if (defaultEventConfig == null) {
            defaultEventConfig = createDefaultEventConfig();
        }

        return defaultEventConfig;
    }

    private EventConfig createDefaultEventConfig() {
        return new ThreadBasedEventConfig("*", EventUseType.UseBoth);
    }

    public void init() {
        defaultDispatcher = getDefaultEventConfig().getDispatcher();

        eventConfigs.forEach(config -> {
            config.getSubjects().forEach(subject -> {
                if (config.useType.equals(EventUseType.UseBoth) || config.useType.equals(EventUseType.OnlySubject)) {
                    subjectBasedConfigs.put(subject, config);
                }

                if (config.useType.equals(EventUseType.UseBoth) || config.useType.equals(EventUseType.OnlyReply)) {
                    subjectBasedConfigs.put(subject + "$", config);
                }

            });
        });
    }

    @Override
    public IEventConsumer createConsumer(String subject, IEventHandler handler) {
        List<EventSource> eventConsumers = subjectBasedConsumers.get(subject);
        if (eventConsumers == null) {
            eventConsumers = createSubjectConsumersIfRequired(subject);
        }

        long id = getNextSourceId();
        String replySubject = subject + "$" + id;
        EventConsumer eventConsumer = new EventConsumer(id, this, subject, replySubject, handler);
        eventConsumers.add(eventConsumer);

        replyHandlers.put(replySubject, eventConsumer);
        return eventConsumer;
    }

    private long getNextSourceId() {
        return eventSourceId.incrementAndGet();
    }

    private synchronized List<EventSource> createSubjectConsumersIfRequired(String subject) {
        List<EventSource> eventConsumers = subjectBasedConsumers.get(subject);
        if (eventConsumers != null) {
            return eventConsumers;
        }

        eventConsumers = new CopyOnWriteArrayList<EventSource>();
        subjectBasedConsumers.put(subject, eventConsumers);

        return eventConsumers;
    }

    @Override
    public IEventPublisher createPublisher(String subject) {
        return createPublisher(subject, null);
    }

    @Override
    public IEventPublisher createPublisher(String subject, IEventHandler handler) {
        long id = getNextSourceId();
        String replySubject = (handler == null) ? null : subject + "$" + id;
        EventPublisher publisher = new EventPublisher(id, this, subject, replySubject, handler);

        if (handler != null) {
            replyHandlers.put(replySubject, publisher);
        }
        return publisher;
    }

    @Override
    public boolean unSubscribe(String subject, IEventConsumer consumer) {
        List<EventSource> eventConsumers = subjectBasedConsumers.get(subject);
        if (eventConsumers == null) {
            return false;
        }

        if (consumer instanceof EventConsumer) {
            String replySubject = ((EventConsumer) consumer).getReplySubject();
            replyHandlers.remove(replySubject);
        }

        return eventConsumers.remove(consumer);
    }

    @Override
    public boolean unSubscribe(IEventPublisher publisher) {
        if (publisher instanceof EventPublisher) {
            String replySubject = ((EventPublisher) publisher).getReplySubject();
            return (replyHandlers.remove(replySubject) != null);
        }

        return false;
    }

    @Override
    public void shutdown() {
        eventConfigs.forEach(eventConfig -> eventConfig.getDispatcher().shutdown());

        defaultDispatcher.shutdown();
    }

    public <T extends Serializable> void dispatch(IEventSource source, EventSource destination, T data, ReplyType replyType,
                                                  IEventContext context) {
        String subject = replyType == null || replyType.equals(ReplyType.None) ? destination.getSubject() : destination.getReplySubject();

        dispatch(source, subject, data, replyType, context);
    }

    public <T extends Serializable> void dispatch(IEventSource source, String subject, T data, ReplyType replyType,
                                                  IEventContext context) {
        EventMessage eventMessage = new EventMessage(data, replyType, context);
        eventMessage.setSource(source);

        publish(subject, eventMessage);
    }

    private void publish(String subject, EventMessage eventMessage) {
        String dispatchSubject = getOriginalSubject(subject);

        if (eventMessage.isReply()) {
            dispatchSubject += "$";
        }

        EventDispatcher dispatcher = getDispatcher(dispatchSubject);
        dispatcher = (dispatcher == null) ? defaultDispatcher : dispatcher;

        if (eventMessage.isReply()) {
            EventSource replyConsumer = getReplyEventSource(subject);
            if (replyConsumer != null) {
                dispatcher.dispatch(replyConsumer, eventMessage, eventMessage.getContext());
            }
        } else {
            List<EventSource> consumers = getConsumers(subject);
            if (consumers != null && !consumers.isEmpty()) {
                dispatcher.dispatch(consumers, eventMessage, eventMessage.getContext());
            }
        }

        reportNoConsumer(subject, eventMessage);
    }

    private void reportNoConsumer(String subject, EventMessage eventMessage) {
        // TODO
    }

    private EventSource getReplyEventSource(String subject) {
        return replyHandlers.get(subject);
    }

    private String getOriginalSubject(String subject) {
        int matchIndex = subject.indexOf("$");
        return (matchIndex == -1) ? subject : subject.substring(0, matchIndex);
    }

    private List<EventSource> getConsumers(String subject) {
        return subjectBasedConsumers.get(subject);
    }

    private EventDispatcher getDispatcher(String subject) {
        EventConfig eventConfig = subjectBasedConfigs.get(subject);
        return eventConfig == null ? null : eventConfig.getDispatcher();
    }

}

package com.opusconsulting.pegasus.event.impl;

public enum EventUseType {
    OnlySubject, OnlyReply, UseBoth
}

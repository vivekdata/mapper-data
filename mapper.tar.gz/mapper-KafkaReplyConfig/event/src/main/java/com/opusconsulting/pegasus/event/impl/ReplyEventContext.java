package com.opusconsulting.pegasus.event.impl;

import com.opusconsulting.pegasus.common.event.IEventContext;
import com.opusconsulting.pegasus.common.event.IReplyEventContext;

public class ReplyEventContext implements IEventContext, IReplyEventContext {
    IEventContext replyContext;
    IEventContext originalContext;

    public ReplyEventContext(IEventContext replyContext, IEventContext originalContext) {
        this.replyContext = replyContext;
        this.originalContext = originalContext;
    }

    @Override
    public IEventContext getOriginalContext() {
        return originalContext;
    }

    @Override
    public <T> T get(String key) {
        return (replyContext == null) ? null : replyContext.get(key);
    }

    @Override
    public <T> void set(String key, T value) {
        if (replyContext != null) {
            replyContext.set(key, value);
        }

    }

    @Override
    public <T> T remove(String key) {
        return (replyContext == null) ? null : replyContext.remove(key);
    }
}

package com.opusconsulting.pegasus.event.impl;

import com.opusconsulting.pegasus.common.event.IEventContext;
import com.opusconsulting.pegasus.common.event.IEventMessage;
import com.opusconsulting.pegasus.common.event.IEventPublisher;
import com.opusconsulting.pegasus.common.event.IReplyEventContext;

public class EventManagerTest {
    public static String getThreadName() {
        return Thread.currentThread().getName();
    }

    public static void multipleReply() throws InterruptedException {
        EventManager eventManager = new EventManager();

        EventConfig config = new ThreadBasedEventConfig("SPECIAL", EventUseType.UseBoth);
        config.addSubject("SP1");
        eventManager.addConfig(config);

        eventManager.init();

        eventManager.createConsumer("SP1", (eventMessage, context) -> {
            System.out.println(getThreadName() + " [SP1] Consumer received the message << " + eventMessage.getData());
            if (!eventMessage.isReply()) {
                System.out.println(getThreadName() + " [SP1] Consumer replying as Hi");
                eventMessage.reply("Hi ...", true);
            }
        });

        IEventPublisher publisher = eventManager.createPublisher("SP1", (eventMessage, context) -> {
            System.out.println(getThreadName() + " [SP1] Publisher received reply message << " + eventMessage.getData());

            if (eventMessage.isReply()) {
                System.out.println(getThreadName() + " [SP1] Publisher replying as Hi again !!!");
                eventMessage.reply("Hi again !!!", true);
            }
        });

        publisher.publish("Hello");

        Thread.sleep(1000);
        eventManager.shutdown();
    }

    public static void justReplyHandler(IEventMessage message, IEventContext context) {
        if (context instanceof IReplyEventContext) {
            IReplyEventContext replyEventContext = (IReplyEventContext) context;
            IEventContext originalContext = replyEventContext.getOriginalContext();
            EventMessage originalMessage = originalContext.get("req");
            System.out.println("Reply from " + context.get("source"));
            System.out.println("Reply to initiator " + originalContext.get("initiator"));

            if (originalMessage != null) {
                EventContext currentReplyContext = new EventContext();
                currentReplyContext.set("source", originalContext.get("initiator"));
                originalMessage.reply("REPLY", true, currentReplyContext);
            }
        }
    }

    private static void chainReply() throws InterruptedException {
        EventManager eventManager = new EventManager();

        EventConfig config = new ThreadBasedEventConfig("CHAIN_REPLY", EventUseType.UseBoth);
        config.addSubject("SUB1");
        config.addSubject("SUB2");
        config.addSubject("SUB3");
        eventManager.addConfig(config);

        eventManager.init();

        eventManager.createConsumer("SUB1", (eventMessage, context) -> {
            System.out.println(getThreadName() + " [SUB1] Consumer received the message << " + eventMessage.getData());

            EventContext eventContext = new EventContext();
            eventContext.set("req", eventMessage);
            eventContext.set("initiator", "SUB1");
            eventManager.createPublisher("SUB2", EventManagerTest::justReplyHandler)
                    .publish("Sending to SUB2", eventContext);
        });

        eventManager.createConsumer("SUB2", (eventMessage, context) -> {
            System.out.println(getThreadName() + " [SUB2] Consumer received the message << " + eventMessage.getData());

            EventContext eventContext = new EventContext();
            eventContext.set("req", eventMessage);
            eventContext.set("initiator", "SUB2");
            eventManager.createPublisher("SUB3", EventManagerTest::justReplyHandler)
                    .publish("Sending to SUB3", eventContext);
        });

        eventManager.createConsumer("SUB3", (eventMessage, context) -> {
            System.out.println(getThreadName() + " [SUB3] Consumer received the message << " + eventMessage.getData());

            if (!eventMessage.isReply()) {
                EventContext currentReplyContext = new EventContext();
                currentReplyContext.set("source", "SUB3");
                System.out.println(getThreadName() + " [SUB3] Consumer replying as Hi");
                eventMessage.reply("Hi ...", true, currentReplyContext);
            }
        });

        IEventPublisher publisher = eventManager.createPublisher("SUB1", (eventMessage, context) -> {
            System.out.println(getThreadName() + " [PUBLISHER] Publisher received reply message << " + eventMessage.getData());
        });

        publisher.publish("Hello");

        Thread.sleep(1000);
        eventManager.shutdown();
    }

    public static void main(String[] args) throws InterruptedException {
        System.out.println("Multiple Reply");
        multipleReply();

        System.out.println("Chain Reply");
        chainReply();
    }

}

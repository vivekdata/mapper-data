package com.opusconsulting.pegasus.format.iso.metadata;

/**
 * Created by saran on 6/10/17.
 */
public class MessageFieldDetail<T extends FieldDetail> {
    ExistenceType type;
    T field;

    public MessageFieldDetail() {
    }

    public MessageFieldDetail(ExistenceType type, T field) {
        this.type = type;
        this.field = field;
    }

    public ExistenceType getType() {
        return type;
    }

    public void setType(ExistenceType type) {
        this.type = type;
    }

    public T getField() {
        return field;
    }

    public void setField(T field) {
        this.field = field;
    }
}

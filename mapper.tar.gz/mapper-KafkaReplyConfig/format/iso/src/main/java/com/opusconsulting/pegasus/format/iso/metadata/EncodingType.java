package com.opusconsulting.pegasus.format.iso.metadata;

/**
 * Created by saran on 5/28/17.
 */
public enum EncodingType {
    ASCII, BCD, EBCDIC, BINARY, HEX, CHAR
}

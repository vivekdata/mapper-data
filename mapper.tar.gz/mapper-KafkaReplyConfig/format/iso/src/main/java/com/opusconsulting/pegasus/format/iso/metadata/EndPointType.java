package com.opusconsulting.pegasus.format.iso.metadata;

public enum EndPointType {
	CLIENT,HOST, EVENTBUS;
}

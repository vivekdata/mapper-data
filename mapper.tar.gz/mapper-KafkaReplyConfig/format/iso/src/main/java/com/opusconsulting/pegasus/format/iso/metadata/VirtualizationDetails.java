package com.opusconsulting.pegasus.format.iso.metadata;

import java.util.ArrayList;
import java.util.List;

public class VirtualizationDetails {
	String name;
	String nodeName;
	String type;
	List<VirtualizationRuleDetails> ruleDetails;
	
	public VirtualizationDetails(String name, String nodeName, String type) {
		super();
		this.name = name;
		this.nodeName = nodeName;
		this.type = type;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getNodeName() {
		return nodeName;
	}

	public void setNodeName(String nodeName) {
		this.nodeName = nodeName;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public List<VirtualizationRuleDetails> getRuleDetails() {
		return ruleDetails;
	}
	
	public void setRuleDetails(List<VirtualizationRuleDetails> ruleDetails) {
		this.ruleDetails = ruleDetails;
	}
}

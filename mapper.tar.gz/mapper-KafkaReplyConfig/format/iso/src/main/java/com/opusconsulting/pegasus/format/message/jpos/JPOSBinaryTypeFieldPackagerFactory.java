package com.opusconsulting.pegasus.format.message.jpos;

import org.jpos.iso.IFA_BINARY;
import org.jpos.iso.IFA_LBINARY;
import org.jpos.iso.IFA_LLBINARY;
import org.jpos.iso.IFA_LLLBINARY;
import org.jpos.iso.IFA_LLLLBINARY;
import org.jpos.iso.IFA_LLLLLBINARY;
import org.jpos.iso.IFA_LLLLLLBINARY;
import org.jpos.iso.IFB_BINARY;
import org.jpos.iso.IFB_LLBINARY;
import org.jpos.iso.IFB_LLHBINARY;
import org.jpos.iso.IFB_LLHEX;
import org.jpos.iso.IFB_LLLBINARY;
import org.jpos.iso.IFB_LLLHBINARY;
import org.jpos.iso.IFB_LLLLBINARY;
import org.jpos.iso.IFE_BINARY;
import org.jpos.iso.IFE_LLBINARY;
import org.jpos.iso.IFE_LLLBINARY;
import org.jpos.iso.IFE_LLLLBINARY;
import org.jpos.iso.IF_CHAR;
import org.jpos.iso.ISOFieldPackager;

import com.opusconsulting.pegasus.format.iso.metadata.EncodingType;
import com.opusconsulting.pegasus.format.iso.metadata.FieldSizeType;

public class JPOSBinaryTypeFieldPackagerFactory {
	public static ISOFieldPackager getFieldPackager(String fieldName, EncodingType encodingType, EncodingType lengthEncodingType, int size, FieldSizeType sizeType) {
		if(FieldSizeType.Fixed.equals(sizeType)){
			return fixedBinaryPackager(fieldName, encodingType, lengthEncodingType, size);
		} else {
			return variableBinaryPackager(fieldName, encodingType, lengthEncodingType, size);
		}
	}

	private static ISOFieldPackager variableBinaryPackager(String fieldName, EncodingType encodingType, EncodingType lengthEncodingType,
			int size) {
		switch (encodingType) {
		case ASCII:
			return getASCIIPackager(fieldName, size, lengthEncodingType);
		case BINARY:
			return getBinaryPackager(fieldName, size, lengthEncodingType);
		case EBCDIC:
			return getEBCDICPackager(fieldName, size, lengthEncodingType);
		case HEX:
			return getHEXPackager(fieldName, size, lengthEncodingType);
		default:
			return new IF_CHAR(size, fieldName);
		}
	}
	
	private static ISOFieldPackager getHEXPackager(String fieldName, int size, EncodingType lengthEncodingType) {
		switch(size) {
		case 2 :
			return new IFB_LLHEX(99, fieldName);
		default :
			return null;
		}
	}

	private static ISOFieldPackager fixedBinaryPackager(String fieldName, EncodingType encodingType, EncodingType lengthEncodingType,
			int size) {
		switch (encodingType) {
		case ASCII:
			return new IFA_BINARY(size, fieldName);
		case BINARY:
			return new IFB_BINARY(size, fieldName);
		case EBCDIC:
			return new IFE_BINARY(size, fieldName);
		case CHAR:
			return null;
		default:
			return new IFA_BINARY(size, fieldName);
		}
	}

	private static ISOFieldPackager getASCIIPackager(String fieldName, int size, EncodingType lengthEncodingTyoe) {
		switch(size) {
			case 1 :
				return new IFA_LBINARY(9, fieldName);
			case 2 :
				return new IFA_LLBINARY(99, fieldName); // it can be IFA_FLLCHAR. but if the length padded with fixed length data padded by space
			case 3 :
				return new IFA_LLLBINARY(999, fieldName);
			case 4 :
				return new IFA_LLLLBINARY(9999, fieldName);
			case 5 :
				return new IFA_LLLLLBINARY(99999, fieldName);
			case 6 :
				return new IFA_LLLLLLBINARY(999999, fieldName);
			default :
				return null;
		}
		
	}
	
	private static ISOFieldPackager getBinaryPackager(String fieldName, int size, EncodingType lengthEncodingType) {
		if(EncodingType.HEX.equals(lengthEncodingType)){
			switch(size) {
			case 2 :
				return new IFB_LLHBINARY(99, fieldName); //IFB_LLHFBINARY
			case 3 :
				return new IFB_LLLHBINARY(999, fieldName);
			default :
				return null;
			}
		} else {
			switch(size) {
				case 2 :
					return new IFB_LLBINARY(99, fieldName);
				case 3 :
					return new IFB_LLLBINARY(999, fieldName);
				case 4 : 
					return new IFB_LLLLBINARY(9999, fieldName);
				default :
					return null;
			}
		}
	}
	
	private static ISOFieldPackager getEBCDICPackager(String fieldName, int size, EncodingType lengthEncodingType) {
		switch(size) {
			case 2 :
				return new IFE_LLBINARY(99, fieldName);
			case 3 :
				return new IFE_LLLBINARY(999, fieldName);
			case 4 :
				return new IFE_LLLLBINARY(9999, fieldName);
			default :
				return null;
		}
	}
}

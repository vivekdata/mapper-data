package com.opusconsulting.pegasus.format.iso.metadata;

import java.util.ArrayList;
import java.util.List;

public class VirtualizationRuleDetails {
	String name;
	VirtualizationRuleType ruleType;
	String formulae;
	String fieldName;
	long delayedTime;
	String messageMetaDataMsgName;
	boolean messageMetaDataMsgRequest;
	List<VirtualizationRuleDetails> childRules;
	
	public VirtualizationRuleDetails() {
		super();
		this.childRules = new ArrayList<>();
	}

	public VirtualizationRuleDetails(String name, VirtualizationRuleType ruleType, String formulae, String fieldName,
			long delayedTime, String messageMetaDataMsgName, boolean messageMetaDataMsgRequest,
			List<VirtualizationRuleDetails> childRules) {
		super();
		this.name = name;
		this.ruleType = ruleType;
		this.formulae = formulae;
		this.fieldName = fieldName;
		this.delayedTime = delayedTime;
		this.messageMetaDataMsgName = messageMetaDataMsgName;
		this.messageMetaDataMsgRequest = messageMetaDataMsgRequest;
		this.childRules = childRules;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public VirtualizationRuleType getRuleType() {
		return ruleType;
	}

	public void setRuleType(String ruleType) {
		this.ruleType = VirtualizationRuleType.getRuleType(ruleType);
	}

	public String getFormulae() {
		return formulae;
	}

	public void setFormulae(String formulae) {
		this.formulae = formulae;
	}

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public long getDelayedTime() {
		return delayedTime;
	}

	public void setDelayedTime(long delayedTime) {
		this.delayedTime = delayedTime;
	}

	public List<VirtualizationRuleDetails> getChildRules() {
		return childRules;
	}
	
	public void addChildRule(VirtualizationRuleDetails ruleDetails){
		this.childRules.add(ruleDetails);
	}

	public String getMessageMetaDataMsgName() {
		return messageMetaDataMsgName;
	}

	public void setMessageMetaDataMsgName(String messageMetaDataMsgName) {
		this.messageMetaDataMsgName = messageMetaDataMsgName;
	}

	public boolean isMessageMetaDataMsgRequest() {
		return messageMetaDataMsgRequest;
	}

	public void setMessageMetaDataMsgRequest(boolean messageMetaDataMsgRequest) {
		this.messageMetaDataMsgRequest = messageMetaDataMsgRequest;
	}
}

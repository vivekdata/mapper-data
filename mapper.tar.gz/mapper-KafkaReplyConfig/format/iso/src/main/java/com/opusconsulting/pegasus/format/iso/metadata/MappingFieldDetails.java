package com.opusconsulting.pegasus.format.iso.metadata;

public class MappingFieldDetails {
	private String destinationFieldName;
	private String mappingFormula;

	public MappingFieldDetails(String destinationFieldName, String mappingFormula) {
		super();
		this.destinationFieldName = destinationFieldName;
		this.mappingFormula = mappingFormula;
	}

	public String getDestinationFieldName() {
		return destinationFieldName;
	}

	public void setDestinationFieldName(String destinationFieldName) {
		this.destinationFieldName = destinationFieldName;
	}

	public String getMappingFormula() {
		return mappingFormula;
	}

	public void setMappingFormula(String mappingFormula) {
		this.mappingFormula = mappingFormula;
	}
}

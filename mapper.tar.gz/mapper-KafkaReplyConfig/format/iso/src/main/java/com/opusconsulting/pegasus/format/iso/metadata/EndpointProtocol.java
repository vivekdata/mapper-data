package com.opusconsulting.pegasus.format.iso.metadata;

public enum EndpointProtocol {
	TCP,HTTP,KAFKA;
}

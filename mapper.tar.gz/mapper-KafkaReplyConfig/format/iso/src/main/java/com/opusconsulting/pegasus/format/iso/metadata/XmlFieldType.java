package com.opusconsulting.pegasus.format.iso.metadata;

public enum XmlFieldType {
	String,Numeric,Composite, Tlv;
}

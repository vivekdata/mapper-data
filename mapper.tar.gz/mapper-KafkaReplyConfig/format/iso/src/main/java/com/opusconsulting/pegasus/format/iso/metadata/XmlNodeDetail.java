package com.opusconsulting.pegasus.format.iso.metadata;

/**
 * Created by Anup on 27/03/2018.
 */
public class XmlNodeDetail extends NodeDetail<XmlMessageDetails> {

    public XmlNodeDetail(String name) {
        super(name);
    }

    public XmlNodeDetail(String name, String description) {
        super(name, description);
    }
}

package com.opusconsulting.pegasus.format.iso.metadata;

import java.util.ArrayList;
import java.util.List;

public class HttpEndPointDetail extends EndPointDetail {
	private List<EndPoint> httpEndPoints;
	
	public HttpEndPointDetail(String nodeName, String address, int port, EndpointProtocol protocol, EndPointType type) {
		super(nodeName, address, port, protocol, type);
		this.httpEndPoints = new ArrayList<>();				
	}

	public HttpEndPointDetail(String address, int port, EndpointProtocol protocol) {
		super(address, port, protocol);
		this.httpEndPoints = new ArrayList<>();
	}
	
	public void loadEndPoint(String url, String messageName, String method){
		EndPoint endPoint = new HttpEndPointDetail.EndPoint(url, messageName, method);
		this.httpEndPoints.add(endPoint);
	}
	
	public List<HttpEndPointDetail.EndPoint> getHttpEndPoints() {
		return httpEndPoints;
	}

	public class EndPoint{
		private String url;
		private String messageName;
		private String method;
		
		public EndPoint(String url, String messageName, String method) {
			super();
			this.url = url;
			this.messageName = messageName;
			this.method = method;
		}

		public String getUrl() {
			return url;
		}

		public String getMessageName() {
			return messageName;
		}

		public String getMethod() {
			return method;
		}
	}
}

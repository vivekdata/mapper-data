package com.opusconsulting.pegasus.format.iso.metadata;

public enum PaddingType {
    None, Left, Right
}
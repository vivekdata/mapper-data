package com.opusconsulting.pegasus.format.iso.metadata;

public class EventbusEndPointDetails extends EndPointDetail {
	String inboundAddress;
	String outboundAddress;
	public EventbusEndPointDetails(String address, int port, EndpointProtocol protocol, String inboundAddress,
			String outboundAddress) {
		super(address, port, protocol);
		this.inboundAddress = inboundAddress;
		this.outboundAddress = outboundAddress;
	}
	
	public EventbusEndPointDetails(String nodeName, String address, int port, EndpointProtocol protocol,
			EndPointType type, String inboundAddress, String outboundAddress) {
		super(nodeName, address, port, protocol, type);
		this.inboundAddress = inboundAddress;
		this.outboundAddress = outboundAddress;
	}


	public String getInboundAddress() {
		return inboundAddress;
	}
	public void setInboundAddress(String inboundAddress) {
		this.inboundAddress = inboundAddress;
	}
	public String getOutboundAddress() {
		return outboundAddress;
	}
	public void setOutboundAddress(String outboundAddress) {
		this.outboundAddress = outboundAddress;
	}
}

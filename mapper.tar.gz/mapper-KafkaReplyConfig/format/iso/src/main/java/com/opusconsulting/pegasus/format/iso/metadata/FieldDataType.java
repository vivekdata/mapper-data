package com.opusconsulting.pegasus.format.iso.metadata;

public enum FieldDataType {
    String, Numeric, Hex, Binary, Tlv;
}
package com.opusconsulting.pegasus.format.iso.metadata;

import java.util.List;

public class RoutingDetails {

	String nodeName;
	List<RoutingFormulaDetails> routingFormulas;

	
	public RoutingDetails(){
		super();
	}
	public RoutingDetails(String nodeName, List<RoutingFormulaDetails> routingFormulas) {
		super();
		this.nodeName = nodeName;
		this.routingFormulas = routingFormulas;
	}

	public String getNodeName() {
		return nodeName;
	}

	public void setNodeName(String nodeName) {
		this.nodeName = nodeName;
	}

	public List<RoutingFormulaDetails> getRoutingFormulas() {
		return routingFormulas;
	}

	public void setRoutingFormulas(List<RoutingFormulaDetails> routingFormulas) {
		this.routingFormulas = routingFormulas;
	}

}

package com.opusconsulting.pegasus.format.iso.metadata;

public class EndPointDetail {
	private String address;
	private int port;
	private EndpointProtocol protocol;
	private EndPointType type;
	private String nodeName;
	
	public EndPointDetail(String address, int port, EndpointProtocol protocol) {
		super();
		this.address = address;
		this.port = port;
		this.protocol = protocol;
	}

	public EndPointDetail(String nodeName, EndpointProtocol protocol, EndPointType type) {
		super();
		this.nodeName=nodeName;
		this.address = address;
		this.port = port;
		this.protocol = protocol;
		this.type = type;
	}



	public EndPointDetail(String nodeName,String address, int port, EndpointProtocol protocol, EndPointType type) {
		super();
		this.nodeName=nodeName;
		this.address = address;
		this.port = port;
		this.protocol = protocol;
		this.type = type;
	}



	public String getAddress() {
		return address;
	}
	
	public int getPort() {
		return port;
	}
	
	public EndpointProtocol getProtocol() {
		return protocol;
	}

	public EndPointType getType() {
		return type;
	}



	public String getNodeName() {
		return nodeName;
	}
	
	
}

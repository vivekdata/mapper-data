package com.opusconsulting.pegasus.format.iso.metadata;

import java.util.List;

/**
 * Created by saran on 5/28/17.
 */
public class ISOFieldMetaData extends FieldDetail<FieldDataType> {
    FieldSizeType sizeType;
    int length;

    EncodingType encodingType;

    int prefixLength;
    EncodingType prefixEncodingType;

    PaddingType paddingType;
    Character paddingChar;

    private ISOFieldMetaData(String name, String description, FieldDataType dataType, FieldSizeType sizeType, int length, EncodingType encodingType,
                             int prefixLength, EncodingType prefixEncodingType, PaddingType paddingType, Character paddingChar) {
        super(name, description, dataType);
        this.sizeType = sizeType;
        this.length = length;
        this.encodingType = encodingType;
        this.prefixLength = prefixLength;
        this.prefixEncodingType = prefixEncodingType;
        this.paddingType = paddingType;
        this.paddingChar = paddingChar;
    }

    private ISOFieldMetaData(String name, String description, FieldDataType dataType, FieldSizeType sizeType, int length, EncodingType encodingType,
                             PaddingType paddingType, Character paddingChar) {
        super(name, description, dataType);
        this.sizeType = sizeType;
        this.length = length;
        this.encodingType = encodingType;
        this.paddingType = paddingType;
        this.paddingChar = paddingChar;
    }

    public static ISOFieldMetaData fixed(String name, String description, FieldDataType dataType, int length, EncodingType encodingType) {
        return new ISOFieldMetaData(name, description, dataType, FieldSizeType.Fixed, length, encodingType, PaddingType.None, null);
    }

    public static ISOFieldMetaData fixed(String name, String description, FieldDataType dataType, int length, EncodingType encodingType,
                                         PaddingType paddingType, Character paddingChar) {
        return new ISOFieldMetaData(name, description, dataType, FieldSizeType.Fixed, length, encodingType, paddingType, paddingChar);
    }

    public static ISOFieldMetaData variable(String name, String description, FieldDataType dataType, EncodingType encodingType, int prefixLength,
                                            EncodingType prefixEncodingType) {
        return new ISOFieldMetaData(name, description, dataType, FieldSizeType.Variable, prefixLength, encodingType, prefixLength, prefixEncodingType,
                PaddingType.None, null);
    }

    public static ISOFieldMetaData variable(String name, String description, FieldDataType dataType, EncodingType encodingType, int prefixLength,
                                            EncodingType prefixEncodingType, PaddingType paddingType, Character paddingChar) {
        return new ISOFieldMetaData(name, description, dataType, FieldSizeType.Variable, prefixLength, encodingType, prefixLength, prefixEncodingType,
                paddingType, paddingChar);
    }

	public FieldSizeType getSizeType() {
		return sizeType;
	}

	public int getLength() {
		return length;
	}

	public EncodingType getEncodingType() {
		return encodingType;
	}

	public int getPrefixLength() {
		return prefixLength;
	}

	public EncodingType getPrefixEncodingType() {
		return prefixEncodingType;
	}

	public PaddingType getPaddingType() {
		return paddingType;
	}

	public Character getPaddingChar() {
		return paddingChar;
	}

}

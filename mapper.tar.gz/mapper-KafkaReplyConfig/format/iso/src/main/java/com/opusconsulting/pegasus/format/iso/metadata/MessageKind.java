package com.opusconsulting.pegasus.format.iso.metadata;

/**
 * Created by saran on 5/28/17.
 */
public enum MessageKind {
    Request, Response
}

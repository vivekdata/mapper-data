package com.opusconsulting.pegasus.format.iso.metadata;

public enum VirtualizationRuleType {
	ADD_FIELD("addField"), MODIFY_FIELD("modifyField"), REMOVE_FIELD("removeField"), 
		DELAY_RESPONSE("delayResponse"), CONDITION_BASED("conditionBased"), 
		SEND_RESPONSE("sendResponse"), NO_RESPONSE("noResponse"), MESSAGE_META_DATA_DECISION("messageMetaDataDecision");

	private String ruleType;

	private VirtualizationRuleType(String ruleType) {
		this.ruleType = ruleType;
	}

	public String getRuleType() {
		return ruleType;
	}
	
	public static VirtualizationRuleType getRuleType(String ruleType){
		for (VirtualizationRuleType virtualizationRuleType : values()) {
			if(virtualizationRuleType.getRuleType().equalsIgnoreCase(ruleType)){
				return virtualizationRuleType;
			}
		}
		return null;
	}
}

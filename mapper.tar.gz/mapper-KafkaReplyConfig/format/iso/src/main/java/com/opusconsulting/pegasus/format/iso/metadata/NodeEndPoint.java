package com.opusconsulting.pegasus.format.iso.metadata;

public interface NodeEndPoint {

}

package com.opusconsulting.pegasus.format.iso.metadata;

import java.util.List;

public class MappingDetails<T extends MappingFieldDetails> {
	String sourceNodeName;
	String sourceMessageName;
	String sourceFormat;
	String destinationNodeName;
	String destinationMessageName;
	String destinationFormat;
	String mappingIdentificationFormula;
	List<T> fieldMapping;
	
	public String getSourceNodeName() {
		return sourceNodeName;
	}
	
	public void setSourceNodeName(String sourceNodeName) {
		this.sourceNodeName = sourceNodeName;
	}
	
	public String getSourceMessageName() {
		return sourceMessageName;
	}
	
	public void setSourceMessageName(String sourceMessageName) {
		this.sourceMessageName = sourceMessageName;
	}
	
	public String getDestinationNodeName() {
		return destinationNodeName;
	}
	
	public void setDestinationNodeName(String destinationNodeName) {
		this.destinationNodeName = destinationNodeName;
	}
	
	public String getDestinationMessageName() {
		return destinationMessageName;
	}
	
	public void setDestinationMessageName(String destinationMessageName) {
		this.destinationMessageName = destinationMessageName;
	}
	
	public List<T> getFieldMapping() {
		return fieldMapping;
	}
	
	public void setFieldMapping(List<T> fieldMapping) {
		this.fieldMapping = fieldMapping;
	}

	public String getMappingIdentificationFormula() {
		return mappingIdentificationFormula;
	}

	public void setMappingIdentificationFormula(String mappingIdentificationFormula) {
		this.mappingIdentificationFormula = mappingIdentificationFormula;
	}

	public String getSourceFormat() {
		return sourceFormat;
	}

	public void setSourceFormat(String sourceFormat) {
		this.sourceFormat = sourceFormat;
	}

	public String getDestinationFormat() {
		return destinationFormat;
	}

	public void setDestinationFormat(String destinationFormat) {
		this.destinationFormat = destinationFormat;
	}
}

package com.opusconsulting.pegasus.format.iso.metadata;

public class NodeEndPointDetails implements NodeEndPoint {
	private String messageName;
	private String url;
	private String methodName;
	
	public NodeEndPointDetails(String messageName, String url, String methodName) {
		super();
		this.messageName = messageName;
		this.url = url;
		this.methodName = methodName;
	}

	public String getMessageName() {
		return messageName;
	}

	public String getUrl() {
		return url;
	}

	public String getMethodName() {
		return methodName;
	}
}

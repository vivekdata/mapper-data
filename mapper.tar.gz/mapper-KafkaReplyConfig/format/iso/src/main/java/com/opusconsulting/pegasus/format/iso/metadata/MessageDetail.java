package com.opusconsulting.pegasus.format.iso.metadata;

import java.util.List;

/**
 * Created by saran on 5/28/17.
 */
public abstract class MessageDetail<T extends MessageFieldDetail> {
    String name;
    String description;
    MessageKind kind;

    List<T> messageFields;
    String messageIdentificationFormula;

    public MessageDetail() {
    }

    public MessageDetail(String name) {
        this.name = name;
    }

    public MessageDetail(String name, String description, MessageKind kind) {
        this.name = name;
        this.description = description;
        this.kind = kind;
    }

    public MessageDetail(String name, String description, MessageKind kind, String messageIdentificationFormula) {
		super();
		this.name = name;
		this.description = description;
		this.kind = kind;
		this.messageIdentificationFormula = messageIdentificationFormula;
	}

	public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public MessageKind getKind() {
        return kind;
    }

    public void setKind(MessageKind kind) {
        this.kind = kind;
    }

    public List<T> getMessageFields() {
        return messageFields;
    }

    public void setMessageFields(List<T> messageFields) {
        this.messageFields = messageFields;
    }

	public String getMessageIdentificationFormula() {
		return messageIdentificationFormula;
	}

	public void setMessageIdentificationFormula(String messageIdentificationFormula) {
		this.messageIdentificationFormula = messageIdentificationFormula;
	}
}

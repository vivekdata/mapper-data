package com.opusconsulting.pegasus.format.message.jpos;

import org.jpos.iso.IFA_BITMAP;
import org.jpos.iso.IFA_NUMERIC;
import org.jpos.iso.IFB_BITMAP;
import org.jpos.iso.IFE_BITMAP;
import org.jpos.iso.ISOFieldPackager;

import com.opusconsulting.pegasus.format.iso.metadata.EncodingType;
import com.opusconsulting.pegasus.format.iso.metadata.FieldDataType;
import com.opusconsulting.pegasus.format.iso.metadata.FieldSizeType;

public class JPOSDataTypeFactory {
	public static ISOFieldPackager getFieldPackager(String fieldName, EncodingType encodingType, EncodingType lengthEncodingType, FieldDataType dataType, int size, FieldSizeType sizeType) {
		switch(dataType){
			case String :
				return JPOSCharTypeFieldPackagerFactory.getFieldPackager(fieldName, encodingType, lengthEncodingType, size, sizeType);
			case Numeric :
				return JPOSNumericTypeFieldPackagerFactory.getFieldPackager(fieldName, encodingType, lengthEncodingType, size, sizeType);
			case Hex :
				return JPOSHexTypeFieldPackagerFactory.getFieldPackager(fieldName, encodingType, lengthEncodingType, size, sizeType);
			case Binary :
				return JPOSBinaryTypeFieldPackagerFactory.getFieldPackager(fieldName, encodingType, lengthEncodingType, size, sizeType);
			case Tlv :
				return JPOSCharTypeFieldPackagerFactory.getFieldPackager(fieldName, encodingType, lengthEncodingType, size, sizeType);
			default :
				throw new UnsupportedOperationException("Unsupported format");
		}
	}
	
	public static ISOFieldPackager getMTIPackager(int size, String fieldName){
		return new IFA_NUMERIC(size, fieldName);
	}
	
	public static ISOFieldPackager getBitMapPackager(String fieldName, EncodingType bitMapEncoding, int size){
		switch (bitMapEncoding) {
		case ASCII:
			return new IFA_BITMAP(size, fieldName);
		case BINARY:
			return new IFB_BITMAP(size, fieldName);
		case EBCDIC:
			return new IFE_BITMAP(size, fieldName);
		default:
			return new IFB_BITMAP(size, fieldName);
		}
	}
}

package com.opusconsulting.pegasus.format.iso.metadata;

public enum FieldSizeType {
    Fixed, Variable
}
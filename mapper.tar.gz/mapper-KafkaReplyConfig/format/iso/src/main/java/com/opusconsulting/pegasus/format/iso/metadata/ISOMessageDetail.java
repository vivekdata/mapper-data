package com.opusconsulting.pegasus.format.iso.metadata;

/**
 * Created by saran on 5/28/17.
 */
public class ISOMessageDetail extends MessageDetail<MessageFieldDetail<ISOFieldMetaData>> {
    public ISOMessageDetail() {
    }

    public ISOMessageDetail(String name, String description, MessageKind kind) {
        super(name, description, kind);
    }
    
    public ISOMessageDetail(String name, String description, MessageKind kind, String msgIdentificationFormula) {
        super(name, description, kind, msgIdentificationFormula);
    }
}

package com.opusconsulting.pegasus.format.message.jpos;

import org.jpos.iso.IFA_LCHAR;
import org.jpos.iso.IFA_LLCHAR;
import org.jpos.iso.IFA_LLLCHAR;
import org.jpos.iso.IFA_LLLLCHAR;
import org.jpos.iso.IFA_LLLLLCHAR;
import org.jpos.iso.IFA_LLLLLLCHAR;
import org.jpos.iso.IFB_LLCHAR;
import org.jpos.iso.IFB_LLHCHAR;
import org.jpos.iso.IFB_LLHECHAR;
import org.jpos.iso.IFB_LLLCHAR;
import org.jpos.iso.IFB_LLLHCHAR;
import org.jpos.iso.IFB_LLLHECHAR;
import org.jpos.iso.IFEA_LLCHAR;
import org.jpos.iso.IFEPE_LLCHAR;
import org.jpos.iso.IFEPE_LLLCHAR;
import org.jpos.iso.IFE_LLCHAR;
import org.jpos.iso.IFE_LLLCHAR;
import org.jpos.iso.IFE_LLLLCHAR;
import org.jpos.iso.IF_CHAR;
import org.jpos.iso.IF_ECHAR;
import org.jpos.iso.ISOFieldPackager;

import com.opusconsulting.pegasus.format.iso.metadata.EncodingType;
import com.opusconsulting.pegasus.format.iso.metadata.FieldSizeType;

public class JPOSCharTypeFieldPackagerFactory {

	public static ISOFieldPackager getFieldPackager(String fieldName, EncodingType encodingType, EncodingType lengthEncodingType, int size, FieldSizeType sizeType) {
		if(FieldSizeType.Fixed.equals(sizeType)){
			return fixedCharPackager(fieldName, encodingType, lengthEncodingType, size);
		} else {
			return variableCharPackager(fieldName, encodingType, lengthEncodingType, size);
		}
	}

	private static ISOFieldPackager variableCharPackager(String fieldName, EncodingType encodingType, EncodingType lengthEncodingType,
			int size) {
		switch (encodingType) {
		case ASCII:
			return getASCIIPackager(fieldName, size, lengthEncodingType);
		case BINARY:
			return getBinaryPackager(fieldName, size, lengthEncodingType);
		case EBCDIC:
			return getEBCDICPackager(fieldName, size, lengthEncodingType);
		default:
			return new IF_CHAR();
		}
	}
	
	@SuppressWarnings("deprecation")
	private static ISOFieldPackager fixedCharPackager(String fieldName, EncodingType encodingType, EncodingType lengthEncodingType,
			int size) {
		switch (encodingType) {
		case ASCII:
			return new IF_CHAR(size, fieldName);
		case BINARY:
			return null;
		case EBCDIC:
			return new IF_ECHAR(size, fieldName);
		default:
			return new IF_CHAR(size, fieldName);
		}
	}

	private static ISOFieldPackager getASCIIPackager(String fieldName, int size, EncodingType lengthEncodingTyoe) {
		if(EncodingType.EBCDIC.equals(lengthEncodingTyoe)){
			switch(size) {
			case 2 :
				return new IFEA_LLCHAR(99, fieldName); // it can be IFEMC_LLCHAR, IFEMC_LLLCHAR, IFEP_LLCHAR, IFEP_LLLCHAR
			default :
				return null;
			}
		} else {
			switch(size) {
				case 1 :
					return new IFA_LCHAR(9, fieldName);
				case 2 :
					return new IFA_LLCHAR(99, fieldName); // it can be IFA_FLLCHAR. but if the length padded with fixed length data padded by space
				case 3 :
					return new IFA_LLLCHAR(999, fieldName);
				case 4 :
					return new IFA_LLLLCHAR(9999, fieldName);
				case 5 :
					return new IFA_LLLLLCHAR(99999, fieldName);
				case 6 :
					return new IFA_LLLLLLCHAR(999999, fieldName);
				default :
					return null;
			}
		}
	}
	
	private static ISOFieldPackager getBinaryPackager(String fieldName, int size, EncodingType lengthEncodingType) {
		if(EncodingType.HEX.equals(lengthEncodingType)){
			switch(size) {
			case 2 :
				return new IFB_LLHCHAR(99, fieldName);
			case 3 :
				return new IFB_LLLHCHAR(999, fieldName);
			default :
				return null;
			}
		} else {
			switch(size) {
				case 2 :
					return new IFB_LLCHAR(99, fieldName);
				case 3 :
					return new IFB_LLLCHAR(999, fieldName);
				default :
					return null;
			}
		}
	}
	
	private static ISOFieldPackager getEBCDICPackager(String fieldName, int size, EncodingType lengthEncodingType) {
		if(EncodingType.HEX.equals(lengthEncodingType)){
			switch(size) {
			case 2 :
				return new IFB_LLHECHAR(99, fieldName);
			case 3 :
				return new IFB_LLLHECHAR(999, fieldName);
			default :
				return null;
			}
		} else if(EncodingType.CHAR.equals(lengthEncodingType)){
			switch(size) {
			case 2 :
				return new IFEPE_LLCHAR(99, fieldName);
			case 3 :
				return new IFEPE_LLLCHAR(999, fieldName);
			default :
				return null;
			}
		} else {
			switch(size) {
				case 2 :
					return new IFE_LLCHAR(99, fieldName);
				case 3 :
					return new IFE_LLLCHAR(999, fieldName);
				case 4 :
					return new IFE_LLLLCHAR(9999, fieldName);
				default :
					return null;
			}
		}
	}

}

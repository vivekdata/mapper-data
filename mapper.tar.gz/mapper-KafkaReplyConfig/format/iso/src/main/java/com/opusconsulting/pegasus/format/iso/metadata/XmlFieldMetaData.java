package com.opusconsulting.pegasus.format.iso.metadata;

import java.util.ArrayList;
import java.util.List;

public class XmlFieldMetaData extends FieldDetail<XmlFieldType> {
	XmlFieldType fieldType;
	List<MessageFieldDetail<XmlFieldMetaData>> children;
	String xPath;
	
	public XmlFieldMetaData(String name, String description, XmlFieldType type) {
		super(name, description, type);
		this.children = new ArrayList<>(1);
	}

	public XmlFieldType getFieldType() {
		return fieldType;
	}

	public void setFieldType(XmlFieldType fieldType) {
		this.fieldType = fieldType;
	}

	public List<MessageFieldDetail<XmlFieldMetaData>> getChildren() {
		return children;
	}

	public void setChildren(List<MessageFieldDetail<XmlFieldMetaData>> children) {
		this.children = children;
	}

	public String getxPath() {
		return xPath;
	}

	public void setxPath(String xPath) {
		this.xPath = xPath;
	}
}

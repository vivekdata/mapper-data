package com.opusconsulting.pegasus.format.iso.metadata;

/**
 * Created by saran on 6/10/17.
 */
public enum ExistenceType {
    Mandatory, Optional, Conditional
}

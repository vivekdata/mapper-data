package com.opusconsulting.pegasus.format.iso.metadata;

import java.util.List;

import com.opusconsulting.pegasus.format.NodeFormat;

/**
 * Created by saran on 5/28/17.
 */
public abstract class NodeDetail<T extends MessageDetail> {
    String name;
    String description;

    List<T> messages;
    NodeFormat format;
    
    List<NodeEndPoint> endpoints;

    public NodeDetail() {
    }

    public NodeDetail(String name) {
        this.name = name;
    }

    public NodeDetail(String name, String description) {
        this.name = name;
        this.description = description;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<T> getMessages() {
        return messages;
    }

    public void setMessages(List<T> messages) {
        this.messages = messages;
    }

	public NodeFormat getFormat() {
		return format;
	}

	public void setFormat(NodeFormat format) {
		this.format = format;
	}

	public List<NodeEndPoint> getEndpoints() {
		return endpoints;
	}

	public void setEndpoints(List<NodeEndPoint> endpoints) {
		this.endpoints = endpoints;
	}
}

package com.opusconsulting.pegasus.format;

public enum NodeFormat {
	ISO93, ISO87, XML, JSON;
}

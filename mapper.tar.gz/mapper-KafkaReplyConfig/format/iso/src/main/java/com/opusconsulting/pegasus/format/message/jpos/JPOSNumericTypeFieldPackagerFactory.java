package com.opusconsulting.pegasus.format.message.jpos;

import org.jpos.iso.IFA_AMOUNT;
import org.jpos.iso.IFA_LLBNUM;
import org.jpos.iso.IFA_LLLNUM;
import org.jpos.iso.IFA_LLNUM;
import org.jpos.iso.IFA_NUMERIC;
import org.jpos.iso.IFB_AMOUNT;
import org.jpos.iso.IFB_LLHNUM;
import org.jpos.iso.IFB_LLLHNUM;
import org.jpos.iso.IFB_LLLNUM;
import org.jpos.iso.IFB_LLNUM;
import org.jpos.iso.IFEB_LLLNUM;
import org.jpos.iso.IFEB_LLNUM;
import org.jpos.iso.IFE_LLNUM;
import org.jpos.iso.IF_CHAR;
import org.jpos.iso.ISOFieldPackager;

import com.opusconsulting.pegasus.format.iso.metadata.EncodingType;
import com.opusconsulting.pegasus.format.iso.metadata.FieldSizeType;

public class JPOSNumericTypeFieldPackagerFactory {
	public static ISOFieldPackager getFieldPackager(String fieldName, EncodingType encodingType, EncodingType lengthEncodingType, int size, FieldSizeType sizeType) {
		if(FieldSizeType.Fixed.equals(sizeType)){
			return fixedNumericPackager(fieldName, encodingType, lengthEncodingType, size);
		} else {
			return variableNumericPackager(fieldName, encodingType, lengthEncodingType, size);
		}
	}

	private static ISOFieldPackager variableNumericPackager(String fieldName, EncodingType encodingType, EncodingType lengthEncodingType,
			int size) {
		switch (encodingType) {
		case ASCII:
			return getASCIIPackager(fieldName, size, lengthEncodingType);
		case BINARY:
			return getBinaryPackager(fieldName, size, lengthEncodingType);
		case EBCDIC:
			return getEBCDICPackager(fieldName, size, lengthEncodingType);
		default:
			return new IF_CHAR();
		}
	}
	
	private static ISOFieldPackager fixedNumericPackager(String fieldName, EncodingType encodingType, EncodingType lengthEncodingType,
			int size) {
		switch (encodingType) {
		case ASCII:
			return new IFA_AMOUNT(size, fieldName); // IFA_NUMERIC also can work
		case BINARY:
			return new IFB_AMOUNT(size, fieldName, true); // IFB_NUMERIC also can work
		default:
			return new IFA_NUMERIC(size, fieldName);
		}
	}

	private static ISOFieldPackager getASCIIPackager(String fieldName, int size, EncodingType lengthEncodingTyoe) {
		switch(size) {
			case 2 :
				return new IFA_LLNUM(99, fieldName); // it can be IFA_FLLNUM. but if the length padded with fixed length data padded by space
			case 3 :
				return new IFA_LLLNUM(999, fieldName);
			default :
				return null;
		}
	}
	
	private static ISOFieldPackager getBinaryPackager(String fieldName, int size, EncodingType lengthEncodingType) {
		if(EncodingType.HEX.equals(lengthEncodingType)){
			switch(size) {
			case 2 :
				return new IFB_LLHNUM(99, fieldName, true);
			case 3 :
				return new IFB_LLLHNUM(999, fieldName, true);
			default :
				return null;
			}
		} else if(EncodingType.ASCII.equals(lengthEncodingType)){
			switch(size) {
			case 2 :
				return new IFA_LLBNUM(99, fieldName, true);
			default :
				return null;
			}
		} else {
			switch(size) {
				case 2 :
					return new IFB_LLNUM(99, fieldName, true);
				case 3 :
					return new IFB_LLLNUM(999, fieldName, true);
				default :
					return null;
			}
		}
	}
	
	private static ISOFieldPackager getEBCDICPackager(String fieldName, int size, EncodingType lengthEncodingType) {
		if(EncodingType.BINARY.equals(lengthEncodingType)){
			switch(size) {
			case 2 :
				return new IFEB_LLNUM(99, fieldName);
			case 3 :
				return new IFEB_LLLNUM(999, fieldName);
			default :
				return null;
			}
		} else {
			switch(size) {
				case 2 :
					return new IFE_LLNUM(99, fieldName);
				default :
					return null;
			}
		}
	}
}

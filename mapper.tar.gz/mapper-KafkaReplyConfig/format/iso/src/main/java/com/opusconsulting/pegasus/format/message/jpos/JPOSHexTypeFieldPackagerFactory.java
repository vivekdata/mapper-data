package com.opusconsulting.pegasus.format.message.jpos;

import org.jpos.iso.IFB_HEX;
import org.jpos.iso.IFB_LLHEX;
import org.jpos.iso.ISOFieldPackager;

import com.opusconsulting.pegasus.format.iso.metadata.EncodingType;
import com.opusconsulting.pegasus.format.iso.metadata.FieldSizeType;

public class JPOSHexTypeFieldPackagerFactory {
	public static ISOFieldPackager getFieldPackager(String fieldName, EncodingType encodingType, EncodingType lengthEncodingType, int size, FieldSizeType sizeType) {
		if(FieldSizeType.Fixed.equals(sizeType)){
			return new IFB_HEX(size, fieldName, true);
		} else {
			return new IFB_LLHEX(99, fieldName);
		}
	}
}

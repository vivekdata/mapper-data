package com.opusconsulting.pegasus.format.iso.metadata;

/**
 * Created by saran on 6/10/17.
 */
public enum BitmapType {
    Binary, HexASCII /* Hex EBCDIC - Not supported */
}

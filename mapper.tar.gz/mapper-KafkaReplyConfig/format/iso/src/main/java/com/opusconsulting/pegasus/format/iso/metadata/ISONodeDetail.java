package com.opusconsulting.pegasus.format.iso.metadata;

import java.util.List;

/**
 * Created by saran on 5/28/17.
 */
public class ISONodeDetail extends NodeDetail<ISOMessageDetail> {
    int headerLength;
    int footerLength;
    BitmapType BitmapType;
    List<ISOFieldMetaData> fieldDetails;

    public ISONodeDetail(String name) {
        super(name);
    }

    public ISONodeDetail(String name, String description) {
        super(name, description);
    }

    public int getHeaderLength() {
        return headerLength;
    }

    public void setHeaderLength(int headerLength) {
        this.headerLength = headerLength;
    }

    public int getFooterLength() {
        return footerLength;
    }

    public void setFooterLength(int footerLength) {
        this.footerLength = footerLength;
    }

    public BitmapType getBitmapType() {
        return BitmapType;
    }

    public void setBitmapType(BitmapType bitmapType) {
        this.BitmapType = bitmapType;
    }

    public List<ISOFieldMetaData> getFieldDetails() {
        return fieldDetails;
    }

    public void setFieldDetails(List<ISOFieldMetaData> fieldDetails) {
        this.fieldDetails = fieldDetails;
    }
}

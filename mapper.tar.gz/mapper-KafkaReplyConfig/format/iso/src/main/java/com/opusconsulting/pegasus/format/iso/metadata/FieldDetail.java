package com.opusconsulting.pegasus.format.iso.metadata;

/**
 * Created by saran on 5/28/17.
 */
public class FieldDetail<T> {
    String name;
    String description;
    T type;

    public FieldDetail(String name, String description, T type) {
        this.name = name;
        this.description = description;
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public T getType() {
        return type;
    }

    public void setType(T type) {
        this.type = type;
    }
}

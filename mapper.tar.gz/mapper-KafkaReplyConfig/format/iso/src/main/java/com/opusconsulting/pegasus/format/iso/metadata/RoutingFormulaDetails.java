package com.opusconsulting.pegasus.format.iso.metadata;

public class RoutingFormulaDetails {

	String routingFormula;
	String destinationNode;
	public String getRoutingFormula() {
		return routingFormula;
	}
	public void setRoutingFormula(String routingFormula) {
		this.routingFormula = routingFormula;
	}
	public String getDestinationNode() {
		return destinationNode;
	}
	public void setDestinationNode(String destinationNode) {
		this.destinationNode = destinationNode;
	}
	
	
	
}

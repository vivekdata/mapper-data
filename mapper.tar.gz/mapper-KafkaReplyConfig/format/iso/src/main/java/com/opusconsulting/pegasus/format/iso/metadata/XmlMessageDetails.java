package com.opusconsulting.pegasus.format.iso.metadata;
/**
 * 
 * @author Anup.Warke
 *
 */
public class XmlMessageDetails extends MessageDetail<MessageFieldDetail<XmlFieldMetaData>> {
	public XmlMessageDetails() {
    }

    public XmlMessageDetails(String name, String description, MessageKind kind) {
        super(name, description, kind);
    }
    
    public XmlMessageDetails(String name, String description, MessageKind kind, String msgIdentificationFormula) {
        super(name, description, kind, msgIdentificationFormula);
    }
}

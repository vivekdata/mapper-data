package com.opusconsulting.pegasus.flow;

import java.util.Map;
import java.util.concurrent.CompletableFuture;

public interface IFlowInstance {
    String getName();

    String getDescription();

    <I, R> CompletableFuture<R> process(Map<String, Object> flowProps);

    <I> void resume(IFlowContext context, I previousStepResult, Map<String, Object> flowProps);
}

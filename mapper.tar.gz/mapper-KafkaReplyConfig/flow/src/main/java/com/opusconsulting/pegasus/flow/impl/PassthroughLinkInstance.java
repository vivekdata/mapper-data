package com.opusconsulting.pegasus.flow.impl;

import java.util.Map;

import com.opusconsulting.pegasus.flow.IFlowContext;

public class PassthroughLinkInstance extends AbstractLinkInstance {
	/**
	 * This method check if the context got the information about exception during the step
	 * execution
	 */
	@Override
	public <I> boolean check(IFlowContext context, I previousStepResult, Map<String, Object> flowProps) {
		//check if error occured
		boolean errorInStepExecution = context.get(AbstractStepInstance.ERROR_IN_STEP_EXEC) == null ? false
				: context.get(AbstractStepInstance.ERROR_IN_STEP_EXEC);
		if(errorInStepExecution){
			return false;
		} else {
			return true;
		}
	}
}

package com.opusconsulting.pegasus.flow.impl;

import com.opusconsulting.pegasus.flow.ILinkInstance;
import com.opusconsulting.pegasus.flow.IFlowContext;
import com.opusconsulting.pegasus.flow.IFlowInstance;
import com.opusconsulting.pegasus.flow.IStepInstance;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

public class DefaultFlowInstance implements IFlowInstance {

    String name;
    String description;
    StepContainer startStepContainer;

    public DefaultFlowInstance(String name, String startStepName, List<IStepInstance> stepInstances, List<ILinkInstance> linkInstances) {
        this(name, name, startStepName, stepInstances, linkInstances);
    }

    public DefaultFlowInstance(String name, String description, String startStepName, List<IStepInstance> stepInstances, List<ILinkInstance> linkInstances) {
        this.name = name;
        this.description = description;

        startStepContainer = getStartStepContainer(startStepName, stepInstances, linkInstances);
    }

    private StepContainer getStartStepContainer(String startStepName, List<IStepInstance> stepInstances, List<ILinkInstance> linkInstances) {
        Map<String, StepContainer> stepContainers = stepInstances.stream()
                .map(StepContainer::new)
                .collect(Collectors.toMap(c -> c.instance.getName(), c -> c));

        linkInstances.stream()
                .map(instance -> new LinkContainer(
                        stepContainers.get(instance.getSourceStepName()),
                        instance,
                        stepContainers.get(instance.getDestinationStepName())))
                .collect(Collectors.toList());

        return stepContainers.get(startStepName);
    }

    @Override
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String getDescription() {
        return description;
    }

    protected IFlowContext createContext() {
        return new DefaultFlowContext(this, false);
    }

    @Override
    public <I, R> CompletableFuture<R> process(Map<String, Object> flowProps) {
        IFlowContext context = createContext();

        //TODO asynchronous handling
        Object retVal = doProcess(context, null, startStepContainer, flowProps);

        return CompletableFuture.completedFuture((R) retVal);
    }

    private <I, R> R doProcess(IFlowContext context, I previousStepResult, StepContainer stepContainer,
                               Map<String, Object> flowProps) {
        Object result = stepContainer.instance.process(context, previousStepResult, flowProps);

        for (LinkContainer linkContainer : stepContainer.getLinkContainers()) {
            boolean canPass = linkContainer.linkInstance.check(context, result, flowProps);
            if (canPass) {
                return doProcess(context, result, linkContainer.destination, flowProps);
            }
        }
        stepContainer.instance.onFlowComplete(context, previousStepResult, flowProps);
        return (R) result;
    }


    @Override
    public <I> void resume(IFlowContext context, I previousStepResult, Map<String, Object> flowProps) {
        //TODO
    }

    public void setDescription(String description) {
        this.description = description;
    }


    class StepContainer {
        IStepInstance instance;
        List<LinkContainer> linkContainers = new ArrayList<>();

        public StepContainer(IStepInstance instance) {
            this.instance = instance;
        }

        void addLinkContainer(LinkContainer linkContainer) {
            linkContainers.add(linkContainer);
        }

        public List<LinkContainer> getLinkContainers() {
            return linkContainers;
        }
    }

    class LinkContainer {
        StepContainer source;
        StepContainer destination;
        ILinkInstance linkInstance;

        public LinkContainer(StepContainer source, ILinkInstance linkInstance, StepContainer destination) {
            this.source = source;
            this.linkInstance = linkInstance;
            this.destination = destination;

            source.addLinkContainer(this);
        }
    }

}

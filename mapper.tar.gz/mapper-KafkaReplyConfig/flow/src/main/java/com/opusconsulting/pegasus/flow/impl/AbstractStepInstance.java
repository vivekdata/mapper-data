package com.opusconsulting.pegasus.flow.impl;

import com.opusconsulting.pegasus.flow.metadata.IStepMetaData;
import com.opusconsulting.pegasus.flow.IFlowContext;
import com.opusconsulting.pegasus.flow.IStepInstance;
import com.opusconsulting.pegasus.flow.IStepMetaDataAware;

import java.util.Map;

public abstract class AbstractStepInstance implements IStepInstance, IStepMetaDataAware {
    public static final String ERROR_IN_STEP_EXEC = "isErrorInStepExecution";
    public static final String ERROR = "error";
    
	String name;
    String description;

    transient IStepMetaData metaData;

    @Override
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public <I> void onFlowComplete(IFlowContext context, I lastStepResult, Map<String, Object> flowProps) {
        boolean exceptionOccured = (context.get(ERROR_IN_STEP_EXEC) == null) ? false : context.get(ERROR_IN_STEP_EXEC);
    	if(exceptionOccured){
	    	flowProps.put(ERROR_IN_STEP_EXEC, context.get(ERROR_IN_STEP_EXEC));
	        flowProps.put(ERROR, context.get(ERROR));
    	}
    }

    public void setMetaData(IStepMetaData metaData) {
        this.metaData = metaData;
    }
    
    public <I> void onError(IFlowContext context, I lastStepResult, Map<String, Object> flowProps, Throwable throwable){
    	context.put(ERROR_IN_STEP_EXEC, true);
    	context.put(ERROR, throwable);
    }
}

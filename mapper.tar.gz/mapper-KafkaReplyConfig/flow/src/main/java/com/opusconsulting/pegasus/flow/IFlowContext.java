package com.opusconsulting.pegasus.flow;

public interface IFlowContext {
    <V> V get(String key);

    <V> void put(String key, V value);

    <V> V remove(String key);

    <R> void next(R result);
}

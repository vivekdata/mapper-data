package com.opusconsulting.pegasus.flow.metadata.impl;

import com.opusconsulting.pegasus.flow.metadata.LinkInstanceInfo;
import com.opusconsulting.pegasus.flow.metadata.IFlowMetaData;
import com.opusconsulting.pegasus.flow.metadata.StepInstanceInfo;

import java.util.List;

public class FlowMetaData extends StepMetaData implements IFlowMetaData {
    String startStepInstanceName;
    List<StepInstanceInfo> stepInstancesInfo;
    List<LinkInstanceInfo> linkInstancesInfo;

    @Override
    public String getStartStepInstanceName() {
        return startStepInstanceName;
    }

    public FlowMetaData setStartStepInstanceName(String startStepInstanceName) {
        this.startStepInstanceName = startStepInstanceName;
        return this;
    }

    @Override
    public List<StepInstanceInfo> getStepInstancesInfo() {
        return stepInstancesInfo;
    }

    public FlowMetaData setStepInstancesInfo(List<StepInstanceInfo> stepInstancesInfo) {
        this.stepInstancesInfo = stepInstancesInfo;
        return this;
    }

    @Override
    public List<LinkInstanceInfo> getLinkInstancesInfo() {
        return linkInstancesInfo;
    }

    public FlowMetaData setLinkInstancesInfo(List<LinkInstanceInfo> linkInstancesInfo) {
        this.linkInstancesInfo = linkInstancesInfo;
        return this;
    }

}

package com.opusconsulting.pegasus.flow.metadata;

import java.util.Map;
import java.util.function.Function;

public class LinkInstanceInfo {
    String description;
    String sourceStepInstanceName;
    String destinationStepInstanceName;
    Function<?, Boolean> condition;

    Map<String, Object> properties;
    Map<String, Object> inputs;

    public String getDescription() {
        return description;
    }

    public LinkInstanceInfo setDescription(String description) {
        this.description = description;
        return this;
    }

    public String getSourceStepInstanceName() {
        return sourceStepInstanceName;
    }

    public LinkInstanceInfo setSourceStepInstanceName(String sourceStepInstanceName) {
        this.sourceStepInstanceName = sourceStepInstanceName;
        return this;
    }

    public String getDestinationStepInstanceName() {
        return destinationStepInstanceName;
    }

    public LinkInstanceInfo setDestinationStepInstanceName(String targetStepInstanceName) {
        this.destinationStepInstanceName = targetStepInstanceName;
        return this;
    }

    public Function<?, Boolean> getCondition() {
        return condition;
    }

    public <T> void setCondition(Function<T, Boolean> condition) {
        this.condition = condition;
    }

    public Map<String, Object> getProperties() {
        return properties;
    }

    public LinkInstanceInfo setProperties(Map<String, Object> properties) {
        this.properties = properties;
        return this;
    }

    public Map<String, Object> getInputs() {
        return inputs;
    }

    public LinkInstanceInfo setInputs(Map<String, Object> inputs) {
        this.inputs = inputs;
        return this;

    }

}

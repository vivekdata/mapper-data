package com.opusconsulting.pegasus.flow.resource;

import org.springframework.stereotype.Component;

@Component
public class ConstantFRHandler implements IFRHandler {
    public final static String TYPE = "const";
    private final static String STRING_TYPE = "string";
    private final static String LONG_TYPE = "long";

    @Override
    public boolean canHandle(FRI identifier) {
        return identifier.getType().equalsIgnoreCase(TYPE);
    }

    @Override
    public <T> T get(FRI identifier) throws Exception {
        String value = identifier.getValue();
        int dataTypeIndex = value.indexOf("/");

        String dataType;
        String data;
        if (dataTypeIndex == -1) {
            dataType = STRING_TYPE;
            data = value;
        } else {
            dataType = value.substring(0, dataTypeIndex);
            data = value.substring(dataTypeIndex + 1);
        }
        return convertTo(dataType, data);
    }

    private <T> T convertTo(String dataType, String data) {
        if (dataType.equalsIgnoreCase(STRING_TYPE)) {
            return (T) data;
        } else if (dataType.equalsIgnoreCase(LONG_TYPE)) {
            return (T) Long.valueOf(data);
        }

        return null;
    }

}

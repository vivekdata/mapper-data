package com.opusconsulting.pegasus.flow;

import com.opusconsulting.pegasus.flow.metadata.StepInstanceInfo;

public interface IStepInstanceCreator {
    IStepInstance create(StepInstanceInfo info);
}

package com.opusconsulting.pegasus.flow.metadata;

import java.util.Map;

public class StepInstanceInfo {
    String name;
    String description;
    String stepName;

    Map<String, Object> properties;
    Map<String, Object> inputs;

    public String getName() {
        return name;
    }

    public StepInstanceInfo setName(String name) {
        this.name = name;
        return this;
    }

    public String getDescription() {
        if (description == null) {
            return name;
        }
        return description;
    }

    public StepInstanceInfo setDescription(String description) {
        this.description = description;
        return this;
    }

    public String getStepName() {
        return stepName;
    }

    public StepInstanceInfo setStepName(String stepName) {
        this.stepName = stepName;
        return this;
    }

    public Map<String, Object> getProperties() {
        return properties;
    }

    public StepInstanceInfo setProperties(Map<String, Object> properties) {
        this.properties = properties;
        return this;
    }

    public Map<String, Object> getInputs() {
        return inputs;
    }

    public StepInstanceInfo setInputs(Map<String, Object> inputs) {
        this.inputs = inputs;
        return this;
    }
}

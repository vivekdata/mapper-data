package com.opusconsulting.pegasus.flow.resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class FRFactory {

    @Autowired
    List<IFRHandler> handlers;

    public <T> T getValue(FRI identifier) throws Exception {
        for (IFRHandler handler : handlers) {
            if (handler.canHandle(identifier)) {
                return handler.get(identifier);
            }
        }

        throw new Exception("Invalid FRI " + identifier);
    }

}

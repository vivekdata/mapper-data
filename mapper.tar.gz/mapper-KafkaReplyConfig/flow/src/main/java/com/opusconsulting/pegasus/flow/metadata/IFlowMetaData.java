package com.opusconsulting.pegasus.flow.metadata;

import java.util.List;

public interface IFlowMetaData extends IStepMetaData {
    String getStartStepInstanceName();

    List<StepInstanceInfo> getStepInstancesInfo();

    List<LinkInstanceInfo> getLinkInstancesInfo();
}

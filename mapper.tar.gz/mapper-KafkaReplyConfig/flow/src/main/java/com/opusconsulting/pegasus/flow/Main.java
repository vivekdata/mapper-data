package com.opusconsulting.pegasus.flow;

import com.opusconsulting.pegasus.flow.impl.FlowFactory;
import com.opusconsulting.pegasus.flow.metadata.IStepMetaData;
import com.opusconsulting.pegasus.flow.metadata.LinkInstanceInfo;
import com.opusconsulting.pegasus.flow.metadata.StepInstanceInfo;
import com.opusconsulting.pegasus.flow.metadata.impl.FlowMetaData;
import com.opusconsulting.pegasus.flow.metadata.impl.StepMetaData;
import com.opusconsulting.pegasus.flow.resource.FRI;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

@Configuration
public class Main {

    @Bean
    public static IStepMetaData createEchoStepMetaData() {
        return new StepMetaData().setName("echo").setType(EchoStepInstance.class);
    }

    @Bean
    public static IStepMetaData createEcho2StepMetaData() {
        return new StepMetaData().setName("echo_ex").setType(EchoStepInstance.class);
    }

    public static void main(String[] args) throws Exception {
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext(new String[]{"spring.xml"});

        IStepInstanceCreator stepInstanceCreator = (IStepInstanceCreator) applicationContext.getBean("stepInstanceCreator");

        StepInstanceInfo stepInstanceInfo = new StepInstanceInfo();
        stepInstanceInfo.setName("echo_id_1");
        stepInstanceInfo.setStepName("echo");
        Map<String, Object> prop = new HashMap<>();
        stepInstanceInfo.setProperties(prop);

        prop.put("msg", "[echo] instance 1");
        IStepInstance instance = stepInstanceCreator.create(stepInstanceInfo);
        System.out.println(instance.hashCode());
        instance.process(null, null, null);

        prop.put("msg", FRI.create("const://string/[echo] instance 2"));
        IStepInstance instance1 = stepInstanceCreator.create(stepInstanceInfo);
        System.out.println(instance1.hashCode());
        instance1.process(null, null, null);

        StepInstanceInfo stepInstanceInfo2 = new StepInstanceInfo();
        stepInstanceInfo2.setName("echo_id_2");
        stepInstanceInfo2.setStepName("echo");
        Map<String, Object> prop2 = new HashMap<>();
        prop2.put("msg", "[echo] instance new 2");
        stepInstanceInfo2.setProperties(prop2);

        FlowFactory factory = (FlowFactory) applicationContext.getBean("flowFactory");

        LinkInstanceInfo linkInstanceInfo = new LinkInstanceInfo();
        linkInstanceInfo.setDescription("Passthro")
                .setSourceStepInstanceName("echo_id_1")
                .setDestinationStepInstanceName("echo_id_2");

        FlowMetaData metaData = new FlowMetaData();
        metaData.setName("PrintFlow");
        metaData.setStartStepInstanceName("echo_id_1")
                .setStepInstancesInfo(Arrays.asList(stepInstanceInfo, stepInstanceInfo2))
                .setLinkInstancesInfo(Arrays.asList(linkInstanceInfo));
        factory.register(metaData);
        factory.init();

        IFlowInstance printFlow = factory.createInstance("PrintFlow");
        printFlow.process(null);
    }
}

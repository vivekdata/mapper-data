package com.opusconsulting.pegasus.flow.resource;

public interface IFRHandler {
    boolean canHandle(FRI identifier);

    <T> T get(FRI identifier) throws Exception;
}

package com.opusconsulting.pegasus.flow.metadata;

public class FieldMetaData {
    private String accessId;
    private String name;
    private String description;
    private Class<?> type;

    public FieldMetaData() {
    }

    public <T> FieldMetaData(String accessId, String name, String description, Class<T> type) {
        this.name = name;
        this.description = description;
        this.type = type;
    }

    public String getAccessId() {
        return accessId;
    }

    public void setAccessId(String accessId) {
        this.accessId = accessId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public <T> Class<T> getType() {
        return (Class<T>) type;
    }

    public <T> void setType(Class<T> type) {
        this.type = type;
    }
}

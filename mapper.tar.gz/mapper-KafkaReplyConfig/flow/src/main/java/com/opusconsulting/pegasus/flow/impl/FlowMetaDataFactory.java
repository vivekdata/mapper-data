package com.opusconsulting.pegasus.flow.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.opusconsulting.pegasus.flow.metadata.IFlowMetaData;

@Component
public class FlowMetaDataFactory {

	@Autowired(required=false)
	private List<IFlowMetaData> preDefinedMetaDatas;
	
    Map<String, IFlowMetaData> metaDatas = new HashMap<>();
	
	@PostConstruct
    void init() {
        if (preDefinedMetaDatas != null) {
            preDefinedMetaDatas.forEach(metaData -> metaDatas.put(metaData.getName(), metaData));
        }
    }

    public void register(IFlowMetaData metaData) {
        metaDatas.put(metaData.getName(), metaData);
    }

    public IFlowMetaData getFlowMetaData(String name) {
        return metaDatas.get(name);
    }
}

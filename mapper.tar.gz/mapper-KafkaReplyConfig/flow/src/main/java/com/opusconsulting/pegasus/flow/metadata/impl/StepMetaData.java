package com.opusconsulting.pegasus.flow.metadata.impl;

import com.opusconsulting.pegasus.flow.metadata.FieldMetaData;
import com.opusconsulting.pegasus.flow.metadata.IStepMetaData;

import java.util.List;

public class StepMetaData implements IStepMetaData {
    String name;
    String description;
    List<FieldMetaData> properties;
    List<FieldMetaData> inputs;
    FieldMetaData output;
    Class<?> type;

    @Override
    public String getName() {
        return name;
    }

    public StepMetaData setName(String name) {
        this.name = name;
        return this;
    }

    @Override
    public String getDescription() {
        return description;
    }

    public StepMetaData setDescription(String description) {
        this.description = description;
        return this;
    }

    @Override
    public List<FieldMetaData> getProperties() {
        return properties;
    }

    public StepMetaData setProperties(List<FieldMetaData> properties) {
        this.properties = properties;
        return this;
    }

    @Override
    public List<FieldMetaData> getInputs() {
        return inputs;
    }

    public StepMetaData setInputs(List<FieldMetaData> inputs) {
        this.inputs = inputs;
        return this;
    }

    @Override
    public FieldMetaData getOutput() {
        return output;
    }

    public StepMetaData setOutput(FieldMetaData output) {
        this.output = output;
        return this;
    }

    @Override
    public Class<?> getType() {
        return type;
    }

    public StepMetaData setType(Class<?> type) {
        this.type = type;
        return this;
    }

    @Override
    public String getBeanName() {
        return null;
    }

}

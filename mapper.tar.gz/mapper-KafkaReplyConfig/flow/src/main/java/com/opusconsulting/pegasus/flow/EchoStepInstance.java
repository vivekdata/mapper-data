package com.opusconsulting.pegasus.flow;

import com.opusconsulting.pegasus.flow.impl.AbstractStepInstance;
import com.opusconsulting.pegasus.flow.impl.StepMetaDataFactory;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import java.util.Map;

public class EchoStepInstance extends AbstractStepInstance implements ApplicationContextAware {

    @Inject
    StepMetaDataFactory factory;

    String msg;

    @PostConstruct
    void init() {
        System.out.println("[echo] post construct");
    }

    @Override
    public <I, R> R process(IFlowContext context, I previousStepResult, Map<String, Object> flowProps) {
        System.out.println(msg + ((previousStepResult != null) ? " - " + previousStepResult : ""));
        return (R) msg;
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        System.out.println("[echo] setApplicationContext invoked");
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}

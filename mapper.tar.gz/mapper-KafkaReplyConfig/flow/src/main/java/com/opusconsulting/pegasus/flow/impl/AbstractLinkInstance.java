package com.opusconsulting.pegasus.flow.impl;

import com.opusconsulting.pegasus.flow.ILinkInstance;
import com.opusconsulting.pegasus.flow.IFlowContext;

import java.util.Map;

public abstract class AbstractLinkInstance implements ILinkInstance {
    String description;
    String sourceStepName;
    String destinationStepName;

    @Override
    public String getDescription() {
        return description;
    }

    public AbstractLinkInstance setDescription(String description) {
        this.description = description;
        return this;
    }

    @Override
    public String getSourceStepName() {
        return sourceStepName;
    }

    public AbstractLinkInstance setSourceStepName(String sourceStepName) {
        this.sourceStepName = sourceStepName;
        return this;
    }

    @Override
    public String getDestinationStepName() {
        return destinationStepName;
    }

    public AbstractLinkInstance setDestinationStepName(String destinationStepName) {
        this.destinationStepName = destinationStepName;
        return this;
    }

    @Override
    public int getPriority() {
        return -1;
    }

    @Override
    public <I> boolean check(IFlowContext context, I previousStepResult, Map<String, Object> flowProps) {
        return true;
    }
}

package com.opusconsulting.pegasus.flow.impl;

import com.opusconsulting.pegasus.flow.IFlowInstance;
import com.opusconsulting.pegasus.flow.ILinkInstance;
import com.opusconsulting.pegasus.flow.IStepInstance;
import com.opusconsulting.pegasus.flow.IStepInstanceCreator;
import com.opusconsulting.pegasus.flow.metadata.IFlowMetaData;
import com.opusconsulting.pegasus.flow.metadata.LinkInstanceInfo;
import com.opusconsulting.pegasus.flow.*;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Component
public class FlowFactory implements ApplicationContextAware {

    Map<String, IFlowMetaData> flowMetaDatas = new HashMap<>();
    Map<String, IFlowInstance> flowInstances;

    ApplicationContext applicationContext;

    @Inject
    IStepInstanceCreator stepInstanceCreator;

    public void register(IFlowMetaData metaData) {
        flowMetaDatas.put(metaData.getName(), metaData);
    }

    public void init() {
        flowInstances = flowMetaDatas.values().stream()
                .map(this::createFlowInstance)
                .collect(Collectors.toMap(instance -> instance.getName(), instance -> instance));
    }

    private IFlowInstance createFlowInstance(IFlowMetaData metaData) {
        List<IStepInstance> stepInstances = metaData.getStepInstancesInfo().stream()
                .map(stepInstanceCreator::create)
                .collect(Collectors.toList());

        List<ILinkInstance> linkInstances = metaData.getLinkInstancesInfo().stream()
                .map(this::createLinkInstance)
                .collect(Collectors.toList());

        return new DefaultFlowInstance(metaData.getName(), metaData.getDescription(),
                metaData.getStartStepInstanceName(), stepInstances, linkInstances);
    }

    private ILinkInstance createLinkInstance(LinkInstanceInfo linkInstanceInfo) {
        return new PassthroughLinkInstance()
                .setDescription(linkInstanceInfo.getDescription())
                .setSourceStepName(linkInstanceInfo.getSourceStepInstanceName())
                .setDestinationStepName(linkInstanceInfo.getDestinationStepInstanceName());
    }

    public IFlowInstance createInstance(String name) {
        return flowInstances.get(name);
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }
}

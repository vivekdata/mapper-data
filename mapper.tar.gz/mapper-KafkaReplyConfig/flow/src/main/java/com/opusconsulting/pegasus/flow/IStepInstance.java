package com.opusconsulting.pegasus.flow;

import java.util.Map;

public interface IStepInstance {
    String getName();

    String getDescription();

    <I, R> R process(IFlowContext context, I previousStepResult, Map<String, Object> flowProps);

    <I> void onFlowComplete(IFlowContext context, I lastStepResult, Map<String, Object> flowProps);
}

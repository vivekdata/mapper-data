package com.opusconsulting.pegasus.flow.impl;

import com.opusconsulting.pegasus.flow.IStepInstance;
import com.opusconsulting.pegasus.flow.IStepInstanceCreator;
import com.opusconsulting.pegasus.flow.metadata.IStepMetaData;
import com.opusconsulting.pegasus.flow.metadata.StepInstanceInfo;
import com.opusconsulting.pegasus.flow.resource.FRFactory;
import com.opusconsulting.pegasus.flow.resource.FRI;
import org.apache.commons.beanutils.PropertyUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.util.HashMap;
import java.util.Map;

@Component
public class StepInstanceCreator implements IStepInstanceCreator, ApplicationContextAware {

    ApplicationContext applicationContext;

    @Inject
    StepMetaDataFactory factory;

    @Inject
    FRFactory frFactory;

    @Override
    public IStepInstance create(StepInstanceInfo info) {
        IStepMetaData stepMetaData = factory.getStepMetaData(info.getStepName());

        Class<?> type = stepMetaData.getType();

        AutowireCapableBeanFactory autowireCapableBeanFactory = applicationContext.getAutowireCapableBeanFactory();

        try {
            IStepInstance instance = BeanUtils.instantiate((Class<IStepInstance>) type);

            Map<String, Object> properties = info.getProperties();
            if (properties == null) {
                properties = new HashMap<>();
            } else {
                properties = new HashMap<>(properties);
            }
            properties.put("name", info.getName());

            for (Map.Entry<String, Object> entry : properties.entrySet()) {
                Object entryValue = entry.getValue();
                if (entryValue instanceof FRI) {
                    entryValue = frFactory.getValue((FRI) entryValue);
                }
                PropertyUtils.setProperty(instance, entry.getKey(), entryValue);
            }

            autowireCapableBeanFactory.autowireBean(instance);

            autowireCapableBeanFactory.initializeBean(instance, type.getName());

            return instance;
        } catch (Exception ex) {
            throw new RuntimeException(ex.getMessage(), ex.getCause());
        }
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }
}

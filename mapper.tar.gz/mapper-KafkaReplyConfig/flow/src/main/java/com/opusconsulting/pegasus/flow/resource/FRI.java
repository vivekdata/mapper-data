package com.opusconsulting.pegasus.flow.resource;

public class FRI {
    private final static String DEFAULT_TYPE = "const";
    private final static String RESOURCE_SEPARATOR = "://";

    private String resource;
    private String type;
    private String value;

    private FRI(String resource) {
        this.resource = resource;

        parse(resource);
    }

    private void parse(String resource) {
        int matchIndex = resource.indexOf(RESOURCE_SEPARATOR);
        if (matchIndex == -1) {
            this.type = DEFAULT_TYPE;
            this.value = resource.substring(0);
        } else {
            this.type = resource.substring(0, matchIndex);
            this.value = resource.substring(matchIndex + RESOURCE_SEPARATOR.length());
        }
    }

    public static FRI create(String resource) {
        return new FRI(resource);
    }


    public String getType() {
        return this.type;
    }

    public String getValue() {
        return this.value;
    }
}

package com.opusconsulting.pegasus.flow.metadata;

import java.util.List;

public interface IStepMetaData {
    String getName();

    String getDescription();

    List<FieldMetaData> getProperties();

    List<FieldMetaData> getInputs();

    FieldMetaData getOutput();

    Class<?> getType();

    String getBeanName();   // Need to find a right place to store this information
}

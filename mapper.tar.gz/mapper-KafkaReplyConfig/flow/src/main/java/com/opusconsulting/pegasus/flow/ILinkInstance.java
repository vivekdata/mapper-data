package com.opusconsulting.pegasus.flow;

import java.util.Map;

public interface ILinkInstance {
    String getDescription();

    int getPriority();

    String getSourceStepName();

    String getDestinationStepName();

    <I> boolean check(IFlowContext context, I previousStepResult, Map<String, Object> flowProps);
}

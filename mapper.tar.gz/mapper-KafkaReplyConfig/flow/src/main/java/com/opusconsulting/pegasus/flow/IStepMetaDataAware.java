package com.opusconsulting.pegasus.flow;

import com.opusconsulting.pegasus.flow.metadata.IStepMetaData;

public interface IStepMetaDataAware {

    void setMetaData(IStepMetaData metaData);

}

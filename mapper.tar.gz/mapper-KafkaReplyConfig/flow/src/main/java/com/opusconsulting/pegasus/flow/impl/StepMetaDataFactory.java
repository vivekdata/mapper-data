package com.opusconsulting.pegasus.flow.impl;

import com.opusconsulting.pegasus.flow.metadata.IStepMetaData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class StepMetaDataFactory {

    @Autowired(required = false)
    List<IStepMetaData> preDefinedMetaDatas;

    Map<String, IStepMetaData> metaDatas = new HashMap<>();

    @PostConstruct
    void init() {
        if (preDefinedMetaDatas != null) {
            preDefinedMetaDatas.forEach(metaData -> metaDatas.put(metaData.getName(), metaData));
        }
    }

    public void register(IStepMetaData metaData) {
        metaDatas.put(metaData.getName(), metaData);
    }

    public IStepMetaData getStepMetaData(String name) {
        return metaDatas.get(name);
    }
}

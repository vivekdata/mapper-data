package com.opusconsulting.pegasus.flow.impl;

import com.opusconsulting.pegasus.flow.IFlowContext;
import com.opusconsulting.pegasus.flow.IFlowInstance;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class DefaultFlowContext implements IFlowContext {
    IFlowInstance flowInstance;
    Map<String, Object> datas;

    public DefaultFlowContext(IFlowInstance flowInstance, boolean threadSafe) {
        this.flowInstance = flowInstance;
        datas = (threadSafe) ? new ConcurrentHashMap<>() : new HashMap<>();
    }

    @Override
    public <V> V get(String key) {
        return (V) datas.get(key);
    }

    @Override
    public <V> void put(String key, V value) {
        datas.put(key, value);
    }

    @Override
    public <V> V remove(String key) {
        return (V) datas.remove(key);
    }

    @Override
    public <R> void next(R result) {
//        flowInstance.resume(this, result);
    }
}

package com.opusconsulting.pegasus.virtualization.rules;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.inject.Inject;

import org.apache.commons.beanutils.PropertyUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;


@Component
public class TreeRuleInstanceCreator implements IRuleInstanceCreator, ApplicationContextAware {

	private ApplicationContext applicationContext;

    @Inject
    RuleMetaDataFactory factory;
	
    @Override
	public IRuleInstance create(TreeRuleInstanceInfo info) {
    	if(info == null)
    		return null;
    	
        AutowireCapableBeanFactory autowireCapableBeanFactory = applicationContext.getAutowireCapableBeanFactory();

        try {
    		IRuleMetaData ruleMetaData = factory.getRuleMetaData(info.getRuleName());

			List<IRuleInstance> childRules = info.getChildRules().stream().map(this::create)
					.collect(Collectors.toList());
    		
    		IRuleInstance nextRuleInstance = create(info.getNextRuleInfo());
    		      
            Class<?> type = ruleMetaData.getType();

			IRuleInstance instance = (IRuleInstance) BeanUtils.instantiateClass(
					type.getConstructor(new Class<?>[] { java.util.List.class, IRuleInstance.class }), childRules,
					nextRuleInstance);

            Map<String, Object> properties = info.getProperties();
            if (properties == null) {
                properties = new HashMap<>();
            } else {
                properties = new HashMap<>(properties);
            }
//            properties.put("name", info.getName());

            for (Map.Entry<String, Object> entry : properties.entrySet()) {
                PropertyUtils.setProperty(instance, entry.getKey(), entry.getValue());
            }

            autowireCapableBeanFactory.autowireBean(instance);

            autowireCapableBeanFactory.initializeBean(instance, type.getName());

            return instance;
        } catch (Exception ex) {
            throw new RuntimeException(ex.getMessage(), ex.getCause());
        }
	}
    
	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		this.applicationContext = applicationContext;
	}

}

package com.opusconsulting.pegasus.virtualization;

import java.util.Arrays;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import com.opusconsulting.pegasus.common.event.IEventPublisher;
import com.opusconsulting.pegasus.event.impl.EventConfig;
import com.opusconsulting.pegasus.event.impl.EventContext;
import com.opusconsulting.pegasus.event.impl.EventManager;
import com.opusconsulting.pegasus.event.impl.EventUseType;
import com.opusconsulting.pegasus.event.impl.ThreadBasedEventConfig;
import com.opusconsulting.pegasus.runtime.RuntimeMain;
import com.opusconsulting.pegasus.virtualization.event.VirtualizationEventSubjects;
import org.springframework.kafka.annotation.EnableKafka;

@Configuration
@Import({RuntimeMain.class, VirtualStepConfiguration.class, VirtualizationEventHandlerConfiguration.class})
@RefreshScope
@EnableKafka
@SpringBootApplication
public class Main {
	static EventManager eventManager;//TODO need to think about this static.
	
	private static ApplicationContext applicationContext;
	
	public static void initEventManager() {
		eventManager = applicationContext.getBean(EventManager.class);
		EventConfig config = new ThreadBasedEventConfig("SPECIAL", EventUseType.UseBoth);
		Arrays.asList(VirtualizationEventSubjects.values()).stream().forEach(eventSubject -> {
			config.addSubject(eventSubject.name());
		});
		eventManager.addConfig(config);
		eventManager.init();
	}
	
	public static void main(String[] args) {
		//applicationContext = new AnnotationConfigApplicationContext(Main.class);
		applicationContext = SpringApplication.run(Main.class, args);
		//applicationContext = new AnnotationConfigApplicationContext(Main.class);
		initEventManager();
		
//		((IEventPublisher)applicationContext.getBean("startVirtualServerEventPublisher")).publish("START");
		
		EventContext eventContext = new EventContext();
		eventContext.set("nodeJSONFilePath", applicationContext.getBean("nodeJSONFilePath"));
		eventContext.set("workFlowJSONFilePath", applicationContext.getBean("workFlowJSONFilePath"));
		eventContext.set("virtulizationJSONFilePath", applicationContext.getBean("virtulizationJSONFilePath"));
		((IEventPublisher)applicationContext.getBean("vitualEnvStartupActivityEventPublisher")).publish("BOOT", eventContext);
	}
}

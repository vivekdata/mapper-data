package com.opusconsulting.pegasus.virtualization.rules;

public class RuleMetaData implements IRuleMetaData {
	String name;
	Class<?> type;
	
	@Override
	public Class<?> getType() {
		return this.type;
	}

	@Override
	public String getName() {
		return this.name;
	}

	public RuleMetaData setName(String name) {
		this.name = name;
		return this;
	}

	public RuleMetaData setType(Class<?> type) {
		this.type = type;
		return this;
	}
}

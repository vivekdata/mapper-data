package com.opusconsulting.pegasus.virtualization.rules.impl;

import java.util.List;
import java.util.Map;

import com.opusconsulting.pegasus.runtime.DefaultIMessage;
import com.opusconsulting.pegasus.runtime.mapper.layman.IMessageMetaData;
import com.opusconsulting.pegasus.runtime.mapper.layman.IMessageMetaDataImpl;
import com.opusconsulting.pegasus.virtualization.rules.IRuleInstance;

public class MessageMetaDataDecisionRule extends AbstractTreeRuleInstance {
	
	String messageName;
	boolean request;

	public MessageMetaDataDecisionRule(List<IRuleInstance> childRules, IRuleInstance nextInstance) {
		super(childRules, nextInstance);
	}

	@Override
	public <I> boolean execute(I result, Map<String, Object> ruleProps) {
		final DefaultIMessage message = (DefaultIMessage) result;
		final IMessageMetaData metaData = new IMessageMetaDataImpl(this.messageName, this.request);
		message.setMetaData(metaData);
		return true;
	}

	public void setMessageName(String messageName) {
		this.messageName = messageName;
	}

	public void setRequest(boolean request) {
		this.request = request;
	}
}

package com.opusconsulting.pegasus.virtualization.event.handlers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import com.opusconsulting.pegasus.channel.tcp.TCPChannelMessage;
import com.opusconsulting.pegasus.channel.tcp.TCPClientChannel;
import com.opusconsulting.pegasus.channel.tcp.TCPClientConfig;
import com.opusconsulting.pegasus.common.event.IEventContext;
import com.opusconsulting.pegasus.common.event.IEventHandler;
import com.opusconsulting.pegasus.common.event.IEventMessage;
import com.opusconsulting.pegasus.event.impl.EventContext;
import com.opusconsulting.pegasus.event.impl.EventMessage;
import com.opusconsulting.pegasus.format.iso.metadata.EndPointDetail;
import com.opusconsulting.pegasus.format.iso.metadata.EndPointType;
import com.opusconsulting.pegasus.format.iso.metadata.EndpointProtocol;
import com.opusconsulting.pegasus.runtime.IConstants;

@Component
public class MapperHostCommunicationEventHandler implements IEventHandler{
	private static final Logger _logger = LoggerFactory.getLogger(MapperHostCommunicationEventHandler.class);
	public static final String SERIALIZED_BUFFER = "serialized_buffer";
	public static final String RESPONSE_BUFFER = "response_message_buffer";
	public static final String SEND_RECEIVE_EVT_DATA = "SEND_RECEIVE";
	public static final String CONNECT_EVT_DATA = "CONNECT";
	private static final String EVENT_DATA_HOST_RESPONSE = "HOST_RESPONSE";
	
	@Lazy
	@Autowired
	List<EndPointDetail> endpoints;
	
	private static Map<String,TCPClientChannel> clientChannelMap = new HashMap<>();
	
	@Override
	public void handle(IEventMessage eventMessage, IEventContext context) {
		_logger.debug("Mapper host activity event processing started. Reply: {}, Message Data: {}", eventMessage.isReply(), eventMessage.getData());
		if(SEND_RECEIVE_EVT_DATA.equalsIgnoreCase(eventMessage.getData())){
			final String nodeName = context.get(IConstants.EVENT_CTX_DESTINATION_NODE_NAME_KEY);
			
			
			TCPClientChannel hostConnectionChannel = clientChannelMap.get(nodeName);
			boolean connectedToHost = false;
			if(hostConnectionChannel == null){
				connectedToHost = connectToClient(nodeName);
				hostConnectionChannel = clientChannelMap.get(nodeName);
			} else {
				connectedToHost = true;
			}
			if(connectedToHost){
				sendReceive(hostConnectionChannel, nodeName, context);
			} else {
				_logger.error("Unable to connect to TCPClient chaneel");//TODO
			}
		} 
	}

	private void sendReceive(final TCPClientChannel hostConnectionChannel, final String nodeName, IEventContext context) {
		try {
			final byte[] msgBuffer = context.get(SERIALIZED_BUFFER);
			hostConnectionChannel.setEventHandler((type, message, additionalInfo) -> {
				System.out.println("Response From mapper host receivevd:" + new String((byte[]) message.getData()));
				_logger.debug("Response received from the mapper host.");
	            replyToInitiator(EVENT_DATA_HOST_RESPONSE , (byte[]) message.getData(), context, true);
			});
			CompletableFuture<Boolean> messageSentFuture = hostConnectionChannel.send(new TCPChannelMessage(msgBuffer, null, null), null);
			if(messageSentFuture.get()){
				_logger.debug("Request message sent to mapper host successfully.");
			} else {
				_logger.debug("Failed to send request message to mapper host.");	
			}
		} catch (Exception e) {
		_logger.error("Error while communicating with mapper host.", e);
		}
	}

	private boolean connectToClient(String nodeName) {
		endpoints.stream().filter(endpoint -> {
			return (EndPointType.HOST.equals(endpoint.getType())
					&& nodeName.equalsIgnoreCase(endpoint.getNodeName()));
		}).forEach((endpoint -> {
			if (EndpointProtocol.TCP.equals(endpoint.getProtocol())) {
				connectToTCPClient(endpoint.getNodeName(),endpoint.getAddress(), endpoint.getPort());
			} else {
				// TODO need to work on HTTP protocols
			}
		}));
		return true;
	}

	private boolean connectToTCPClient(String nodeName,String address, int port) {
		try {
			TCPClientConfig config = new TCPClientConfig(address, port,nodeName);
	        TCPClientChannel clientChannel = new TCPClientChannel(config);
	        _logger.info("Connecting to Mapper Host. Node: {}, IP: {}, Port: {}", nodeName, address, port);
	        CompletableFuture<Boolean> start = clientChannel.start();
	        _logger.info("Virtualizer connected sucessfully to Mapper host on IP: {}, Port: {}", address, port);
	        clientChannelMap.put(nodeName, clientChannel);
	        return start.get();
		} catch (Exception e) {
			_logger.error("Error while connecting the mapper host on IP: {}, Port: {}", address, port);
			_logger.error("Connection Error.", e);
			return false;
		}
	}
	
	private <T> void replyToInitiator(String eventMessage, T responseData, IEventContext context, boolean success) {
		EventContext replyContext = new EventContext();
    	replyContext.set(RESPONSE_BUFFER, responseData);
    	replyContext.set(IConstants.EVENT_CTX_DESTINATION_NODE_NAME_KEY, context.get(IConstants.EVENT_CTX_DESTINATION_NODE_NAME_KEY));
    	replyContext.set(IConstants.EVENT_CTX_MESSAGE_NAME, context.get(IConstants.EVENT_CTX_MESSAGE_NAME));
    	replyContext.set(IConstants.EVENT_CTX_MESSAGE_TYPE_REQUEST, context.get(IConstants.EVENT_CTX_MESSAGE_TYPE_REQUEST));
    	replyContext.set(IConstants.EVENT_CTX_NODE_FORMAT, context.get(IConstants.EVENT_CTX_NODE_FORMAT));
        
		EventMessage originalMessage = context.get(ORI_REQUEST_CTX_KEY);
		if(originalMessage == null){
			return;
		}
		originalMessage.reply(eventMessage, success, replyContext);
	}
}

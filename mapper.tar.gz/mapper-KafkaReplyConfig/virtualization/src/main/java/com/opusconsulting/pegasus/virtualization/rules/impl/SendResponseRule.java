package com.opusconsulting.pegasus.virtualization.rules.impl;

import java.util.List;
import java.util.Map;

import com.opusconsulting.pegasus.virtualization.rules.IRuleInstance;

public class SendResponseRule extends AbstractTreeRuleInstance {

	public SendResponseRule(List<IRuleInstance> childRules, IRuleInstance nextInstance) {
		super(childRules, nextInstance);
	}

	@Override
	public <I> boolean execute(I result, Map<String, Object> ruleProps) {
		return false;
	}
}

package com.opusconsulting.pegasus.virtualization.event;

public enum VirtualizationEventSubjects {
	VIRTUALIZATION_BOOT, VIRTUALIZATION_STARTUP_ACTIVITY, PROCESS_VIRTUAL_BUFFER, VIRTUAL_HOST_COMMUNICATION, VIRTUAL_SAMPLE_FEED;
}

package com.opusconsulting.pegasus.virtualization.event.handlers;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import javax.inject.Inject;

import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.opusconsulting.pegasus.common.event.IEventContext;
import com.opusconsulting.pegasus.common.event.IEventHandler;
import com.opusconsulting.pegasus.common.event.IEventMessage;
import com.opusconsulting.pegasus.common.event.IEventPublisher;
import com.opusconsulting.pegasus.common.event.IReplyEventContext;
import com.opusconsulting.pegasus.common.event.ReplyType;
import com.opusconsulting.pegasus.event.impl.EventContext;
import com.opusconsulting.pegasus.event.impl.ReplyEventContext;
import com.opusconsulting.pegasus.flow.IFlowInstance;
import com.opusconsulting.pegasus.flow.impl.FlowFactory;
import com.opusconsulting.pegasus.runtime.IConstants;
import com.opusconsulting.pegasus.runtime.flow.AbstractIWorkflow;
import com.opusconsulting.pegasus.runtime.flow.IWorkflow;
import com.opusconsulting.pegasus.virtualization.flow.TreeRuleExecutionFlow;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelHandlerContext;

@Component
public class ProcessVirtualMessageBufferEventHandler implements IEventHandler {
	
	private static final Logger _logger = LoggerFactory.getLogger(ProcessVirtualMessageBufferEventHandler.class);
	private static final String RESPONSE_BUFFER = "processedResponseBuffer";
	
	@Inject
	FlowFactory flowFactory;
	
	@Inject
	@Lazy
	IEventPublisher startVirtualServerEventPublisher;
	
	@Override
	public void handle(IEventMessage eventMessage, IEventContext context) {
		_logger.debug("Virtual Process message event received. Is Reply: " + eventMessage.isReply());
		if(eventMessage.isReply()){
			processEventReply(eventMessage, context);
		} else {
			processEvent(eventMessage, context);
		}
	}

	private void processEventReply(IEventMessage eventMessage, IEventContext context) {
		if(ReplyType.Failure.equals(eventMessage.getReplyType())){
			//TODO think of failure scenario
		} else {
			final byte[] respBuffer = context.get(RESPONSE_BUFFER);
			//TODO Need to re-think on the logic
			sendResponseToServer(context, respBuffer);
		}
	}

	private void sendResponseToServer(IEventContext context, byte[] serializedRespBuffer) {
		final Object ctx = fetchResponseChannelCtx(context);
		EventContext eventContext = new EventContext();
		eventContext.set(IConstants.EVENT_CTX_SERIALIZED_RESPONSE_BUFFER, serializedRespBuffer);
		eventContext.set(IConstants.EVENT_CTX_CHANNEL_CONTEXT, ctx);
		String nodeName = null;
		if (context.getClass().isAssignableFrom(ReplyEventContext.class)) {
			IReplyEventContext replyEventContext = (IReplyEventContext) context;
			IEventContext originalContext = replyEventContext.getOriginalContext();
			nodeName = originalContext.get("SOURCE_NODE");
		}
		eventContext.set(IConstants.EVENT_CTX_SOURCE_NODE_NAME_KEY, nodeName);

		eventContext.set(IConstants.KF_TOPIC, context.get(IConstants.KF_TOPIC));

		startVirtualServerEventPublisher.publish("RESPOND_TO_SERVER", eventContext);
	}

	private Object fetchResponseChannelCtx(IEventContext context) {
		if (context.getClass().isAssignableFrom(ReplyEventContext.class)) {
			IReplyEventContext replyEventContext = (IReplyEventContext) context;
			IEventContext originalContext = replyEventContext.getOriginalContext();
			return originalContext.get(IConstants.SERVER_MSG_PROTOCOL_CTX);
		} else {
			return context.get(IConstants.SERVER_MSG_PROTOCOL_CTX);
		}
	}

	private void processEvent(IEventMessage eventMessage, IEventContext context) {
		final byte[] messageBuffer = eventMessage.getData();
		try {
			final byte[] processedBuffer = executeVirtualization(context, messageBuffer);
			//publish to client communication event
			EventContext replyContext = new EventContext();
			replyContext.set(RESPONSE_BUFFER, processedBuffer);
			eventMessage.reply("", true, replyContext);
		} catch (InterruptedException | ExecutionException e) {
			_logger.error("Error while sending Response to Server", e);
		}
	}

	private byte[] executeVirtualization(IEventContext context, final byte[] messageBuffer)
			throws InterruptedException, ExecutionException {
		final String nodeName = context.get(IConstants.EVENT_CTX_SOURCE_NODE_NAME_KEY);
		if(nodeName == null) return messageBuffer;
		final IFlowInstance virtualizationFlow = flowFactory.createInstance(AbstractIWorkflow.prepareMetaDataName(nodeName, TreeRuleExecutionFlow.VIRTUAL_RULE_EXEC_FLOW));
		final Map<String, Object> flowProps = new HashMap<>();
		flowProps.put(IConstants.FLOW_PROPS_MESSAGE_BUFFER_KEY, messageBuffer);
		flowProps.put(IConstants.FLOW_PROPS_NODE_NAME_KEY, context.get(IConstants.EVENT_CTX_SOURCE_NODE_NAME_KEY));
		
		if (context.get(IConstants.IS_REQUEST_PARAM_DESERIALIZE_SERIALIZE_REQUIRED) != null
				&& (boolean) context.get(IConstants.IS_REQUEST_PARAM_DESERIALIZE_SERIALIZE_REQUIRED)) {
			flowProps.put(IConstants.IS_REQUEST_PARAM_DESERIALIZE_SERIALIZE_REQUIRED, context.get(IConstants.IS_REQUEST_PARAM_DESERIALIZE_SERIALIZE_REQUIRED));
			if (context.get(IConstants.HTTP_REQUEST_PARAM_FIELDS_KEY) != null) {
				flowProps.put(IConstants.HTTP_REQUEST_PARAM_FIELDS_KEY, context.get(IConstants.HTTP_REQUEST_PARAM_FIELDS_KEY));
			}
			flowProps.put(IConstants.HTTP_MESSAGE_NAME_PROPS_KEY, context.get(IConstants.HTTP_MESSAGE_NAME_PROPS_KEY));
			flowProps.put(IConstants.IS_HTTP_REQUEST_MESSAGE_PROPS_KEY, context.get(IConstants.IS_HTTP_REQUEST_MESSAGE_PROPS_KEY));
		}
		
		final CompletableFuture<byte[]> virtualizationResult = virtualizationFlow.process(flowProps);
		return virtualizationResult.get();
	}

}

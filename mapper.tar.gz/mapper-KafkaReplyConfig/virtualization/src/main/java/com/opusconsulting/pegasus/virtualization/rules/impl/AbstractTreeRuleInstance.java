package com.opusconsulting.pegasus.virtualization.rules.impl;

import java.util.List;

import com.opusconsulting.pegasus.virtualization.rules.IRuleInstance;

public abstract class AbstractTreeRuleInstance implements IRuleInstance {
	List<IRuleInstance> childRules;
	IRuleInstance prevInstance;
	IRuleInstance nextInstance;
	
	public AbstractTreeRuleInstance(List<IRuleInstance> childRules,
			IRuleInstance nextInstance) {
		super();
		this.childRules = childRules;
		this.nextInstance = nextInstance;
	}

	@Override
	public List<IRuleInstance> getChildRules() {
		return this.childRules;
	}

	@Override
	public IRuleInstance nextRule() {
		return this.nextInstance;
	}

}

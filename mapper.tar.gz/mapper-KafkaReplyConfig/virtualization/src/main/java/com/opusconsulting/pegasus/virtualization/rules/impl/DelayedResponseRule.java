package com.opusconsulting.pegasus.virtualization.rules.impl;

import java.util.List;
import java.util.Map;

import com.opusconsulting.pegasus.virtualization.rules.IRuleInstance;

public class DelayedResponseRule extends AbstractTreeRuleInstance {

	int delay;
	
	public DelayedResponseRule(List<IRuleInstance> childRules, IRuleInstance nextInstance) {
		super(childRules, nextInstance);
	}

	@Override
	public <I> boolean execute(I result, Map<String, Object> ruleProps) {
		try {
			Thread.sleep(delay);
		} catch (InterruptedException e) {
			return false;
		}
		return true;
	}

	public void setDelay(int delay) {
		this.delay = delay;
	}
}

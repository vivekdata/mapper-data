package com.opusconsulting.pegasus.virtualization.rules;

import java.util.List;
import java.util.Map;

public interface IRuleInstance {
	<I> boolean execute(I result, Map<String, Object> ruleProps);
	
	List<IRuleInstance> getChildRules();
	
	IRuleInstance nextRule();
}

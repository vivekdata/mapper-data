package com.opusconsulting.pegasus.virtualization.flow;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.opusconsulting.pegasus.flow.impl.FlowFactory;
import com.opusconsulting.pegasus.flow.impl.FlowMetaDataFactory;
import com.opusconsulting.pegasus.flow.metadata.IFlowMetaData;
import com.opusconsulting.pegasus.flow.metadata.LinkInstanceInfo;
import com.opusconsulting.pegasus.flow.metadata.StepInstanceInfo;
import com.opusconsulting.pegasus.flow.metadata.impl.FlowMetaData;
import com.opusconsulting.pegasus.format.NodeFormat;
import com.opusconsulting.pegasus.format.iso.metadata.ISONodeDetail;
import com.opusconsulting.pegasus.format.iso.metadata.MessageDetail;
import com.opusconsulting.pegasus.format.iso.metadata.NodeDetail;
import com.opusconsulting.pegasus.format.iso.metadata.VirtualizationDetails;
import com.opusconsulting.pegasus.format.iso.metadata.VirtualizationRuleDetails;
import com.opusconsulting.pegasus.format.iso.metadata.VirtualizationRuleType;
import com.opusconsulting.pegasus.format.iso.metadata.XmlNodeDetail;
import com.opusconsulting.pegasus.runtime.IConstants;
import com.opusconsulting.pegasus.runtime.flow.AbstractIWorkflow;
import com.opusconsulting.pegasus.runtime.formula.ISOMessageCodeProvider;
import com.opusconsulting.pegasus.runtime.formula.util.IConditionUtility;
import com.opusconsulting.pegasus.runtime.formula.util.IValueProviderUtility;
import com.opusconsulting.pegasus.virtualization.rules.IRuleInstance;
import com.opusconsulting.pegasus.virtualization.rules.IRuleInstanceFields;
import com.opusconsulting.pegasus.virtualization.rules.TreeRuleInstanceCreator;
import com.opusconsulting.pegasus.virtualization.rules.TreeRuleInstanceInfo;
import com.opusconsulting.pegasus.virtualization.rules.impl.FieldDecisionRule;

@Component
public class TreeRuleExecutionFlow extends AbstractIWorkflow {
	private static final Logger _logger = LoggerFactory.getLogger(TreeRuleExecutionFlow.class);
	
	private static final String DESERIALIZE = "deserializer";

	private static final String SERIALIZE = "serializer";

	private static final String VIRTUAL_RULE_EXEC = "virtualRuleExecutor";

	public static final String VIRTUAL_RULE_EXEC_FLOW = "virtualizationRuleExecutionFlow";
	
	public static final String ADDITIONAL_HTTP_DESERIALIZER = "httpRequestParamDeserializer";
	
	public static final String ADDITIONAL_HTTP_SERIALIZER = "httpRequestParamSerializer";

	@Inject
	FlowFactory flowFactory;

	@Inject
	FlowMetaDataFactory flowMetaDataFactory;

	@Inject
	TreeRuleInstanceCreator ruleInstanceCreator;

	@Inject
	IValueProviderUtility valueProviderUtility;

	@Inject
	IConditionUtility conditionUtility;
	
	
	private StepInstanceInfo buildDeserializeStepInfo(NodeDetail<MessageDetail> nodeDetail) {
		if(nodeDetail.getClass().isAssignableFrom(ISONodeDetail.class)){
			Map<String, Object> isoDeserializerProps = new HashMap<>();
			isoDeserializerProps.put("nodeDetail", nodeDetail);
			
			return new StepInstanceInfo().setName(DESERIALIZE)
					.setStepName("ISODeserializer").setProperties(isoDeserializerProps);
		} else if(nodeDetail.getClass().isAssignableFrom(XmlNodeDetail.class)
				&& NodeFormat.XML.equals(nodeDetail.getFormat())){
			Map<String, Object> xmlDeserializerProps = new HashMap<>();
			xmlDeserializerProps.put("nodeDetail", nodeDetail);
			
			return new StepInstanceInfo().setName(DESERIALIZE)
					.setStepName("XMLDeserializer").setProperties(xmlDeserializerProps);
		} else if(nodeDetail.getClass().isAssignableFrom(XmlNodeDetail.class)
				&& NodeFormat.JSON.equals(nodeDetail.getFormat())){
			Map<String, Object> jsonDeserializerProps = new HashMap<>();
			jsonDeserializerProps.put("nodeDetail", nodeDetail);
			return new StepInstanceInfo().setName(DESERIALIZE)
					.setStepName("JSONDeserializer").setProperties(jsonDeserializerProps);
		} else {
			throw new UnsupportedOperationException("Unsupported node details provided");
		}
	}

	private StepInstanceInfo buildSerializeStepInfo(NodeDetail<MessageDetail> nodeDetail) {
		if(nodeDetail.getClass().isAssignableFrom(ISONodeDetail.class)){
			Map<String, Object> serializerProps = new HashMap<>();
			serializerProps.put("nodeDetail", nodeDetail);
			
			return new StepInstanceInfo().setName(SERIALIZE)
					.setStepName("ISOSerializer").setProperties(serializerProps);
		} else if(nodeDetail.getClass().isAssignableFrom(XmlNodeDetail.class) && NodeFormat.XML.equals(nodeDetail.getFormat())){
			Map<String, Object> xmlDeserializerProps = new HashMap<>();
			xmlDeserializerProps.put("nodeDetail", nodeDetail);
			return new StepInstanceInfo().setName(SERIALIZE)
					.setStepName("XMLSerializer").setProperties(xmlDeserializerProps);
		}else if(nodeDetail.getClass().isAssignableFrom(XmlNodeDetail.class) && NodeFormat.JSON.equals(nodeDetail.getFormat())){
			Map<String, Object> jsonDeserializerProps = new HashMap<>();
			jsonDeserializerProps.put("nodeDetail", nodeDetail);
			return new StepInstanceInfo().setName(SERIALIZE)
					.setStepName("JSONSerializer").setProperties(jsonDeserializerProps);
		} else {
			throw new UnsupportedOperationException("Unsupported node details provided");
		}
	}

	private StepInstanceInfo buildVirtualizationRuleExecutionStepInfo(List<VirtualizationDetails> virtualizationDetailsList) {
		final Map<String, List<IRuleInstance>> virtualRuleInstaces = new HashMap<>();
		for (VirtualizationDetails virtualizationDetails : virtualizationDetailsList) {
			final List<TreeRuleInstanceInfo> ruleInstanceInfos = buildTreeRuleInstanceInfo(virtualizationDetails);
			
			final List<IRuleInstance> ruleInstances = ruleInstanceInfos.stream().map(ruleInstanceInfo -> {
				return ruleInstanceCreator.create(ruleInstanceInfo);
			}).collect(Collectors.toList());
			virtualRuleInstaces.put(virtualizationDetails.getNodeName(), ruleInstances);
		}
				
		Map<String, Object> virtualRuleExeProps = new HashMap<>();
		virtualRuleExeProps.put("ruleInstances", virtualRuleInstaces);

		return new StepInstanceInfo().setName(VIRTUAL_RULE_EXEC).setStepName("VirtualRuleExecutor")
				.setProperties(virtualRuleExeProps);
	}

	private List<TreeRuleInstanceInfo> buildTreeRuleInstanceInfo(VirtualizationDetails virtualizationDetails) {
		if (virtualizationDetails.getRuleDetails() != null) {
			return virtualizationDetails.getRuleDetails().stream().map(ruleDetail -> {
				return buildRuleInstanceInfo(ruleDetail);
			}).collect(Collectors.toList());
		}
		return null;
	}

	/**
	 * 
	 * @param ruleDetail
	 *            - Rule details for which the TreeRuleInstanceInfo getting
	 *            build
	 * @param startIndex
	 *            - start index of list of Rule details from where ruleDetail
	 *            has picked up
	 * @param ruleList
	 *            - list of Rule details from where ruleDetail has picked up
	 * @return TreeRuleInstanceInfo
	 * 
	 *         </br>
	 *         </br>
	 *         <b>NOTE:</b> method builds the TreeRuleInstanceInfo from the rule
	 *         details. Next rule info will be the rule detail next in the list
	 *         from current.
	 * 
	 *         </br>
	 *         <b>Example:</b></br>
	 *         If List has </br>
	 * 
	 *         <pre>
	 * 		RuleDetail("Rule-1", "SomeRule" .... ),
	 * 			RuleDetail("Rule-2", "SomeRule" .... ),
	 * 				RuleDetail("Rule-3", "SomeRule" .... ),
	 * 				RuleDetail("Rule-4", "SomeRule" .... ),
	 * 			RuleDetail("Rule-5", "SomeRule" .... ),
	 * 				RuleDetail("Rule-6", "SomeRule" .... ),
	 * 		RuleDetail("Rule-7", "SomeRule" .... ),
	 * 			RuleDetail("Rule-8", "SomeRule" .... ),
	 * 			RuleDetail("Rule-9", "SomeRule" .... ),
	 * 		RuleDetail("Rule-10", "SomeRule" .... )
	 *         </pre>
	 * 
	 *         Method will treat first rule detail as a Root rule and start
	 *         preparing the Info. Final out put will be
	 * 
	 *         <pre>
	 * 		TreeRuleInstanceInfo("Rule-1"...)
	 * 			- nextRuleInfo("Rule-7"...)
	 * 			- childRules
	 * 					TreeRuleInstanceInfo("Rule-2"...)
	 * 						- nextRuleInfo("Rule-5"...)
	 * 
	 * 
	 *         </pre>
	 * 
	 */
	private TreeRuleInstanceInfo buildRuleInstanceInfo(VirtualizationRuleDetails ruleDetail) {
		TreeRuleInstanceInfo ruleInstanceInfo = new TreeRuleInstanceInfo();
		ruleInstanceInfo.setName(ruleDetail.getName());

		/*int nextInfoIndex = startIndex + 1;
		if (nextInfoIndex < ruleList.size()) {
			ruleInstanceInfo
					.setNextRuleInfo(buildRuleInstanceInfo(ruleList.get(nextInfoIndex), nextInfoIndex, ruleList));
		}*/
		ruleInstanceInfo.setRuleName(ruleDetail.getRuleType() == null ? null : ruleDetail.getRuleType().getRuleType());
		try {
			ruleInstanceInfo.setProperties(buildRuleProperties(ruleDetail.getRuleType(), ruleDetail));
		} catch (Exception e) {
			_logger.error("Error while setting ruleInstanceinfo for TreeRuleInstanceInfo ", e);
		}
		ruleDetail.getChildRules().stream().forEach((childRule -> {
			ruleInstanceInfo.addChildRule(buildRuleInstanceInfo(childRule));
		}));
		return ruleInstanceInfo;
	}

	private Map<String, Object> buildRuleProperties(VirtualizationRuleType ruleType, VirtualizationRuleDetails ruleValue)
			throws Exception {
		Map<String, Object> ruleProperties = new HashMap<>();
		
		switch (ruleType) {
			case ADD_FIELD:
				ruleProperties.put(IRuleInstanceFields.FIELD_DECISION_FIELD_NAME_PROP, ruleValue.getFieldName());
				ruleProperties.put(IRuleInstanceFields.FIELD_DECISION_ACTION_PROP, FieldDecisionRule.ADD_ACTION);
				ruleProperties.put(IRuleInstanceFields.FIELD_DECISION_FIELD_VALUE_PROP, valueProviderUtility.buildValueProvider(ruleValue.getFormulae(),
						new ISOMessageCodeProvider("request")));
				break;
			case MODIFY_FIELD:
				ruleProperties.put(IRuleInstanceFields.FIELD_DECISION_FIELD_NAME_PROP, ruleValue.getFieldName());
				ruleProperties.put(IRuleInstanceFields.FIELD_DECISION_ACTION_PROP, FieldDecisionRule.MODIFY_ACTION);
				ruleProperties.put(IRuleInstanceFields.FIELD_DECISION_FIELD_VALUE_PROP, valueProviderUtility.buildValueProvider(ruleValue.getFormulae(),
						new ISOMessageCodeProvider("request")));
				break;
			case REMOVE_FIELD:
				ruleProperties.put(IRuleInstanceFields.FIELD_DECISION_FIELD_NAME_PROP, ruleValue.getFieldName());
				ruleProperties.put(IRuleInstanceFields.FIELD_DECISION_ACTION_PROP, FieldDecisionRule.REMOVE_ACTION);
				break;
			case CONDITION_BASED:
				ruleProperties.put(IRuleInstanceFields.CONDITION_BASED_CONDITION_PROP,
						conditionUtility.buildCondition(ruleValue.getFormulae(), new ISOMessageCodeProvider("request")));// TODO need the factory for code provider
				break;
			case DELAY_RESPONSE:
				ruleProperties.put(IRuleInstanceFields.DELAYED_RESPONSE_DELAY_PROP, ruleValue.getDelayedTime());
				break;
			case MESSAGE_META_DATA_DECISION:
				ruleProperties.put(IRuleInstanceFields.MESSAGE_META_DATA_DECISION_MESSAGE_NAME_PROP, ruleValue.getMessageMetaDataMsgName());
				ruleProperties.put(IRuleInstanceFields.MESSAGE_META_DATA_DECISION_IS_REQUEST_PROP, ruleValue.isMessageMetaDataMsgRequest());
				break;
			default:
				break;
		}
		return ruleProperties;
	}

	@Override
	protected List<IFlowMetaData> buildFlowMetaDatas(Map<String, Object> workFlowData) {
		List<IFlowMetaData> metaDatas = new ArrayList<>();
		Map<String, NodeDetail<MessageDetail>> nodeDetails = (Map<String, NodeDetail<MessageDetail>>) workFlowData.get(IConstants.NODE_DETAILS_CONFIGS);
		List<VirtualizationDetails> virtualizationDetailsList = (List<VirtualizationDetails>) workFlowData.get(IConstants.VIRTUALIZATION_DETAILS);
		
		if(virtualizationDetailsList == null || virtualizationDetailsList.isEmpty()){
			System.err.println("No virtualization data available.");
			return null;
		}
		
		nodeDetails.entrySet().stream().forEach(nodeEntry -> {
			FlowMetaData virtualRuleExecFlowMetaData = buildFlowMetaData(nodeEntry.getValue(),
					virtualizationDetailsList);
			metaDatas.add(virtualRuleExecFlowMetaData);
		});
		
		return metaDatas;
	}

	private FlowMetaData buildFlowMetaData(NodeDetail<MessageDetail> nodeDetail,
			List<VirtualizationDetails> virtualizationDetailsList) {
		FlowMetaData virtualRuleExecFlowMetaData = new FlowMetaData();
		virtualRuleExecFlowMetaData.setName(prepareMetaDataName(nodeDetail.getName(), VIRTUAL_RULE_EXEC_FLOW));
		
		StepInstanceInfo deserializeStepInfo = buildDeserializeStepInfo(nodeDetail);

		StepInstanceInfo serializeStepInfo = buildSerializeStepInfo(nodeDetail);

		StepInstanceInfo virtualRuleExecStepInfo = buildVirtualizationRuleExecutionStepInfo(virtualizationDetailsList);

		final boolean defaultTreeFlowMetaData = checkIfDefaultTreeFlowMetaDataRequire(nodeDetail);
		if(defaultTreeFlowMetaData){
			return prepareDefaultTreeFlowMetaData(virtualRuleExecFlowMetaData, deserializeStepInfo, serializeStepInfo,
					virtualRuleExecStepInfo);
		} else {
			final StepInstanceInfo additionalDeserializeStepInfo = buildHttpDeserializeStepInfo(nodeDetail);
			
			final StepInstanceInfo additionalSerializeStepInfo = buildHttpSerializeStepInfo(nodeDetail);
			
			return prepareCustomTreeFlowMetaData(virtualRuleExecFlowMetaData, deserializeStepInfo,
					additionalDeserializeStepInfo, virtualRuleExecStepInfo, serializeStepInfo,
					additionalSerializeStepInfo);
		}
	}

	private FlowMetaData prepareDefaultTreeFlowMetaData(FlowMetaData virtualRuleExecFlowMetaData,
			StepInstanceInfo deserializeStepInfo, StepInstanceInfo serializeStepInfo,
			StepInstanceInfo virtualRuleExecStepInfo) {
		final LinkInstanceInfo preVirtualRuleExecution = buildLinkInstance(DESERIALIZE, VIRTUAL_RULE_EXEC);

		final LinkInstanceInfo postVirtualRuleExecution = buildLinkInstance(VIRTUAL_RULE_EXEC, SERIALIZE);

		virtualRuleExecFlowMetaData.setStartStepInstanceName(DESERIALIZE)
				.setStepInstancesInfo(Arrays.asList(deserializeStepInfo, virtualRuleExecStepInfo, serializeStepInfo))
				.setLinkInstancesInfo(Arrays.asList(preVirtualRuleExecution, postVirtualRuleExecution));
		return virtualRuleExecFlowMetaData;
	}

	private StepInstanceInfo buildHttpDeserializeStepInfo(NodeDetail<MessageDetail> nodeDetail) {
		Map<String, Object> httpAdditionalDeserializerProps = new HashMap<>();
		httpAdditionalDeserializerProps.put("nodeDetail", nodeDetail);
		
		return new StepInstanceInfo().setName(ADDITIONAL_HTTP_DESERIALIZER)
				.setStepName(ADDITIONAL_HTTP_DESERIALIZER).setProperties(httpAdditionalDeserializerProps);
	}
	
	private StepInstanceInfo buildHttpSerializeStepInfo(NodeDetail<MessageDetail> nodeDetail) {
		Map<String, Object> httpAdditionalSerializerProps = new HashMap<>();
		httpAdditionalSerializerProps.put("nodeDetail", nodeDetail);
		
		return new StepInstanceInfo().setName(ADDITIONAL_HTTP_SERIALIZER)
				.setStepName(ADDITIONAL_HTTP_SERIALIZER).setProperties(httpAdditionalSerializerProps);
	}
	
	/**
	 * This method checks whether you need custom tree flow meta data
	 * @param nodeDetail
	 * @return
	 */
	private boolean checkIfDefaultTreeFlowMetaDataRequire(NodeDetail<MessageDetail> nodeDetail) {
		if (nodeDetail.getClass().isAssignableFrom(XmlNodeDetail.class)
				&& NodeFormat.XML.equals(nodeDetail.getFormat())) {
			return false;
		} else if (nodeDetail.getClass().isAssignableFrom(XmlNodeDetail.class)
				&& NodeFormat.JSON.equals(nodeDetail.getFormat())) {
			return false;
		} else {
			return true;
		}
	}
	
	/**
	 * Builds the flow meta data as per the sequential input of the steps.
	 * @param virtualRuleExecFlowMetaData
	 * @param sequentialStepInfos
	 * @return
	 */
	private FlowMetaData prepareCustomTreeFlowMetaData(FlowMetaData virtualRuleExecFlowMetaData,
			StepInstanceInfo... sequentialStepInfos) {
		//build the link instances as per the step infos
		final List<LinkInstanceInfo> linkInstanceInfos = new ArrayList<>();
		for(int stepInfoIndex = 0; stepInfoIndex < (sequentialStepInfos.length-1); stepInfoIndex++){
			final LinkInstanceInfo linkInstance = buildLinkInstance(sequentialStepInfos[stepInfoIndex].getName(), sequentialStepInfos[stepInfoIndex+1].getName());
			linkInstanceInfos.add(linkInstance);
		}
		
		virtualRuleExecFlowMetaData.setStartStepInstanceName(sequentialStepInfos[0].getName())
				.setStepInstancesInfo(Arrays.asList(sequentialStepInfos))
				.setLinkInstancesInfo(linkInstanceInfos);
		return virtualRuleExecFlowMetaData;
	}
}

package com.opusconsulting.pegasus.virtualization.rules;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class TreeRuleInstanceInfo {
	String name;
	String ruleName;
	Map<String, Object> properties;
	TreeRuleInstanceInfo nextRuleInfo;
	List<TreeRuleInstanceInfo> childRules = new ArrayList<>();
	
	public String getName() {
		return name;
	}
	public TreeRuleInstanceInfo setName(String name) {
		this.name = name;
		return this;
	}
	public String getRuleName() {
		return ruleName;
	}
	public TreeRuleInstanceInfo setRuleName(String ruleName) {
		this.ruleName = ruleName;
		return this;
	}
	public Map<String, Object> getProperties() {
		return properties;
	}
	public TreeRuleInstanceInfo setProperties(Map<String, Object> properties) {
		this.properties = properties;
		return this;
	}
	public TreeRuleInstanceInfo getNextRuleInfo() {
		return nextRuleInfo;
	}
	public TreeRuleInstanceInfo setNextRuleInfo(TreeRuleInstanceInfo nextRuleInfo) {
		this.nextRuleInfo = nextRuleInfo;
		return this;
	}
	public List<TreeRuleInstanceInfo> getChildRules() {
		return childRules;
	}
	public TreeRuleInstanceInfo addChildRule(TreeRuleInstanceInfo childRule) {
		this.childRules.add(childRule);
		return this;
	}
	
	
}

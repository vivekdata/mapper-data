package com.opusconsulting.pegasus.virtualization.rules;

public interface IRuleInstanceCreator {
	IRuleInstance create(TreeRuleInstanceInfo info);
}

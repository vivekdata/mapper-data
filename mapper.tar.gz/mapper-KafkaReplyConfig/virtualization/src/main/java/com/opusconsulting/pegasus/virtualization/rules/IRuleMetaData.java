package com.opusconsulting.pegasus.virtualization.rules;

public interface IRuleMetaData {
	Class<?> getType();

	String getName();
}

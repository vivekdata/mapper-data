package com.opusconsulting.pegasus.common.event;

import com.opusconsulting.pegasus.common.IContext;

public interface IEventContext extends IContext {
}

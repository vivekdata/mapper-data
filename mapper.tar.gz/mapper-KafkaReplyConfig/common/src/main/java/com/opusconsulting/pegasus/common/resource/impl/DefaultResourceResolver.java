package com.opusconsulting.pegasus.common.resource.impl;

import com.opusconsulting.pegasus.common.resource.util.ResourceUtil;
import com.opusconsulting.pegasus.common.resource.ResourceHandler;
import com.opusconsulting.pegasus.common.resource.ResourceInfo;
import com.opusconsulting.pegasus.common.resource.ResourceResolver;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by Saran on 9/22/14.
 */
public class DefaultResourceResolver<T> implements ResourceResolver<T> {

    private static Map<String, ResourceHandler> resourceHandlerMap = new HashMap<String, ResourceHandler>();

    public void register(String type, ResourceHandler handler) {
        resourceHandlerMap.put(type, handler);
    }

    public ResourceHandler unregister(String type) {
        return resourceHandlerMap.remove(type);
    }

    public ResourceHandler getHandler(String type) {
        return resourceHandlerMap.get(type);
    }

    @Override
    public boolean isValid(String resourceIdentifier) {
        ResourceHandler handler = getLRHandler(resourceIdentifier);
        if (handler == null) {
            return false;
        }

        return true;
    }

    @Override
    public <R> R getResource(String resourceIdentifier) throws Exception {
        ResourceInfo baseLRInfo = ResourceUtil.getBaseLRInfo(resourceIdentifier);
        if (baseLRInfo == null) {
            return null;
        }

        ResourceHandler lrHandler = resourceHandlerMap.get(baseLRInfo.getType());
        if (lrHandler == null) {
            return null;
        }

        return (R) lrHandler.getResource(baseLRInfo);
    }

    @Override
    public ResourceHandler getLRHandler(String resourceIdentifier) {
        ResourceInfo baseLRInfo = ResourceUtil.getBaseLRInfo(resourceIdentifier);
        if (baseLRInfo == null) {
            return null;
        }

        return getHandler(baseLRInfo.getType());
    }

    @Override
    public T getRunnable(String resourceIdentifier) throws Exception {
        ResourceInfo baseLRInfo = ResourceUtil.getBaseLRInfo(resourceIdentifier);
        if (baseLRInfo == null) {
            throw new Exception("Invalid resource " + resourceIdentifier);
        }

        ResourceHandler lrHandler = resourceHandlerMap.get(baseLRInfo.getType());
        if (lrHandler == null) {
            throw new Exception("Handler not registered for resource type " + baseLRInfo.getType());
        }

        return (T) lrHandler.getRunnable(baseLRInfo);
    }

}

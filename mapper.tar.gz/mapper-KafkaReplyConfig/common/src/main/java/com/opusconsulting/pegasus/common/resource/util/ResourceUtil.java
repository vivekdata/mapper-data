package com.opusconsulting.pegasus.common.resource.util;


import com.opusconsulting.pegasus.common.resource.ResourceInfo;

/**
 * Created by Saran on 9/22/14.
 */
public class ResourceUtil {

    public static ResourceInfo getBaseLRInfo(String resourceIdentifer) {
        int matchIndex = resourceIdentifer.indexOf("://");
        if (matchIndex == -1) {
            return null;
        }

        String type = resourceIdentifer.substring(0, matchIndex);
        String data = resourceIdentifer.substring(matchIndex + 3);
        return new ResourceInfo(type, data);
    }

}

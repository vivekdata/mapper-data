package com.opusconsulting.pegasus.common.channel;

/**
 * Created by saran on 5/28/17.
 */
public interface IChannelEvent<T extends IChannelMessage> {
    void onEvent(String type, T message, Object additionalInfo);
}

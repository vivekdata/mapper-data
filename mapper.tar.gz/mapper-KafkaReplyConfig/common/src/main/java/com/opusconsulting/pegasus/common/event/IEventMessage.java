package com.opusconsulting.pegasus.common.event;

import java.io.Serializable;

public interface IEventMessage {
    IEventSource getSource();

    <T extends Serializable> T getData();

    ReplyType getReplyType();

    boolean isReply();

    <T extends Serializable> void reply(T data, boolean isSuccess);

    <T extends Serializable> void reply(T data, boolean isSuccess, IEventContext replyContext);
}

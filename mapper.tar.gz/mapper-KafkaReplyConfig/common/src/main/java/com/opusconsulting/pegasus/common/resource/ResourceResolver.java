package com.opusconsulting.pegasus.common.resource;

import com.opusconsulting.pegasus.common.resource.exception.ResourceNotFound;

/**
 * Created by Saran on 9/22/14.
 * <p/>
 * Local Resource Resolver
 */
public interface ResourceResolver<T> {
    boolean isValid(String resourceIdentifier);

    <R> R getResource(String resourceIdentifier) throws Exception;

    ResourceHandler getLRHandler(String resourceIdentifier) throws ResourceNotFound;

    T getRunnable(String resourceIdentifier) throws Exception;
}

package com.opusconsulting.pegasus.common.channel;

import java.util.Map;

/**
 * Created by saran on 5/28/17.
 */
public interface IChannelMessage<T, C> {
    Map<String, Object> getProps();

    T getData();

    C getProtocolContext();
}

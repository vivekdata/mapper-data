package com.opusconsulting.pegasus.common.channel;

import java.util.concurrent.CompletableFuture;

public interface IChannel<C, M> {

    void setConfig(C config);

    void setEventHandler(IChannelEvent eventHandler);

    CompletableFuture<Boolean> start() throws Exception;

    CompletableFuture<Boolean> stop() throws Exception;

    CompletableFuture<Boolean> send(M message, IChannelContext ctx) throws Exception;
}

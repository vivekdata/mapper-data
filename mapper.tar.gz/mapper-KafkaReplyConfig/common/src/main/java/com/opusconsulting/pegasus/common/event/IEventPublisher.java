package com.opusconsulting.pegasus.common.event;

import java.io.Serializable;

public interface IEventPublisher {
    <T extends Serializable> void publish(T data);

    <T extends Serializable> void publish(T data, IEventContext context);
}

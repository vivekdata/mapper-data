package com.opusconsulting.pegasus.common.event;

public enum ReplyType {
    Success, Failure, None
}

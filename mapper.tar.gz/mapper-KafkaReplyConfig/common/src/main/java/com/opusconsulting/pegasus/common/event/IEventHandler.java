package com.opusconsulting.pegasus.common.event;

public interface IEventHandler {
	String ORI_REQUEST_CTX_KEY = "request";
	
    void handle(IEventMessage eventMessage, IEventContext context);
}

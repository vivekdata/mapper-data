package com.opusconsulting.pegasus.common.resource.exception;

/**
 * Created by Saran on 9/22/14.
 */
public class ResourceNotFound extends Exception {
    public ResourceNotFound() {
    }

    public ResourceNotFound(String s) {
        super(s);
    }

    public ResourceNotFound(String s, Throwable throwable) {
        super(s, throwable);
    }

    public ResourceNotFound(Throwable throwable) {
        super(throwable);
    }
}

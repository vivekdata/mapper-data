package com.opusconsulting.pegasus.common;

import java.util.HashMap;
import java.util.Map;

public class Context implements IContext {

    Map<String, Object> data;

    @Override
    public <T> T get(String key) {
        return (data == null) ? null : (T) data.get(key);
    }

    @Override
    public <T> void set(String key, T value) {
        getOrCreateIfNull().put(key, value);
    }

    @Override
    public <T> T remove(String key) {
        return (data == null) ? null : (T) data.remove(key);
    }

    private Map<String, Object> getOrCreateIfNull() {
        if (data == null) {
            data = new HashMap<>();
        }

        return data;
    }
}

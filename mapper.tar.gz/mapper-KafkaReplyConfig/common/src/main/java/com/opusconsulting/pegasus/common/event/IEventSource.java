package com.opusconsulting.pegasus.common.event;

import java.io.Serializable;

public interface IEventSource {
    <T extends Serializable> void send(IEventSource source, T data, ReplyType replyType);

    <T extends Serializable> void send(IEventSource source, T data, ReplyType replyType, IEventContext context);
}

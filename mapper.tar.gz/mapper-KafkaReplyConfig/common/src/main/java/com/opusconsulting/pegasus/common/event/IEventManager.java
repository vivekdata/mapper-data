package com.opusconsulting.pegasus.common.event;

public interface IEventManager {
    IEventConsumer createConsumer(String subject, IEventHandler handler);

    IEventPublisher createPublisher(String subject);

    IEventPublisher createPublisher(String subject, IEventHandler handler);

    boolean unSubscribe(String subject, IEventConsumer consumer);

    boolean unSubscribe(IEventPublisher publisher);

    void shutdown();
}

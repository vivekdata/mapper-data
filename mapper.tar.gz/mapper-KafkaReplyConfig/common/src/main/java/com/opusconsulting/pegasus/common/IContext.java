package com.opusconsulting.pegasus.common;

public interface IContext {
    <T> T get(String key);

    <T> void set(String key, T value);

    <T> T remove(String key);
}

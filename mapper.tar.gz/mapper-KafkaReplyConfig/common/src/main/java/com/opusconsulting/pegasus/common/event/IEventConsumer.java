package com.opusconsulting.pegasus.common.event;

public interface IEventConsumer {
    void unSubscribe();
}

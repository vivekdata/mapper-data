package com.opusconsulting.pegasus.common.channel;

import com.opusconsulting.pegasus.common.IContext;

public interface IChannelContext extends IContext {
}

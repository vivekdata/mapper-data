package com.opusconsulting.pegasus.common.event;

public interface IReplyEventContext {
    IEventContext getOriginalContext();
}

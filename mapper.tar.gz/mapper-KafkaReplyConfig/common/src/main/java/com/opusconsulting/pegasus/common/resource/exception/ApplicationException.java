package com.opusconsulting.pegasus.common.resource.exception;

public class ApplicationException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7053877073126273375L;
	
	public ApplicationException(String message, Throwable exception) {
		super(message, exception);
	}
}

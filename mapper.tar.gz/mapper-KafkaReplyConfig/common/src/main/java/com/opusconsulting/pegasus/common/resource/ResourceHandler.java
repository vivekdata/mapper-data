package com.opusconsulting.pegasus.common.resource;


/**
 * Created by Saran on 9/22/14.
 */
public interface ResourceHandler<T> {
    <R> R getResource(ResourceInfo resourceInfo) throws Exception;

    T getRunnable(ResourceInfo baseResourceInfo) throws Exception;
}

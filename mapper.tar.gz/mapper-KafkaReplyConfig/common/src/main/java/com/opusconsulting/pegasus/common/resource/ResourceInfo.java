package com.opusconsulting.pegasus.common.resource;

/**
 * Created by Saran on 9/22/14.
 */
public class ResourceInfo {
    String type;
    String data;

    public ResourceInfo(String type) {
        this(type, null);
    }

    public ResourceInfo(String type, String data) {
        this.type = type;
        this.data = data;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }
}

Steps to checkout code from Git::::::::::::

git clone http://10.10.31.53/opustools/mapper.git
cd mapper
touch README.md
git add README.md
git commit -m "add README"
git push -u origin master

Steps to Run Mapper:::::::

Go to /cloud-config-server/src/main/resources/config/runtimeConfig-dev.properties file and add path of json file 
No need to add Envirnment Variable in runtime and Virtualization module.
first run Config-Server module,Virtualization and Runtime module to test end to end

------------------------------------------------------------------------------------------------------------------------
### Install Apache Kafka
1. Download the latest version of Apache Kafka from https://kafka.apache.org/downloads under Binary downloads.

2. Extract the contents to C:\ to a directory of your choice.

### Run Kafka Server
**Step 1:** Kafka requires Zookeeper to run. Basically, Kafka uses Zookeeper to manage the entire cluster and various brokers. Therefore, a running instance of Zookeeper is a prerequisite to Kafka.

To start Zookeeper, we can open a PowerShell prompt and execute the below command:

`.\bin\windows\zookeeper-server-start.bat .\config\zookeeper.properties`

If the command is successful, Zookeeper will start on port 2181.

**Step 2:** Now open another command prompt and change the directory to the kafka folder. Run kafka server using the command:

`.\bin\windows\kafka-server-start.bat .\config\server.properties`

Now your Kafka Server is up and running, you can create topics to store messages. Also, we can produce or consume data directly from the command prompt.

**Create a Kafka Topic:**
Open a new command prompt in the location C:\kafka\bin\windows.

**Run the following command:**

`kafka-topics.bat --create --zookeeper localhost:2181 --replication-factor 1 --partitions 1 --topic test`

`Creating Kafka Producer:`
Open a new command prompt in the location C:\kafka\bin\windows

**Run the following command:**

`kafka-console-producer.bat --broker-list localhost:9092 --topic test`

**Creating Kafka Consumer:**
Open a new command prompt in the location C:\kafka\bin\windows.

**Run the following command:**

`kafka-console-consumer.bat --bootstrap-server localhost:9092 --topic test --from-beginning`

### Mapper Kafka Producer-Consumer commands
**_Producer_**

Open a new command prompt in the location C:\kafka\bin\windows

**Run the following command:**

`.\kafka-console-producer.bat --broker-list localhost:9092 --topic topic.consumer --property parse.headers=true`

**_Consumer_**

Open a new command prompt in the location C:\kafka\bin\windows

**Run the following command:**

`.\kafka-console-consumer.bat --bootstrap-server localhost:9092 --topic topic.producer --property print.headers=true`


#### _For Mapper Config and Input files please check folder mapper\configutaion_files\KafkaReqResp_
package com.opusconsulting.pegasus.runtime;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.opusconsulting.pegasus.flow.IFlowContext;
import com.opusconsulting.pegasus.flow.IFlowInstance;
import com.opusconsulting.pegasus.flow.impl.FlowFactory;
import com.opusconsulting.pegasus.flow.metadata.IStepMetaData;
import com.opusconsulting.pegasus.flow.metadata.LinkInstanceInfo;
import com.opusconsulting.pegasus.flow.metadata.StepInstanceInfo;
import com.opusconsulting.pegasus.flow.metadata.impl.FlowMetaData;
import com.opusconsulting.pegasus.flow.metadata.impl.StepMetaData;
import com.opusconsulting.pegasus.format.iso.metadata.EncodingType;
import com.opusconsulting.pegasus.format.iso.metadata.FieldDataType;
import com.opusconsulting.pegasus.format.iso.metadata.FieldSizeType;
import com.opusconsulting.pegasus.format.iso.metadata.ISOFieldMetaData;
import com.opusconsulting.pegasus.format.iso.metadata.ISOMessageDetail;
import com.opusconsulting.pegasus.format.iso.metadata.MessageKind;
import com.opusconsulting.pegasus.formula.ISOMessageCodeProvider;
import com.opusconsulting.pegasus.formula.codegen.CodeMetaData;
import com.opusconsulting.pegasus.formula.codegen.FormulaCodeInfo;
import com.opusconsulting.pegasus.formula.codegen.FunctionMetaData;
import com.opusconsulting.pegasus.formula.codegen.ParamMetaData;
import com.opusconsulting.pegasus.formula.codegen.impl.FormulaCodeGenerator;
import com.opusconsulting.pegasus.formula.compiler.JavaCodeCompiler;
import com.opusconsulting.pegasus.runtime.mapper.layman.IMessageCreator;
import com.opusconsulting.pegasus.runtime.mapper.layman.MessageCreatorImpl;
import com.opusconsulting.pegasus.runtime.steps.MappingConfig;
import com.opusconsulting.pegasus.step.IsoMsgByteGeneratorStep;

@Configuration
public class TestEngineFlow {

	@Bean
	public static IStepMetaData createIsoMsgByteGeneratorStepMetaData() {
		return new StepMetaData().setName("isoMsgByteGenerator").setType(IsoMsgByteGeneratorStep.class);
	}

	private static ClassPathXmlApplicationContext init() {
		ClassPathXmlApplicationContext mainApplicationContext = new ClassPathXmlApplicationContext(
				new String[] { "formula-spring.xml" , "spring.xml"}, true);

		AnnotationConfigApplicationContext applicationContext = new AnnotationConfigApplicationContext();
		applicationContext.register(StepConfiguration.class, TestEngineFlow.class);
		applicationContext.setParent(mainApplicationContext);
		applicationContext.refresh();
		return mainApplicationContext;
	}

	public static void main(String[] args) {
		try {

			ClassPathXmlApplicationContext mainApplicationContext = init();

			FormulaCodeGenerator formulaCodeGenerator = (FormulaCodeGenerator) mainApplicationContext
					.getBean("formulaCodeGenerator");
			JavaCodeCompiler compiler = (JavaCodeCompiler) mainApplicationContext.getBean(JavaCodeCompiler.class);

			final Map<String, Object> nodeMetaDataObj = readJsonMetaData(
					"D:\\workspace\\poc\\pegasus-backend\\VISA_UPDATED.json");
			// Field Meta data
			List<ISOFieldMetaData> fieldMetaDatas = buildFieldMetaData(nodeMetaDataObj);
			// message meta data
			List<ISOMessageDetail> messageMetaDatas = buildMessageMetaData(nodeMetaDataObj);
			Map<String, ICondition> msgIdentificationsFoumulas = buildFormulas(messageMetaDatas, formulaCodeGenerator,
					compiler);

			final Map<String, Object> workFlowMetaDataObj = readJsonMetaData(
					"D:\\workspace\\poc\\pegasus-backend\\masterCard_To_Visa_workFlow.json");
			final Map<String, List<MappingConfig>> mappingConfigs = buildMappingConfig(workFlowMetaDataObj, formulaCodeGenerator, compiler);
			// build supported message creater
			final Map<String, IMessageCreator> messageCreators = buildMessageCreaterMap();

			// Sample message Byte generator step
			Map<String, Object> isoMessageByteGeneratorProps = new HashMap<>();
			StepInstanceInfo isoMessageByteGeneratorInfo = new StepInstanceInfo().setName("msgByteGenerator")
					.setStepName("isoMsgByteGenerator").setProperties(isoMessageByteGeneratorProps);

			// De-Serialize step
			Map<String, Object> isoDeserializerProps = new HashMap<>();
			isoDeserializerProps.put("fieldDetails", fieldMetaDatas);

			StepInstanceInfo deserializerStepInstanceInfo = new StepInstanceInfo().setName("deserializer")
					.setStepName("ISODeserializer").setProperties(isoDeserializerProps);
			// Message Identification step
			Map<String, Object> messageIdentificationProps = new HashMap<>();
			messageIdentificationProps.put("formulas", msgIdentificationsFoumulas);
			messageIdentificationProps.put("computeEvenIfExists", true);
			StepInstanceInfo messageIdStep = new StepInstanceInfo().setName("messageIdentification")
					.setStepName("MessageIdentification").setProperties(messageIdentificationProps);
			// Transformation step
			Map<String, Object> transformationStepProps = new HashMap<>();
			transformationStepProps.put("sourceMapping", mappingConfigs);
			transformationStepProps.put("messageCreators", messageCreators);
			StepInstanceInfo transformationStepInfo = new StepInstanceInfo().setName("transformation")
					.setStepName("Transformation").setProperties(transformationStepProps);

			// Serialize step
			StepInstanceInfo serializerStepInstanceInfo = new StepInstanceInfo().setName("serializer")
					.setStepName("ISOSerializer").setProperties(isoDeserializerProps);

			// Flow
			FlowFactory flowFactory = (FlowFactory) mainApplicationContext.getBean("flowFactory");

			final LinkInstanceInfo msgByteGeneratorToDeserializer = new LinkInstanceInfo();
			msgByteGeneratorToDeserializer.setSourceStepInstanceName("msgByteGenerator")
					.setDestinationStepInstanceName("deserializer");

			final LinkInstanceInfo deserializeToMsgId = new LinkInstanceInfo();
			deserializeToMsgId.setSourceStepInstanceName("deserializer")
					.setDestinationStepInstanceName("messageIdentification");

			final LinkInstanceInfo msgIdToTransform = new LinkInstanceInfo();
			msgIdToTransform.setSourceStepInstanceName("messageIdentification")
					.setDestinationStepInstanceName("transformation");

			final LinkInstanceInfo transformationToSerialize = new LinkInstanceInfo();
			transformationToSerialize.setSourceStepInstanceName("transformation")
					.setDestinationStepInstanceName("serializer");

			FlowMetaData flowMetaData = new FlowMetaData();
			flowMetaData.setName("iso87Toiso93");
			flowMetaData.setStartStepInstanceName("msgByteGenerator")
					.setStepInstancesInfo(Arrays.asList(isoMessageByteGeneratorInfo, deserializerStepInstanceInfo,
							messageIdStep, transformationStepInfo, serializerStepInstanceInfo))
					.setLinkInstancesInfo(Arrays.asList(msgByteGeneratorToDeserializer, deserializeToMsgId,
							msgIdToTransform, transformationToSerialize));
			flowFactory.register(flowMetaData);
			flowFactory.init();

			IFlowInstance printFlow = flowFactory.createInstance("iso87Toiso93");
			Object flowResult = printFlow.process(null);
			try {
				System.out.println(((CompletableFuture) flowResult).get());
				byte[] messageBytes = (byte[]) ((CompletableFuture) flowResult).get();
				System.out.println("After flow complete : " + new String(messageBytes));
			} catch (InterruptedException | ExecutionException e) {
				e.printStackTrace();
			}

		} catch (FileNotFoundException exception) {
			exception.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private static Map<String, Object> readJsonMetaData(String nodeMetaDataFile)
			throws IOException, JsonParseException, JsonMappingException {
		ObjectMapper mapper = new ObjectMapper();
		@SuppressWarnings("unchecked")
		Map<String, Object> obj = mapper.readValue(new File(nodeMetaDataFile), Map.class);
		return obj;
	}

	private static Map<String, ICondition> buildFormulas(List<ISOMessageDetail> messageMetaDatas,
			FormulaCodeGenerator formulaCodeGenerator, JavaCodeCompiler compiler) {
		final Map<String, ICondition> formulaConditions = new HashMap<>();
		messageMetaDatas.stream().forEach(messageDetail -> {
			try {
				ICondition iConditionObj = TestEngineFlow.buildCondition(
						messageDetail.getMessageIdentificationFormula(), formulaCodeGenerator, compiler);
				if (iConditionObj != null)
					formulaConditions.put(messageDetail.getName(), iConditionObj);
			} catch (Exception e) {
				e.printStackTrace();
			}
		});
		return formulaConditions;
	}

	private static ICondition buildCondition(String formula, FormulaCodeGenerator formulaCodeGenerator,
			JavaCodeCompiler compiler) throws Exception {
		CodeMetaData codeMetaData = new CodeMetaData();
		codeMetaData.setPackageName("com.opusconsulting.pegasus.formula");
		codeMetaData.addImport("com.opusconsulting.pegasus.runtime.ICondition");
		codeMetaData.addImport("static com.opusconsulting.pegasus.formula.ExcelFunctions.*");
		codeMetaData.addImport("com.opusconsulting.pegasus.runtime.IMessage");
		codeMetaData.addImport("java.util.Map");
		codeMetaData.addImport("com.opusconsulting.pegasus.flow.IFlowContext");
		codeMetaData.setImplementClasses(Arrays.asList("ICondition"));

		FunctionMetaData functionMetaData = new FunctionMetaData();
		functionMetaData.setName("check");
		functionMetaData.setReturnType("boolean");
		functionMetaData.setParams(Arrays.asList(new ParamMetaData("request", "IMessage"),
				new ParamMetaData("ctx", "IFlowContext"), new ParamMetaData("tag", "Map<String, Object>")));
		codeMetaData.setCallFunctionMetaData(functionMetaData);
		if (formula == null)
			return null;

		FormulaCodeInfo formulaCodeInfo = formulaCodeGenerator.create(formula, codeMetaData,
				new ISOMessageCodeProvider("request"));
		formulaCodeInfo.getClassName();

		Class<Object> conditionClass = compiler.compile(formulaCodeInfo.getClassName(), formulaCodeInfo.getCode());
		return (ICondition) conditionClass.newInstance();
	}

	private static List<ISOMessageDetail> buildMessageMetaData(Map<String, Object> obj) {
		List<Object> messages = (List<Object>) obj.get("messages");
		return messages.stream().map(message -> {
			Map<String, Object> messageData = (LinkedHashMap<String, Object>) message;
			return new ISOMessageDetail((String) messageData.get("name"), (String) messageData.get("description"),
					MessageKind.valueOf((String) messageData.get("type")),
					(String) messageData.get("messageIdentification"));
		}).collect(Collectors.toList());
	}

	private static List<ISOFieldMetaData> buildFieldMetaData(Map<String, Object> obj) {
		List<Object> fields = (List) obj.get("fields");
		return fields.stream().map(field -> {
			Map<String, Object> fieldData = (LinkedHashMap<String, Object>) field;
			FieldSizeType fieldType = FieldSizeType.valueOf((String) fieldData.get("fieldType"));
			if (FieldSizeType.Fixed.equals(fieldType)) {
				return ISOFieldMetaData.fixed((String) fieldData.get("fieldname"),
						(String) fieldData.get("description"),
						FieldDataType.valueOf((String) fieldData.get("fieldDataType")),
						Integer.parseInt((String) fieldData.get("size")),
						EncodingType.valueOf((String) fieldData.get("encodingType")));
			} else if (FieldSizeType.Variable.equals(fieldType)) {
				return ISOFieldMetaData.variable((String) fieldData.get("fieldname"),
						(String) fieldData.get("description"),
						FieldDataType.valueOf((String) fieldData.get("fieldDataType")),
						EncodingType.valueOf((String) fieldData.get("encodingType")),
						Integer.parseInt((String) fieldData.get("size")),
						fieldData.get("lengthEncodingType") != null
								? EncodingType.valueOf((String) fieldData.get("lengthEncodingType"))
								: EncodingType.ASCII);
			}
			return null;
		}).collect(Collectors.toList());
	}

	private static Map<String, IMessageCreator> buildMessageCreaterMap() {
		Map<String, IMessageCreator> messageCreaters = new HashMap<String, IMessageCreator>();
		messageCreaters.put("masterCard", new MessageCreatorImpl("mastercard", null));
		return messageCreaters;
	}

	private static Map<String, List<MappingConfig>> buildMappingConfig(Map<String, Object> workFlowMetaDataObj,
			FormulaCodeGenerator formulaCodeGenerator, JavaCodeCompiler compiler) {
		List<Object> data = (List) workFlowMetaDataObj.get("data");
		Map<String, Object> mappingData = (LinkedHashMap<String, Object>) data.get(0);
		
		return ((List<LinkedHashMap<String, Object>>) mappingData.get("mapping")).stream()
				.collect(Collectors.groupingBy((mapperData -> {
					return ((Map) mapperData).get("sourceMessage");
				}), HashMap::new, Collectors.toCollection(ArrayList::new)))
				.entrySet().stream()
				.collect(Collectors.toMap(item -> {
					return (String)item.getKey();}, item -> { 
						return buildMappingConfig(item.getValue(), formulaCodeGenerator, compiler) ;
						
					}));
		
		/*
		return ((List<LinkedHashMap<String, Object>>)mappingData.get("mapping")).stream().map(mapperMetaObj -> {
			Map<String, Object> mappingMetaData = (LinkedHashMap<String, Object>) mapperMetaObj;
			try {
				ICondition iConditionObj = TestEngineFlow.buildCondition((String) mappingMetaData.get("mappingCondition"),
						formulaCodeGenerator, compiler);
				if (iConditionObj != null)
					return new MappingConfig((String) mappingMetaData.get("destMessage"),iConditionObj);
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			return new MappingConfig((String) mappingMetaData.get("destMessage"),new ICondition() {
				
				@Override
				public boolean check(IMessage message, IFlowContext ctx, Map<String, Object> params) {
					return false;
				}
			});
		}).collect(Collectors.toList());*/
	}

	private static List<MappingConfig> buildMappingConfig(ArrayList<LinkedHashMap<String, Object>> mappingData,
			FormulaCodeGenerator formulaCodeGenerator, JavaCodeCompiler compiler) {
		return mappingData.stream().map(mapperMetaObj -> {
			Map<String, Object> mappingMetaData = (LinkedHashMap<String, Object>) mapperMetaObj;
			try {
				ICondition iConditionObj = TestEngineFlow.buildCondition((String) mappingMetaData.get("mappingCondition"),
						formulaCodeGenerator, compiler);
				if (iConditionObj != null){
					MappingConfig mappingConfig = new MappingConfig((String) mappingMetaData.get("destMessage"),iConditionObj);
					mappingConfig.setDestinationName((String) mappingMetaData.get("destNode"));
					return mappingConfig;
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			MappingConfig mappingConfig = new MappingConfig((String) mappingMetaData.get("destMessage"),new ICondition() {
				
				@Override
				public boolean check(IMessage message, IFlowContext ctx, Map<String, Object> params) {
					return true;
				}
			});
			mappingConfig.setDestinationName((String) mappingMetaData.get("destNode"));
			return mappingConfig;
		}).collect(Collectors.toList());
	}
}

#!/bin/bash
java --add-opens java.base/jdk.internal.misc=ALL-UNNAMED -Dio.netty.tryReflectionSetAccessible=true -Dapplication.properties.path=C:/Code/Mapper_Distributions/virtualization/ditributions/runtimeConfig.properties -Dcache.config.path=C:/Code/Mapper_Distributions/virtualization/ditributions/ehcache2.xml -jar @executable_name@

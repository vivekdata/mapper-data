package com.opusconsulting.pegasus.runtime.scheduler;

import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.opusconsulting.pegasus.channel.tcp.TCPClientChannel;
import com.opusconsulting.pegasus.common.event.IEventPublisher;
import com.opusconsulting.pegasus.event.impl.EventContext;
import com.opusconsulting.pegasus.format.iso.metadata.EndPointDetail;
import com.opusconsulting.pegasus.format.iso.metadata.EndPointType;
import com.opusconsulting.pegasus.format.iso.metadata.EndpointProtocol;
import com.opusconsulting.pegasus.runtime.IConstants;
import com.opusconsulting.pegasus.runtime.mapper.layman.ClientConnectionFactory;

@Component
@Scope("prototype")
public class ScheduledTimer {
	
	private static final Logger _logger = LoggerFactory.getLogger(ScheduledTimer.class);
	
	@Lazy
	@Autowired
	List<EndPointDetail> endpoints;
	
	@Inject
	@Lazy
	IEventPublisher heartbeatHandlerPublisher;
	
	@Autowired
	ClientConnectionFactory clientConnectionFactory;

	public void scheduler(String nodeName , int time) {
		ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
		scheduler.scheduleAtFixedRate(new HeartBeat(nodeName), 30, time,
				TimeUnit.SECONDS);
	}

	public class HeartBeat implements Runnable {

		private String nodeName;
		
		public HeartBeat(String nodeName) {
			this.nodeName = nodeName;
		}

		@Override
		public void run() {
			endpoints.stream().filter(endpoint -> {
				return EndPointType.CLIENT.equals(endpoint.getType());
			}).forEach((endpoint -> {
				if (EndpointProtocol.TCP.equals(endpoint.getProtocol())
						&& nodeName.equalsIgnoreCase(endpoint.getNodeName())) {
					TCPClientChannel clientChannel = (TCPClientChannel) clientConnectionFactory
							.getClientChannel(endpoint.getNodeName());
					if (!clientChannel.isTCPClientChannelOpen()) {
						EventContext eventContext = new EventContext();
						eventContext.set(IConstants.EVENT_CTX_NODE_NAME_KEY, endpoint.getNodeName());
						eventContext.set(IConstants.EVENT_CTX_ADDRESS, endpoint.getAddress());
						eventContext.set(IConstants.EVENT_CTX_PORT, endpoint.getPort());
						heartbeatHandlerPublisher.publish("RECONNECT", eventContext);
					} else {
						_logger.info("Application connected to client for node {}" , nodeName);
					}
				}
			}));
		}
	}
}

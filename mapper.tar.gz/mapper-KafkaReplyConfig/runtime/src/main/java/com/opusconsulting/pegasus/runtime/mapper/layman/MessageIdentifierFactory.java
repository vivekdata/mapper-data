package com.opusconsulting.pegasus.runtime.mapper.layman;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

@Component
public class MessageIdentifierFactory {

	
	@Lazy
	@Autowired
	List<IMessageIdentifier> messageIdentifiers;
	
	    public IMessageIdentifier getIdentifier(String origin) {
    	if(messageIdentifiers != null){
    		
			final Optional<IMessageIdentifier> identifier =  messageIdentifiers.stream().filter(identifierConfig ->{
				return identifierConfig.getOriginName().equalsIgnoreCase(origin);
			}).findFirst();
			if(identifier.isPresent()){
				return identifier.get();
			} else {
				return null;
			}
		} else {
			return null;
		}
    }

}

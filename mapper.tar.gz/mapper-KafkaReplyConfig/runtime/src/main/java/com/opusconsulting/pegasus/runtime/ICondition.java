package com.opusconsulting.pegasus.runtime;

import java.util.Map;

import com.opusconsulting.pegasus.flow.IFlowContext;

public interface ICondition {
    boolean check(IMessage message, IFlowContext ctx, Map<String, Object> params);
}

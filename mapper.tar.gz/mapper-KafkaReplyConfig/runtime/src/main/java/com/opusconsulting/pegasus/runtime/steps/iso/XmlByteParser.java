package com.opusconsulting.pegasus.runtime.steps.iso;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import com.opusconsulting.pegasus.common.resource.exception.ApplicationException;
import com.opusconsulting.pegasus.format.iso.metadata.MessageFieldDetail;
import com.opusconsulting.pegasus.format.iso.metadata.XmlFieldMetaData;
import com.opusconsulting.pegasus.runtime.DefaultIMessage;
import com.opusconsulting.pegasus.runtime.IMessage;
import com.opusconsulting.pegasus.runtime.XmlIMessage;
import com.opusconsulting.pegasus.runtime.mapper.layman.MessageKey;

public class XmlByteParser implements ByteParser {
	private SAXParser saxParser;
	private List<MessageFieldDetail<XmlFieldMetaData>> messageFields;
	private static final Logger _logger = LoggerFactory.getLogger(XmlByteParser.class);

	public XmlByteParser() throws ApplicationException {
		super();
		final SAXParserFactory saxParserFactory = SAXParserFactory.newInstance();
		try {
			this.saxParser = saxParserFactory.newSAXParser();
		} catch (ParserConfigurationException | SAXException e) {
			_logger.error("Unable to instantiate XML Byte parser. Please check the configuration.");
			throw new ApplicationException("Unable to instantiate XML Byte parser", e);
		}
	}

	public XmlByteParser(List<MessageFieldDetail<XmlFieldMetaData>> messageFields) {
		super();
		this.messageFields = messageFields;
	}

	@Override
	public IMessage unpack(byte[] input, String nodeName, Boolean isEventReply) {
		try {
			final XmlIMessage message = new XmlIMessage(null, "ROOT", null);//TODO need to set the node meta data
			final SaxParserHandler handler = new SaxParserHandler(message);
			saxParser.parse(new ByteArrayInputStream(input), handler);
			return message;
		} catch (SAXException | IOException e) {
			_logger.error("Error while processing the XML meesage bytes.", e);
			return null;
		}
	}

	@Override
	public byte[] pack(IMessage message, String nodeName, Boolean isEventReply) {
		final XmlIMessage xmlIMessage = format(message);
		String xmlReponse = generateXML(xmlIMessage);
		return xmlReponse.getBytes();
	}

	private XmlIMessage format(IMessage message) {
		// A dummy ROOT element will be created and at the end it will be ignore
		// while creating the XML
		XmlIMessage rootXmlMessage = new XmlIMessage(message.getNodeMetaData(), "ROOT", null);
		((DefaultIMessage) message).formatToXml(this.messageFields, rootXmlMessage);
		return rootXmlMessage.getChildren().get(0);
	}

	private String generateXML(XmlIMessage iMessage) {
		String xmlString = null;
		try {
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();

			Document doc = docBuilder.newDocument();
			Element rootElement = buildRootElement(iMessage, doc);

			rootElement.appendChild(addChildElements(iMessage, doc, rootElement));

			// write the content into xml file
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			DOMSource source = new DOMSource(doc);
			StringWriter writer = new StringWriter();
			StreamResult result = new StreamResult(writer);

			transformer.transform(source, result);

			xmlString = writer.toString();

		} catch (ParserConfigurationException pce) {
			_logger.error("Error while generating the XML meesage bytes.", pce);
		} catch (TransformerException tfe) {
			_logger.error("Error while generating the XML meesage bytes.", tfe);
		}
		return xmlString;
	}

	private Element buildRootElement(XmlIMessage iMessage, Document doc) {
		Element rootElement = doc.createElement(iMessage.getElementName());
		final Map<String, Object> attributesMap = iMessage.getAttributes();
		if (attributesMap != null) {
			Set<String> attributeNames = attributesMap.keySet();
			for (String name : attributeNames) {
				if (iMessage.getAttrribute(name) != null) {
					Attr attr = doc.createAttribute(name);
					attr.setValue((String) attributesMap.get(name));
					rootElement.setAttributeNode(attr);
				}
			}
		}
		doc.appendChild(rootElement);
		return rootElement;
	}

	private Element addChildElements(XmlIMessage childXMLMessage, Document document, Element parentElement) {
		Element element = null;
		try {
			if (childXMLMessage.getChildren() != null && childXMLMessage.getChildren().size() > 0) {
				for (XmlIMessage iMessage : childXMLMessage.getChildren()) {
					element = document.createElement(iMessage.getElementName());
					if (iMessage.getElementValue() != null)
						element.appendChild(document.createTextNode((String) iMessage.getElementValue()));

					Map<String, Object> attributesMap = iMessage.getAttributes();
					if (attributesMap != null) {
						Set<String> attributeNames = attributesMap.keySet();
						for (String name : attributeNames) {
							if (iMessage.getAttrribute(name) != null) {
								Attr attr = document.createAttribute(name);
								attr.setValue((String) attributesMap.get(name));
								element.setAttributeNode(attr);
							}
						}
					}

					parentElement.appendChild(element);
					if (iMessage.getChildren() != null && iMessage.getChildren().size() > 0)
						addChildElements(iMessage, document, element);
				}
			}

		} catch (Exception e) {
			_logger.error("Error while generating the XML meesage bytes. Error in adding child elements", e);
		}
		return element;
	}

	private class SaxParserHandler extends DefaultHandler {

		private XmlIMessage message;

		public SaxParserHandler(XmlIMessage message) {
			this.message = message;
		}

		private XmlIMessage getMessage() {
			return message;
		}

		@Override
		public void characters(char[] ch, int start, int length) throws SAXException {
			final String value = String.valueOf(ch, start, length);
			if (!value.isEmpty()) {
				this.message.setValue(new MessageKey(this.message.getElementName()), value);
			}
		}

		@Override
		public void startElement(String uri, String localName, String qName, Attributes attributes)
				throws SAXException {
			XmlIMessage message = new XmlIMessage(null, qName, null);
			if (attributes != null && attributes.getLength() != 0) {
				for (int i = 0; i < attributes.getLength(); i++) {
					message.addAttribute(attributes.getQName(i), attributes.getValue(i));
				}
			}
			this.message.addChildren(message);
			this.message = message;
		}

		@Override
		public void endElement(String uri, String localName, String qName) throws SAXException {
			this.message = this.message.getParent();
		}
	}
}

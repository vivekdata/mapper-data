package com.opusconsulting.pegasus.runtime.flow;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.opusconsulting.pegasus.flow.metadata.IFlowMetaData;
import com.opusconsulting.pegasus.flow.metadata.LinkInstanceInfo;
import com.opusconsulting.pegasus.flow.metadata.StepInstanceInfo;
import com.opusconsulting.pegasus.flow.metadata.impl.FlowMetaData;
import com.opusconsulting.pegasus.format.NodeFormat;
import com.opusconsulting.pegasus.format.iso.metadata.ISONodeDetail;
import com.opusconsulting.pegasus.format.iso.metadata.MessageDetail;
import com.opusconsulting.pegasus.format.iso.metadata.NodeDetail;
import com.opusconsulting.pegasus.format.iso.metadata.XmlNodeDetail;
import com.opusconsulting.pegasus.runtime.IConstants;

@Component
public class SerializeWorkflow extends AbstractIWorkflow {
	private static final Logger _logger = LoggerFactory.getLogger(SerializeWorkflow.class);
	private static final String SERIALIZER_STEPNAME = "serializer";
	private static final String HTTP_SERIALIZER_STEPNAME = "httpSerializer";
	
	@Override
	protected List<IFlowMetaData> buildFlowMetaDatas(Map<String, Object> workFlowData) {
		if(workFlowData == null){
			_logger.error("Serializer workflow intiation failed due to missing workflow meta data.");
			return null;
		}
		
		Map<String, NodeDetail<MessageDetail>> nodeDetails = (Map<String, NodeDetail<MessageDetail>>) workFlowData
				.get(IConstants.NODE_DETAILS_CONFIGS);
		
		return nodeDetails.entrySet().stream().map((nodeDetailEntry) -> {
			if(nodeDetailEntry.getValue().getClass().isAssignableFrom(ISONodeDetail.class)){
				return buildIsoFlowMetaData(nodeDetailEntry.getValue());
			}else if(nodeDetailEntry.getValue().getFormat().equals(NodeFormat.JSON)){
				return buildJsonFlowMetaData(nodeDetailEntry.getValue());
			}
			else if(nodeDetailEntry.getValue().getClass().isAssignableFrom(XmlNodeDetail.class) && nodeDetailEntry.getValue().getFormat().equals(NodeFormat.XML)){
				return buildXmlFlowMetaData(nodeDetailEntry.getValue());
			}
			else {
				return null;
			}
		}).collect(Collectors.toList());
	}

	private IFlowMetaData buildIsoFlowMetaData(NodeDetail<MessageDetail> nodeDetail) {
		FlowMetaData flowMetaData = new FlowMetaData();
		flowMetaData.setName(prepareMetaDataName(nodeDetail.getName(), SERIALIZE));
		
		Map<String, Object> serializerProps = new HashMap<>();
		serializerProps.put("nodeDetail", nodeDetail);
		
		StepInstanceInfo serializerStepInstanceInfo = new StepInstanceInfo().setName(SERIALIZER_STEPNAME)
				.setStepName("ISOSerializer").setProperties(serializerProps);
		
		createSerializerStepAndLink(flowMetaData, serializerStepInstanceInfo,nodeDetail,SERIALIZER_STEPNAME);

		return flowMetaData;
	}
	
	private IFlowMetaData buildXmlFlowMetaData(NodeDetail<MessageDetail> nodeDetail) {
		FlowMetaData flowMetaData = new FlowMetaData();
		flowMetaData.setName(prepareMetaDataName(nodeDetail.getName(), SERIALIZE));
		Map<String, Object> xmlDeserializerProps = new HashMap<>();
		
		xmlDeserializerProps.put("nodeDetail", nodeDetail);
		
		StepInstanceInfo serializerStepInstanceInfo = new StepInstanceInfo().setName(SERIALIZER_STEPNAME)
				.setStepName("XMLSerializer").setProperties(xmlDeserializerProps);

		createSerializerStepAndLink(flowMetaData, serializerStepInstanceInfo,nodeDetail,SERIALIZER_STEPNAME);
		return flowMetaData;
	}
	
	private IFlowMetaData buildJsonFlowMetaData(NodeDetail<MessageDetail> nodeDetail) {
		FlowMetaData flowMetaData = new FlowMetaData();
		flowMetaData.setName(prepareMetaDataName(nodeDetail.getName(), SERIALIZE));
		Map<String, Object> JsonSerializerProps = new HashMap<>();
		
		JsonSerializerProps.put("nodeDetail", nodeDetail);
		
		StepInstanceInfo serializerStepInstanceInfo = new StepInstanceInfo().setName(SERIALIZER_STEPNAME)
				.setStepName("JSONSerializer").setProperties(JsonSerializerProps);

		createSerializerStepAndLink(flowMetaData, serializerStepInstanceInfo,nodeDetail,SERIALIZER_STEPNAME);
		return flowMetaData;
	}
	
	private void createSerializerStepAndLink(FlowMetaData flowMetaData,
			StepInstanceInfo serializerStepInstanceInfo,NodeDetail<MessageDetail> nodeDetail,String stepName) {
		Map<String, Object> httpSerializerProps = new HashMap<>();
		httpSerializerProps.put("nodeDetail", nodeDetail);
		StepInstanceInfo deserializerStepInstanceInfoHttpRequest = new StepInstanceInfo().setName(HTTP_SERIALIZER_STEPNAME)
				.setStepName("httpRequestParamSerializer").setProperties(httpSerializerProps);
		
		final LinkInstanceInfo deserializerStep = buildLinkInstance(stepName, HTTP_SERIALIZER_STEPNAME);

		flowMetaData.setStartStepInstanceName(SERIALIZER_STEPNAME)
				.setStepInstancesInfo(Arrays.asList(serializerStepInstanceInfo,deserializerStepInstanceInfoHttpRequest))
				.setLinkInstancesInfo(Arrays.asList(deserializerStep));
	}
}

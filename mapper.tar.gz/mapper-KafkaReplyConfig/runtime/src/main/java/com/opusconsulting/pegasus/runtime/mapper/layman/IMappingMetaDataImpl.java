package com.opusconsulting.pegasus.runtime.mapper.layman;

public class IMappingMetaDataImpl implements IMappingMetaData{

	String origin;
	String target;
	String originalMessageName;
	String targetMessageName;

	public IMappingMetaDataImpl(String origin, String target, String originalMessageName, String targetMessageName) {
		super();
		this.origin = origin;
		this.target = target;
		this.originalMessageName = originalMessageName;
		this.targetMessageName = targetMessageName;
	}

	@Override
	public String getOrigin() {
		return this.origin;
	}

	@Override
	public String getTarget() {
		return this.target;
	}

	@Override
	public String getOriginMessageName() {
		return this.originalMessageName;
	}

	@Override
	public String getTargetMessageName() {
		return this.targetMessageName;
	}

}

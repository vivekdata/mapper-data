package com.opusconsulting.pegasus.runtime.steps.iso;

import java.util.ArrayList;
import java.util.List;

import com.opusconsulting.pegasus.format.iso.metadata.ISOMessageDetail;
import org.jpos.iso.ISOBasePackager;
import org.jpos.iso.ISOException;
import org.jpos.iso.ISOFieldPackager;
import org.jpos.iso.ISOMsg;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.opusconsulting.pegasus.common.resource.exception.ApplicationException;
import com.opusconsulting.pegasus.format.iso.metadata.ISOFieldMetaData;
import com.opusconsulting.pegasus.format.message.jpos.JPOSDataTypeFactory;
import com.opusconsulting.pegasus.runtime.DefaultIMessage;
import com.opusconsulting.pegasus.runtime.IMessage;
import com.opusconsulting.pegasus.runtime.mapper.layman.NodeMetaData;

public class ISOBufferParser implements ByteParser {
	private static final Logger _logger = LoggerFactory.getLogger(ISOBufferParser.class);
	private JPOSParserWithJSONConfig config;
	private List<ISOFieldMetaData> fieldDetails;

	List<ISOMessageDetail> messages;
	private List<Integer> tagFieldDetails;

	public static final String TLV_DATATYPE = "Tlv";

	public ISOBufferParser(List<ISOFieldMetaData> fieldDetails, List<ISOMessageDetail> messages) {
		super();
		this.fieldDetails = fieldDetails;
		init(fieldDetails);

		this.messages = messages;

		// Add all Tag dataType Fields
		tagFieldDetails = new ArrayList<>();
		int i = 0;
		for ( ISOFieldMetaData isoFieldMetaData: fieldDetails ) {
			if(String.valueOf(isoFieldMetaData.getType()).equals(TLV_DATATYPE)) {
				tagFieldDetails.add(i);
			}
			i++;
		}
	}
	
	private void init(List<ISOFieldMetaData> fieldDetails) {
		this.config = new JPOSParserWithJSONConfig(fieldDetails);
	}

	/**
	 * Unpacks the bytebuf to IMessage
	 * @param input
	 * @return
	 * @throws ApplicationException 
	 */
	@Override
	public IMessage unpack(byte[] input, String nodeName, Boolean isEventReply) throws ApplicationException {
		if(this.config == null)
			return null;
		final ISOMsg msg = new ISOMsg();
		msg.setPackager(this.config);
		try {
			msg.unpack(input);
			return format(msg, messages, nodeName, isEventReply);
		} catch (ISOException e) {
			_logger.error("Error while unpacking the iso message bytes.", e);
			throw new ApplicationException("Error while unpacking the iso message bytes.", e);
		} catch (Exception exception){
			_logger.error("Error while unpacking the iso message bytes.", exception);
			throw new ApplicationException("Error while unpacking the iso message bytes.", exception);
		}
	}
	
	/**
	 * Pack the IMessage to bytebuf
	 * @param message
	 * @return
	 */
	@Override
	public byte[] pack(IMessage message, String nodeName, Boolean isEventReply) throws ApplicationException{
		if(this.config == null)
			return null;
		try {
			final ISOMsg msg = format(message, messages, nodeName, isEventReply);
			msg.setPackager(this.config);
			return msg.pack();
		} catch (ISOException e) {
			_logger.error("Error while packing the iso message bytes.", e);
			throw new ApplicationException("Error while packing the iso message bytes.", e);
		} catch (Exception exception){
			_logger.error("Error while packing the iso message bytes.", exception);
			throw new ApplicationException("Error while packing the iso message bytes.", exception);
		}
	}
	
	private DefaultIMessage format(final ISOMsg msg, List<ISOMessageDetail> messages, String nodeName, Boolean isEventReply) throws ISOException{

		final DefaultIMessage message = new DefaultIMessage(new NodeMetaData(null));
		if(null != this.tagFieldDetails && this.tagFieldDetails.size() == 0)
			message.build(msg, this.fieldDetails);
		else
			message.build(msg, this.fieldDetails, this.tagFieldDetails);
		return message;
	}
	
	private ISOMsg format(final IMessage message, List<ISOMessageDetail> messages, String nodeName, Boolean isEventReply) throws ISOException{

		if(null != this.tagFieldDetails && this.tagFieldDetails.size() == 0)
			return ((DefaultIMessage)message).format(this.fieldDetails);
		else
			return ((DefaultIMessage)message).format(this.fieldDetails, this.tagFieldDetails);
	}

	@SuppressWarnings("unused")
	private class JPOSParserWithJSONConfig extends ISOBasePackager {

		public JPOSParserWithJSONConfig(List<ISOFieldMetaData> fieldDetails) {
			super();
			initializePackager(fieldDetails);
		}

		private void initializePackager(List<ISOFieldMetaData> fieldDetails) {
			final ISOFieldPackager jposfieldPackagers[] = new ISOFieldPackager[fieldDetails.size()];
			int iFieldIndex = 0;
			for (ISOFieldMetaData isoFields : fieldDetails) {
				if (iFieldIndex == 0) {
					jposfieldPackagers[iFieldIndex++] = JPOSDataTypeFactory.getMTIPackager(isoFields.getLength(), isoFields.getName());
					continue;
				} else if (iFieldIndex == 1) {
					jposfieldPackagers[iFieldIndex++] = JPOSDataTypeFactory
							.getBitMapPackager(isoFields.getName(), isoFields.getEncodingType(), isoFields.getLength());
					continue;
				}
				ISOFieldPackager fieldPackager = buildISOMessageFieldPackager(isoFields);
				if (fieldPackager != null)
					jposfieldPackagers[iFieldIndex++] = fieldPackager;
			}
			setFieldPackager(jposfieldPackagers);
		}

		private ISOFieldPackager buildISOMessageFieldPackager(ISOFieldMetaData isoFields) {
			return JPOSDataTypeFactory.getFieldPackager(isoFields.getName(), isoFields.getEncodingType(), isoFields.getPrefixEncodingType(),
					isoFields.getType(), isoFields.getLength(), isoFields.getSizeType());
		}
	}
}
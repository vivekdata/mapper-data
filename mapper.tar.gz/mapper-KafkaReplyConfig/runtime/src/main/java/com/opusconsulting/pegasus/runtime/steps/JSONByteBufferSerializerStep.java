package com.opusconsulting.pegasus.runtime.steps;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.opusconsulting.pegasus.common.resource.exception.ApplicationException;
import com.opusconsulting.pegasus.flow.IFlowContext;
import com.opusconsulting.pegasus.flow.impl.AbstractStepInstance;
import com.opusconsulting.pegasus.format.iso.metadata.MessageDetail;
import com.opusconsulting.pegasus.format.iso.metadata.NodeDetail;
import com.opusconsulting.pegasus.runtime.IConstants;
import com.opusconsulting.pegasus.runtime.IMessage;
import com.opusconsulting.pegasus.runtime.steps.iso.ByteParser;

public class JSONByteBufferSerializerStep extends AbstractStepInstance {

	private static final Logger _logger = LoggerFactory.getLogger(JSONByteBufferSerializerStep.class);

	private NodeDetail<MessageDetail> nodeDetail;

	@Autowired
	private ByteParser parser;

	@Override
	public <I, R> R process(IFlowContext context, I previousStepResult, Map<String, Object> flowProps) {

		// TODO Auto-generated method stub
		final IMessage message = (IMessage) flowProps.get(IConstants.FLOW_PROPS_TRANSFORMED_REQUEST_KEY);
		final String nodeName = (String) flowProps.get(IConstants.FLOW_PROPS_NODE_NAME_KEY);
		final Boolean isEventReply = (Boolean) flowProps.get(IConstants.IS_PROCESS_EVENT_MESSAGE_RECEIVED_KEY);

		if (message == null) {
			_logger.error("No message received to serialize from the flow properties of the step.");
			return (R) message;
		}

		try {
			return (R) this.parser.pack(message, nodeName, isEventReply);
		} catch (ApplicationException e) {
			_logger.error(e.getMessage(), e);
			onError(context, null, flowProps, e);
			return null;
		}
	}

	public void setNodeDetail(NodeDetail<MessageDetail> nodeDetail) {
		this.nodeDetail = nodeDetail;
	}

}

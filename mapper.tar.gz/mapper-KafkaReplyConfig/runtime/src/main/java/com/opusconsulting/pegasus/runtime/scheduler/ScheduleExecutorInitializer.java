package com.opusconsulting.pegasus.runtime.scheduler;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.opusconsulting.pegasus.runtime.RuntimeMain;

@Component
@EnableAutoConfiguration
//@Configuration
public class ScheduleExecutorInitializer extends RuntimeMain {

	private static final Logger _logger = LoggerFactory.getLogger(ScheduleExecutorInitializer.class);
	
	@Resource
	Environment environment;
	
	public void initializeNodeScheduler(String nodesName) {

		environment = getApplicationContext().getEnvironment();
		String[] nodes = nodesName.split(",");
		for (String nodeName : nodes) {
			String interval = environment.getProperty("node." + nodeName + ".reconnectTime");
			if (interval != null && !interval.isEmpty()) {
				_logger.info("Scheduler ******" + nodeName + " Interval " + interval);
				((ScheduledTimer) getApplicationContext().getBean("scheduledTimer")).scheduler(nodeName,
						Integer.parseInt(interval));
			}
		}
	}
}

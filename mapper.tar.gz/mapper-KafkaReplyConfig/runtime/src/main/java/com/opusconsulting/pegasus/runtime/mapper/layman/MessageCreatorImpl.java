package com.opusconsulting.pegasus.runtime.mapper.layman;

import java.util.List;
import java.util.Optional;

import com.opusconsulting.pegasus.runtime.DefaultIMessage;
import com.opusconsulting.pegasus.runtime.IMessage;

public class MessageCreatorImpl implements IMessageCreator {
	String origin;
	List<MessageConfig> messageConfigs;
	
	public MessageCreatorImpl(String origin, List<MessageConfig> messageConfigs) {
		super();
		this.origin = origin;
		this.messageConfigs = messageConfigs;
	}

	@Override
	public IMessage create(String targetMessageName) {
		if(messageConfigs != null){
			final Optional<IMessage> newMessage = messageConfigs.stream().filter((messageConfig) -> {
				return messageConfig.getName().equalsIgnoreCase(targetMessageName);
			}).map((config) -> {
				IMessage message = new DefaultIMessage(new NodeMetaData(getOriginName()));
				message.setMetaData(new IMessageMetaDataImpl(targetMessageName, config.isRequest()));
				return message;
			}).findFirst();
			if(newMessage.isPresent()){
				return newMessage.get();
			} else {
				return null;
			}
		}
		return null;
	}

	@Override
	public String getOriginName() {
		return this.origin;
	}

}

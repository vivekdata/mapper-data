package com.opusconsulting.pegasus.runtime.steps;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import com.opusconsulting.pegasus.format.iso.metadata.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.opusconsulting.pegasus.flow.IFlowContext;
import com.opusconsulting.pegasus.flow.impl.AbstractStepInstance;
import com.opusconsulting.pegasus.format.NodeFormat;
import com.opusconsulting.pegasus.runtime.IConstants;

@SuppressWarnings({"rawtypes", "unchecked"})
public class JSONReaderStep extends AbstractStepInstance {
	private static final Logger _logger = LoggerFactory.getLogger(JSONReaderStep.class);

	String filePath;
	public static final String TLV_DATATYPE = "Tlv";
	
	@PostConstruct
	void init() {

	}

	@Override
	public <I, R> R process(IFlowContext context, I previousStepResult, Map<String, Object> flowProps) {

		_logger.debug("JSON Configuration read started.");

		List<NodeDetail> nodesList = new ArrayList<NodeDetail>();
		Map<String, Object> workFlowInfoMap = new HashMap<String, Object>(2);
		List<VirtualizationDetails> virtualizationDetailsList = new ArrayList<>();
		try {
			String nodeJSONFilePath = (String) flowProps.get("nodeJSONFilePath");
			String nodeFiles[] = nodeJSONFilePath.split(IConstants.JSON_FILES_NAME_SEPERATOR);
			for (String nodeFileName : nodeFiles) {
				nodesList.addAll(processNodeJSONFile(nodeFileName));
			}

			String workFlowJSONFilePath = (String) flowProps.get("workFlowJSONFilePath");
			String workFlowJSONFiles[] = workFlowJSONFilePath.split(IConstants.JSON_FILES_NAME_SEPERATOR);

			for (String workFlowJSONFileName : workFlowJSONFiles) {
				Map<String, Object> jsonFileWorkFlowMap = processWorkFlowsJSONFile(workFlowJSONFileName, nodesList);

				// below code added because, now we are processing the more than
				// one workflow json file, and method returns the map.
				// we need to check every time whether the workFlowInfoMap contains key (mappingConfigInfo,routingDetails) or not.
				// If it is present, then we need to pull the same and add the jsonFileWorkFlowMap returned information and again push it into workFlowInfoMap.
				
				if (workFlowInfoMap.containsKey("mappingConfigInfo")) {
					Map<String, List<MappingDetails>> alreadyAddedMappingConfig = (Map<String, List<MappingDetails>>) workFlowInfoMap
							.get("mappingConfigInfo");
					Map<String, List<MappingDetails>> mappingConfig = (Map<String, List<MappingDetails>>) jsonFileWorkFlowMap
							.get("mappingConfigInfo");
					Set<String> keys = mappingConfig.keySet();
					for (String mapKey : keys) {
						alreadyAddedMappingConfig.put(mapKey, mappingConfig.get(mapKey));
					}
					workFlowInfoMap.put("mappingConfigInfo", alreadyAddedMappingConfig);
				} else {
					workFlowInfoMap.put("mappingConfigInfo", jsonFileWorkFlowMap.get("mappingConfigInfo"));
				}

				if (workFlowInfoMap.containsKey("routingDetails")) {
					List<RoutingDetails> routingDetailsList = (List<RoutingDetails>) workFlowInfoMap
							.get("routingDetails");
					routingDetailsList.addAll((List<RoutingDetails>) jsonFileWorkFlowMap.get("routingDetails"));
					workFlowInfoMap.put("routingDetails", routingDetailsList);

				} else {
					workFlowInfoMap.put("routingDetails",
							(List<RoutingDetails>) jsonFileWorkFlowMap.get("routingDetails"));
				}
			}

			String virtulizationJSONFilePath = (String) flowProps.get("virtulizationJSONFilePath");
			String virtulizationJSONFiles[] = virtulizationJSONFilePath.split(IConstants.JSON_FILES_NAME_SEPERATOR);

			for (String virtulizationJSONFileName : virtulizationJSONFiles) {
				virtualizationDetailsList.addAll(processVirtulizationJSONFile(virtulizationJSONFileName));
			}
		} catch (JsonParseException e) {
			_logger.error("Error while reading the configuration. Please check configuration provided.", e);
			onError(context, previousStepResult, flowProps, e);
		} catch (JsonMappingException e) {
			_logger.error("Error while reading the configuration. Please check configuration provided.", e);
			onError(context, previousStepResult, flowProps, e);
		} catch (IOException e) {
			_logger.error("Error while reading the configuration. Please check configuration provided.", e);
			onError(context, previousStepResult, flowProps, e);
		} catch (Exception e) {
			_logger.error("Error while reading the configuration. Please check configuration provided.", e);
			onError(context, previousStepResult, flowProps, e);
		}

		context.put("nodes", nodesList);
		context.put("mappingConfigs", workFlowInfoMap.get("mappingConfigInfo"));
		context.put("routings", workFlowInfoMap.get("routingDetails"));
		context.put("virtualizationDetails", virtualizationDetailsList);
		_logger.debug("Successfully performed loading nodes, workflows, virtualization information.");
		return (R) previousStepResult;
	}
	
	
	private NodeFormat evaluateFormat(List supportedFormats) {
		if(supportedFormats == null || supportedFormats.isEmpty()) return null;
		return NodeFormat.valueOf((String)supportedFormats.get(0));
	}

	private VirtualizationRuleDetails buildTreeRuleDetails(Map<String, Object> ruleData){
		VirtualizationRuleDetails ruleDetails = new VirtualizationRuleDetails();
		ruleDetails.setName((String)ruleData.get("title"));
		ruleDetails.setRuleType((String)ruleData.get("ruleType"));
		ruleDetails.setFieldName((String)ruleData.get("fieldName"));
		ruleDetails.setFormulae((String)ruleData.get("formulae"));
		ruleDetails.setMessageMetaDataMsgName((String)ruleData.get("messageName"));
		boolean messageMetaDataMsgRequest = ruleData.get("isRequest") == null ? false : (Boolean)ruleData.get("isRequest");
		ruleDetails.setMessageMetaDataMsgRequest(messageMetaDataMsgRequest);
		
		List<LinkedHashMap<String, Object>> childRuleData = (List<LinkedHashMap<String, Object>>) ruleData
				.get("children");
		if(childRuleData != null){
			childRuleData.stream().forEach(childRuleDetail -> {
				ruleDetails.addChildRule(buildTreeRuleDetails(childRuleDetail));
			});
		}
	
		return ruleDetails;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	private static Map<String, Object> readJsonMetaData(String nodeMetaDataFile)
			throws IOException, JsonParseException, JsonMappingException {
		ObjectMapper mapper = new ObjectMapper();
		Map<String, Object> obj = mapper.readValue(new File(nodeMetaDataFile), Map.class);
		return obj;
	}

	private List<ISOMessageDetail> buildISOMessageMetaData(List<Object> messages, List<ISOFieldMetaData> fieldList) {
		return messages.stream().map(message -> {
			Map<String, Object> messageData = (LinkedHashMap<String, Object>) message;
			ISOMessageDetail messageDetail = new ISOMessageDetail((String) messageData.get("name"), (String) messageData.get("description"),
					MessageKind.valueOf((String) messageData.get("type")),
					(String) messageData.get("messageIdentification"));
			messageDetail.setMessageFields(buildISOMessageFields((List<Map<String, Object>>)messageData.get("fields"), fieldList));
			return messageDetail;
		}).collect(Collectors.toList());
	}
	
	private List<XmlMessageDetails> buildXMLMessageMetaData(List<Object> messages) {
		return messages.stream().map(message -> {
			Map<String, Object> messageData = (LinkedHashMap<String, Object>) message;
			XmlMessageDetails messageDetail = new XmlMessageDetails((String) messageData.get("name"), (String) messageData.get("description"),
					MessageKind.valueOf((String) messageData.get("type")),
					(String) messageData.get("messageIdentification"));
			messageDetail.setMessageFields(buildXmlMessageFields((List<Map<String, Object>>)messageData.get("fields")));
			return messageDetail;
		}).collect(Collectors.toList());
	}

	private List<ISOFieldMetaData> buildFieldMetaData(List<Object> fields) {


		return fields.stream().map(field -> {
			Map<String, Object> fieldData = (LinkedHashMap<String, Object>) field;


			FieldSizeType fieldType = getFieldSizeType((String) fieldData.get("type"));
			if (FieldSizeType.Fixed.equals(fieldType)) {
				return ISOFieldMetaData.fixed((String) fieldData.get("name"), (String) fieldData.get("description"),
						getFieldDataType(fieldData.get("dataType")),
						Integer.parseInt((String) fieldData.get("size")),
						getEncodingType((String) fieldData.get("dataEncoding")));
			} else if (FieldSizeType.Variable.equals(fieldType)) {

				return ISOFieldMetaData.variable((String) fieldData.get("name"), (String) fieldData.get("description"),
						getFieldDataType(fieldData.get("dataType")),
						getEncodingType((String) fieldData.get("dataEncoding")),
						Integer.parseInt((String) fieldData.get("size")), null);

			} else {
				System.out.println("Field Name: " + fieldData.get("name") + ", Field Type: " + fieldData.get("type"));
			}
			return null;
		}).collect(Collectors.toList());
	}
	
	private FieldDataType getFieldDataType(Object fieldDataTypeValue){
		return (fieldDataTypeValue == null || ((String) fieldDataTypeValue).trim().length() == 0) ? null
				: FieldDataType.valueOf((String) fieldDataTypeValue);
	}
	
	private EncodingType getEncodingType(Object encodingTypeValue){
		return (encodingTypeValue == null || ((String) encodingTypeValue).trim().length() == 0) ? null
				: EncodingType.valueOf((String) encodingTypeValue);
	}
	
	private FieldSizeType getFieldSizeType(Object fieldSizeTypeValue){
		return (fieldSizeTypeValue == null || ((String) fieldSizeTypeValue).trim().length() == 0) ? null
				: FieldSizeType.valueOf((String) fieldSizeTypeValue);
	}
	
	private List<MessageFieldDetail<ISOFieldMetaData>> buildISOMessageFields(final List<Map<String, Object>> msgFieldList, final List<ISOFieldMetaData> fieldList) {
		return msgFieldList.stream().map(msgFieldMap -> {
			ISOFieldMetaData field = fieldList.stream().filter(fieldMetaData -> {
				return fieldMetaData.getName().equalsIgnoreCase((String)msgFieldMap.get("name"));
			}).findFirst().get();
			
			final ExistenceType existenceType = (msgFieldMap.get("required") == null ? ExistenceType.Optional
					: ((Boolean) msgFieldMap.get("required") ? ExistenceType.Mandatory : ExistenceType.Optional));
			return new MessageFieldDetail<ISOFieldMetaData>(existenceType, field);
		}).collect(Collectors.toList());
	}
	
	private List<MessageFieldDetail<XmlFieldMetaData>> buildXmlMessageFields(
			final List<Map<String, Object>> msgFieldList) {
		final List<MessageFieldDetail<XmlFieldMetaData>> returnResult = new ArrayList<>();
		msgFieldList.stream().forEach(msgFieldMap -> {
			final XmlFieldType fieldType = XmlFieldType.valueOf((String) msgFieldMap.get("dataType"));
			XmlFieldMetaData field = new XmlFieldMetaData((String) msgFieldMap.get("name"),
					(String) msgFieldMap.get("name"), fieldType);
			field.setxPath((String) msgFieldMap.get("xmlPath"));
			final ExistenceType existenceType = (msgFieldMap.get("required") == null ? ExistenceType.Optional
					: ((Boolean) msgFieldMap.get("required") ? ExistenceType.Mandatory : ExistenceType.Optional));
			final MessageFieldDetail fieldDetail = new MessageFieldDetail<XmlFieldMetaData>(existenceType, field);
			if(msgFieldMap.get("children") != null){
				List<MessageFieldDetail<XmlFieldMetaData>> children = buildXmlMessageFields(((java.util.List)msgFieldMap.get("children")));
				((XmlFieldMetaData)fieldDetail.getField()).setChildren(children);
			}
			returnResult.add(fieldDetail);
		});
		return returnResult;
		
		/*return msgFieldList.stream().map(msgFieldMap -> {
			final XmlFieldType fieldType = XmlFieldType.valueOf((String) msgFieldMap.get("dataType"));
			XmlFieldMetaData field = new XmlFieldMetaData((String) msgFieldMap.get("name"),
					(String) msgFieldMap.get("name"), fieldType);
			field.setxPath((String) msgFieldMap.get("xmlPath"));
			final ExistenceType existenceType = (msgFieldMap.get("required") == null ? ExistenceType.Optional
					: ((Boolean) msgFieldMap.get("required") ? ExistenceType.Mandatory : ExistenceType.Optional));
			final MessageFieldDetail fieldDetail = new MessageFieldDetail<XmlFieldMetaData>(existenceType, field);
			if(msgFieldMap.get("children") != null){
				List<MessageFieldDetail<XmlFieldMetaData>> children = buildXmlMessageFields(((java.util.List)msgFieldMap.get("children")));
				((XmlFieldMetaData)fieldDetail.getField()).setChildren(children);
			}
			return fieldDetail;
		}).collect(Collectors.toList());*/
	}
	
	
	private List<NodeDetail> processNodeJSONFile(String nodeJSONFile)
			throws JsonParseException, JsonMappingException, IOException {
		List<NodeDetail> nodeDetailsList = new ArrayList<NodeDetail>();

		ObjectMapper mapper = new ObjectMapper();
		List<LinkedHashMap<String, Object>> nodesList = mapper.readValue(new File(nodeJSONFile), List.class);
		for (LinkedHashMap<String, Object> nodesDetails : nodesList) {
			final NodeFormat nodeFormat = evaluateFormat((List) nodesDetails.get("supportedFormats"));
			if (NodeFormat.ISO87.equals(nodeFormat) || NodeFormat.ISO93.equals(nodeFormat)) {
				NodeDetail isoNodeDetail = new ISONodeDetail((String) nodesDetails.get("name"),
						(String) nodesDetails.get("description"));
				((ISONodeDetail) isoNodeDetail).setFieldDetails(buildFieldMetaData((List) nodesDetails.get("fields")));


				isoNodeDetail.setMessages(buildISOMessageMetaData((List) nodesDetails.get("messages"),
						((ISONodeDetail) isoNodeDetail).getFieldDetails()));
				isoNodeDetail.setFormat(nodeFormat);
				//get the end point list if any,
				loadEndPoints(nodesDetails, isoNodeDetail);
				nodeDetailsList.add(isoNodeDetail);
			} else if (NodeFormat.XML.equals(nodeFormat) || NodeFormat.JSON.equals(nodeFormat)) {
				NodeDetail xmlNodeDetail = new XmlNodeDetail((String) nodesDetails.get("name"),
						(String) nodesDetails.get("description"));
				xmlNodeDetail.setMessages(buildXMLMessageMetaData((List) nodesDetails.get("messages")));
				xmlNodeDetail.setFormat(nodeFormat);
				//get the end point list if any,
				loadEndPoints(nodesDetails, xmlNodeDetail);
				nodeDetailsList.add(xmlNodeDetail);
			}
		}
		return nodeDetailsList;

	}
	
	private Map<String,Object> processWorkFlowsJSONFile(String workFlowJSONFile,List<NodeDetail> nodeDetailsList) throws JsonParseException, JsonMappingException, IOException{

		Map<String, Object> workFlowInfo = new HashMap<String, Object>(2);
		Map<String, List<MappingDetails>> mappingConfigMap = new HashMap<>();

		List<RoutingDetails> routingDetailsList = new ArrayList<>();
		ObjectMapper mapper = new ObjectMapper();
		List<LinkedHashMap<String, Object>> workFlows = mapper.readValue(new File(workFlowJSONFile), List.class);

		for (Object record : workFlows) {
			List<Object> mappings = (List) ((Map) record).get("mapping");
			for (Object mapping : mappings) {
				List<MappingDetails> mappingConfigList = new ArrayList<MappingDetails>();
				Map<String, Object> mappingDetailsMap = (Map) mapping;

				MappingDetails mappingDetails = new MappingDetails();
				mappingDetails.setDestinationMessageName((String) mappingDetailsMap.get("destMessage"));
				mappingDetails.setDestinationNodeName((String) mappingDetailsMap.get("destNode"));
				mappingDetails.setDestinationFormat((String) mappingDetailsMap.get("destFormat"));
				mappingDetails.setSourceMessageName((String) mappingDetailsMap.get("sourceMessage"));
				mappingDetails.setSourceNodeName((String) mappingDetailsMap.get("sourceNode"));
				mappingDetails.setSourceFormat((String) mappingDetailsMap.get("sourceFormat"));
				mappingDetails.setMappingIdentificationFormula("EXACT(\"1\", \"1\")");

				List<MappingFieldDetails> fieldMappingList = new ArrayList<>();
				Map<String, String> filedMappings = (Map) mappingDetailsMap.get("fieldMapping");

				for (Map.Entry<String, String> entry : filedMappings.entrySet()) {
					fieldMappingList.add(new MappingFieldDetails(entry.getKey(), entry.getValue()));
				}

				mappingDetails.setFieldMapping(fieldMappingList);

				mappingConfigList.add(mappingDetails);

				String mapKey = (String) mappingDetailsMap.get("sourceNode") + "_"
						+ (String) mappingDetailsMap.get("sourceMessage") + "_"
						+ (String) mappingDetailsMap.get("destNode") + "_"
						+ (String) mappingDetailsMap.get("destMessage");
				
				if (mappingConfigMap.containsKey(mapKey)) {

					List<MappingDetails> mappingList = mappingConfigMap
							.get(mapKey);
					mappingList.addAll(mappingConfigList);
					mappingConfigMap.put(mapKey, mappingList);
				} else {
					mappingConfigMap.put(mapKey, mappingConfigList);
				}

			}

			Map<String, Object> routingDetailsMap = (LinkedHashMap<String, Object>) ((Map) record).get("routing");

			routingDetailsList = nodeDetailsList.stream().map(node -> {
				if (routingDetailsMap.containsKey(node.getName())) {
					List<Object> nodeRoutingList = (List) routingDetailsMap.get(node.getName());
					List<RoutingFormulaDetails> routingFormulaDetails = new ArrayList<RoutingFormulaDetails>();
					for (Object object : nodeRoutingList) {
						Map<String, Object> routingFormulaDetailsMap = (Map) object;
						RoutingFormulaDetails formulaDetails = new RoutingFormulaDetails();
						formulaDetails.setDestinationNode((String) routingFormulaDetailsMap.get("destination"));
						formulaDetails.setRoutingFormula((String) routingFormulaDetailsMap.get("formulae"));
						routingFormulaDetails.add(formulaDetails);
					}

					return new RoutingDetails(node.getName(), routingFormulaDetails);
				}
				return new RoutingDetails(node.getName(), new ArrayList<>());
			}).collect(Collectors.toList());

		}
		workFlowInfo.put("mappingConfigInfo", mappingConfigMap);
		workFlowInfo.put("routingDetails", routingDetailsList);
		return workFlowInfo;

	}
	
	private List<VirtualizationDetails> processVirtulizationJSONFile(String virtulizationJSONFile) throws JsonParseException, JsonMappingException, IOException{
		ObjectMapper mapper = new ObjectMapper();
		List<VirtualizationDetails> virtualizationDetailsList = new ArrayList<>();
		List<LinkedHashMap<String, Object>> virtulizations = mapper.readValue(new File(virtulizationJSONFile), List.class);
		for (Object record : virtulizations) {
			ArrayList<Object> requestDataArray = (ArrayList<Object>) ((Map) record).get("requestData");
			if(((Map) record).get("virtualizationLeg") == null || (((Map) record).get("virtualizationLeg").equals("Response") &&  requestDataArray.isEmpty())){
				final VirtualizationDetails virtualizationDetails = new VirtualizationDetails((String) ((Map) record).get("name"),
						(String) ((Map) record).get("nodeName"), (String) ((Map) record).get("type"));
				Map<String, List<LinkedHashMap<String, Object>>> virtualizationData = (Map<String, List<LinkedHashMap<String, Object>>>) ((Map) record).get("virtualizationData");
				List<LinkedHashMap<String, Object>> treeData = virtualizationData.get("treeData");
				if(!treeData.isEmpty()) {
					virtualizationDetails.setRuleDetails(
						treeData.stream().map(ruleData -> {
							return buildTreeRuleDetails(ruleData);
						}).collect(Collectors.toList())
					);	
					virtualizationDetailsList.add(virtualizationDetails);
				}
			}
		}
		return virtualizationDetailsList;
	}
	
	/**
	 * This method loads the end points in the node detail
	 * @param nodesDetails
	 * @param nodeDetail
	 */
	private void loadEndPoints(LinkedHashMap<String, Object> nodesDetails, NodeDetail nodeDetail) {
		final List<Object> endPointsRawInfoList = (List<Object>) nodesDetails.get("endpoints");
		List<NodeEndPointDetails> endPoints = (List<NodeEndPointDetails>) endPointsRawInfoList.stream().map(endPointsRawInfo -> {
			final Map<String, Object> endPointsRawInfoData = (LinkedHashMap<String, Object>) endPointsRawInfo;
			return new NodeEndPointDetails((String)endPointsRawInfoData.get("messageName"), (String)endPointsRawInfoData.get("url"),
					(String)endPointsRawInfoData.get("methodName"));

		}).collect(Collectors.toList());
		nodeDetail.setEndpoints(endPoints);
	}
}

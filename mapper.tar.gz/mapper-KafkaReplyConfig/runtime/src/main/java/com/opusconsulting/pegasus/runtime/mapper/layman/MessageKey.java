package com.opusconsulting.pegasus.runtime.mapper.layman;

public class MessageKey implements IKey {
	String value;

	public MessageKey(String value) {
		super();
		this.value = value;
	}

	@Override
	public String getValue() {
		return value;
	}

	@Override
	public String toString() {
		return value;
	}
	
	
}

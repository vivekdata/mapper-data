package com.opusconsulting.pegasus.runtime.event.handler;

import com.opusconsulting.pegasus.common.event.*;
import com.opusconsulting.pegasus.event.impl.EventContext;
import com.opusconsulting.pegasus.event.impl.EventManager;
import com.opusconsulting.pegasus.flow.IFlowInstance;
import com.opusconsulting.pegasus.flow.impl.FlowFactory;
import com.opusconsulting.pegasus.runtime.IConstants;
import com.opusconsulting.pegasus.runtime.flow.AbstractIWorkflow;
import com.opusconsulting.pegasus.runtime.flow.IWorkflow;
import com.opusconsulting.pegasus.runtime.flows.EnvStartUpFlow;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@Component
@RefreshScope
public class EnvStartupActivityEventHandler implements IEventHandler {
	
	private static final Logger _logger = LoggerFactory.getLogger(EnvStartupActivityEventHandler.class);


	@Inject
	FlowFactory flowFactory;
	
	@Inject
	List<AbstractIWorkflow> workflows;
	
	@Inject
	@Lazy
	IEventPublisher startServerEventPublisher;
	
	@Inject
	@Lazy
	IEventPublisher clientActivityEventPublisher;

	@Value("${workFlowJSONFilePath}")
	public String workFlowJSONFilePath;
	
	@PostConstruct
	public void init(){
		//initialize Environment start up flow only
		_logger.debug("Initializing Environment Startup activty handler.");

		if (workflows != null) {
			workflows.stream().filter((workflow) -> {
				return workflow instanceof EnvStartUpFlow;
			}).forEach((workflow) -> {
				workflow.registerToFactory(null);
			});
		}
		flowFactory.init();
		_logger.debug("Successfully initialized flow factory for Environment Startup activty flow.");
	}
	
	@Override
	public void handle(IEventMessage eventMessage, IEventContext context) {
		if(eventMessage.isReply()){
			_logger.debug("Environment startup acitity event reply process. Message = {}", (String)eventMessage.getData());
			if("PROCESS_READ_DATA".equalsIgnoreCase(eventMessage.getData())){
				boolean success = processEventReply(eventMessage, context);
				if(success){
					EventContext serverStartContext = new EventContext();
					serverStartContext.set(ORI_REQUEST_CTX_KEY, eventMessage);
					_logger.debug("Environment startup acitity successful. Start Host server event initialized.");
					startServerEventPublisher.publish("START", serverStartContext);
				}
			} else if("SERVER_STARTED".equalsIgnoreCase(eventMessage.getData())){
				System.out.println("----------- Server started successfully ------------------");
				_logger.info("------------------ Host server started successfully -------------------.");
				//TODO may pass end-point details from context
				EventContext connectClientContext = new EventContext();
				connectClientContext.set(ORI_REQUEST_CTX_KEY, eventMessage);
				_logger.debug("CLIENT connection establishment event initialized");
				clientActivityEventPublisher.publish("CONNECT", connectClientContext);
			} else if("SERVER_STARTED_FAILED".equalsIgnoreCase(eventMessage.getData())){
				_logger.error("-------------------- Host Server Start activit failed ------------------");
				//TODO some clean up activity if any.
			} else if("CLIENT_CONNECTED".equalsIgnoreCase(eventMessage.getData())){
				//TODO log message of activity
				_logger.info("-------------------- Connected to CLIENT(s) successfully ------------------");
				System.out.println("----------- Connected to Client successfully ------------------");
			} else if("CLIENT_CONNECTION_FAILED".equalsIgnoreCase(eventMessage.getData())){
				//TODO some clean up activity if any.
				_logger.error("-------------------- Connection to CLIENT(s) activity failed. ------------------");
			} else if("FAILED_TO_READ".equalsIgnoreCase(eventMessage.getData())){
				_logger.error("-------------------- Environment bootup activity failed. ------------------");
				System.exit(0);
			}
		} else {
			_logger.debug("Environment startup acitity event process started. Event Message: {} ", (String)eventMessage.getData());
			processEventMessage(eventMessage, context);
		}
		
		_logger.debug("Environment startup acitity event process started. Event Message: {} ");
		//processStartUpFlow(eventMessage, context);
	}

	private boolean processEventReply(IEventMessage eventMessage, IEventContext context) {
		_logger.info("Processing Environment start up activity event reply. Reply Type: {}", eventMessage.getReplyType());
		if(ReplyType.Failure.equals(eventMessage.getReplyType())){
			return false;
		}
		// TODO take the pojo values from reply context and prepare the other
		// flow instances
		
		final Map<String, Object> workflowData = new HashMap<>();
		workflowData.put(IConstants.NODE_DETAILS_CONFIGS, context.get(IConstants.NODE_DETAILS_CONFIGS));
		_logger.info("Initializaing application Workflows");
		if (workflows != null) {
			workflows.stream().filter((workflow) -> {
				return !(workflow instanceof EnvStartUpFlow);
			}).forEach((workflow) -> {
				workflow.registerToFactory(workflowData);
			});
		}
		flowFactory.init();
		_logger.info("Application workflows successfully initialized.");
		return true;
	}

	private void processEventMessage(IEventMessage eventMessage, IEventContext context) {
		// TODO prepare Startup flow instance and start the flow
		if("BOOT".equalsIgnoreCase(eventMessage.getData())){
			try {
				final Map<String, Object> flowResultValue = executeStartupflow(context);
				if(flowResultValue == null){
					eventMessage.reply("FAILED_TO_READ", false);
				} else {
					IEventContext replyContext = new EventContext();
					flowResultValue.entrySet().forEach((entry) -> {
						replyContext.set(entry.getKey(), entry.getValue());
					});
					eventMessage.reply("PROCESS_READ_DATA", true, replyContext);
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
				eventMessage.reply("Failed", false);
			} catch (ExecutionException e) {
				e.printStackTrace();
				eventMessage.reply("Failed", false);
			}
		}
	}

	private Map<String, Object> executeStartupflow(IEventContext context) throws InterruptedException, ExecutionException {
		IFlowInstance startUpFlowInstance = flowFactory.createInstance(AbstractIWorkflow.prepareMetaDataName("", IWorkflow.STARTUP));

		final Map<String, Object> startupProps = new HashMap<>();
		startupProps.put("nodeJSONFilePath", context.get("nodeJSONFilePath"));
		startupProps.put("workFlowJSONFilePath", context.get("workFlowJSONFilePath"));
		startupProps.put("virtulizationJSONFilePath", context.get("virtulizationJSONFilePath"));
		final CompletableFuture<Map<String, Object>> flowResult = startUpFlowInstance.process(startupProps);
		return flowResult.get();
	}


	@Value("${nodeJSONFilePath}")
	public String nodeJSONFilePath;



	@Value("${virtulizationJSONFilePath}")
	public String virtulizationJSONFilePath;

	@Value("${sourceNodeName}")
	private String sourceNode  ;

	@Value("${node.names}")
	private String nodeNames;

	@Bean(name={"sourceNode"})
	public String getSourceNodeName(){//TODO need to think about this.
		return sourceNode;
	}

	@Bean(name={"nodeJSONFilePath"})
	public String getNodeJSONFilePath() {
			return nodeJSONFilePath;
	}

	@Bean(name={"virtulizationJSONFilePath"})
	public String getVirtulizationJSONFilePath() {
			return virtulizationJSONFilePath;
	}

	@Bean(name={"nodeNames"})
	public String getNodeNames() {
			return nodeNames;
	}


	@Bean(name="workFlowJSONFilePath")
	public String getWorkFlowJSONFilePath() {
		return workFlowJSONFilePath;
	}

}

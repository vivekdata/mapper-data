package com.opusconsulting.pegasus.runtime.mapper.layman;

import java.io.Serializable;

public class IMessageMetaDataImpl implements IMessageMetaData,Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6118234996915882144L;
	private String name;
	private boolean isRequest;
	
	
	public IMessageMetaDataImpl(String name, boolean isRequest) {
		super();
		this.name = name;
		this.isRequest = isRequest;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setRequest(boolean isRequest) {
		this.isRequest = isRequest;
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return this.name;
	}

	@Override
	public boolean isRequest() {
		// TODO Auto-generated method stub
		return this.isRequest;
	}

}

package com.opusconsulting.pegasus.runtime.event.handler;

import java.time.Duration;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Future;
import java.util.stream.Collectors;

import javax.inject.Inject;

import com.opusconsulting.pegasus.common.event.*;
import com.opusconsulting.pegasus.runtime.brokers.producer.TopicProducer;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.header.Header;
import org.apache.kafka.common.header.Headers;
import org.apache.kafka.common.header.internals.RecordHeader;
import org.apache.kafka.common.header.internals.RecordHeaders;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.env.Environment;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import com.opusconsulting.pegasus.channel.http.HttpChannelMessage;
import com.opusconsulting.pegasus.channel.http.HttpServerChannel;
import com.opusconsulting.pegasus.channel.http.HttpServerChannelConfig;
import com.opusconsulting.pegasus.channel.http.HttpServerChannelConfig.HttpUrlInfo;
import com.opusconsulting.pegasus.channel.http.handler.HttpChannelHandler.HttpMethodType;
import com.opusconsulting.pegasus.channel.tcp.TCPChannelMessage;
import com.opusconsulting.pegasus.channel.tcp.TCPServerChannel;
import com.opusconsulting.pegasus.channel.tcp.TCPServerConfig;
import com.opusconsulting.pegasus.common.channel.IChannel;
import com.opusconsulting.pegasus.common.channel.IChannelEvent;
import com.opusconsulting.pegasus.event.impl.EventContext;
import com.opusconsulting.pegasus.event.impl.EventMessage;
import com.opusconsulting.pegasus.format.iso.metadata.EndPointDetail;
import com.opusconsulting.pegasus.format.iso.metadata.EndpointProtocol;
import com.opusconsulting.pegasus.format.iso.metadata.HttpEndPointDetail;
import com.opusconsulting.pegasus.runtime.IConstants;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelHandlerContext;
import io.vertx.core.Vertx;
import io.vertx.core.buffer.Buffer;
import io.vertx.ext.web.RoutingContext;

@Component
public class StartServerEventHandler implements IEventHandler {
	private static final Logger _logger = LoggerFactory.getLogger(StartServerEventHandler.class);
	private IChannel serverChannel;

	@Inject
	@Lazy
	IEventPublisher processMessageEventPublisher;

	@Inject
	String sourceNode ;// TODO This may be the configuration value. However currently injecting for
						// demo purpose

	@Autowired
	@Lazy
	List<EndPointDetail> endpoints;

	@Autowired
	private Vertx vertx;

	@Autowired
	TopicProducer producer;

	@Override
	public void handle(IEventMessage eventMessage, IEventContext context) {
		_logger.debug("Starting HOST server...");
		_logger.debug("Get Data: {}", (String) eventMessage.getData());
		if("START".equalsIgnoreCase(eventMessage.getData())){//this is consumer part
			boolean serverStarted = startServer(context);
			if(serverStarted){
				replyToInitiator("SERVER_STARTED", context, true);
			} else {
				if(this.serverChannel != null){
					try {
						this.serverChannel.stop();
					} catch (Exception e) {
						_logger.error("Error occured while shutting down the server channel.", e);
					}
				}
				replyToInitiator("SERVER_STARTED_FAILED", context, false);
			}
		}else if ("RESPOND_TO_SERVER".equalsIgnoreCase(eventMessage.getData())) {
			final byte[] responseMessageBytes = context.get(IConstants.EVENT_CTX_SERIALIZED_RESPONSE_BUFFER);
			final String sourceNodeName = (context.get(IConstants.EVENT_CTX_DESTINATION_NODE_NAME_KEY) == null) ? sourceNode
					: context.get(IConstants.EVENT_CTX_DESTINATION_NODE_NAME_KEY);
			_logger.debug("Msg:> {}", new String(responseMessageBytes));
			endpoints.stream().filter(endpoint -> {
				return endpoint.getNodeName().equalsIgnoreCase(sourceNodeName);
			}).forEach((endpoint -> {
				if (EndpointProtocol.TCP.equals(endpoint.getProtocol())) {
					final ChannelHandlerContext ctx = context.get(IConstants.EVENT_CTX_CHANNEL_CONTEXT);
					ByteBuf response = Unpooled.buffer(1024);
					response.writeBytes(responseMessageBytes);
					ChannelFuture responseFuture = ctx.channel().writeAndFlush(response);
					if(responseFuture.awaitUninterruptibly().isDone()) {
						_logger.debug("Response " + (responseFuture.isSuccess()? "successfully sent back:" : " failed to send back."));
						_logger.debug("TCP Response Message: {}", new String(responseMessageBytes));
						final Throwable error = responseFuture.cause();
						if(error != null) {
							_logger.error("Error after respond back.", error);
						}
					}
				} else {
					// TODO need to work on HTTP protocols
					if (EndpointProtocol.HTTP.equals(endpoint.getProtocol())) {		
						final RoutingContext ctx = context.get(IConstants.EVENT_CTX_CHANNEL_CONTEXT);
						Buffer responseMessage = Buffer.buffer(responseMessageBytes);
						ctx.response().setChunked(true).write(responseMessage).end();
						System.out.println("HTTP Response sent back:" + new String(responseMessageBytes));
					} else if (EndpointProtocol.KAFKA.equals(endpoint.getProtocol())) {
						System.out.println("KAFKA Response sent back:" + sourceNodeName + " : " + new String(responseMessageBytes));
						producer.send(new String(responseMessageBytes), context.get(IConstants.KF_TOPIC), null);
					}
				}
			}));
		}
	}
	
	private boolean startServer(IEventContext context) {
		endpoints.stream().filter(endpoint -> {
			return endpoint.getNodeName().equalsIgnoreCase(sourceNode);
		}).forEach((endpoint -> {
			if(EndpointProtocol.TCP.equals(endpoint.getProtocol())) {
				startTCPServer(endpoint.getAddress(), endpoint.getPort());
			} else if(EndpointProtocol.HTTP.equals(endpoint.getProtocol())) {
				startHttpServer(endpoint);
			} else if(EndpointProtocol.KAFKA.equals(endpoint.getProtocol())) {
				_logger.debug("Kafka Endpoint... !");
			}
		}));
		return true;
	}

	@SuppressWarnings("unchecked")
	private void startHttpServer(EndPointDetail endpoint) {
		if (!endpoint.getClass().isAssignableFrom(HttpEndPointDetail.class)) {
			_logger.error(
					"Invalid endpoint details provided for the HTTP server start up. The endpoint should be of type HttpEndPointDetail.");
			return;
		}
		HttpEndPointDetail httpEndPoint = (HttpEndPointDetail) endpoint;

		final HttpServerChannelConfig config = new HttpServerChannelConfig();
		config.setHostName(httpEndPoint.getAddress());
		config.setPort(endpoint.getPort());
		// config.setContentType(HttpContentType.JSON);
		config.setUrlInfos((List<HttpUrlInfo>) httpEndPoint.getHttpEndPoints().stream().map(httpEndPointInfo -> {
			return config.new HttpUrlInfo(httpEndPointInfo.getUrl(), httpEndPointInfo.getMessageName(),
					httpEndPointInfo.getMethod());
		}).collect(Collectors.toList()));
		this.serverChannel = new HttpServerChannel(vertx, config);
		this.serverChannel.setEventHandler(new IChannelEvent<HttpChannelMessage>() {
			public void onEvent(String type, HttpChannelMessage message, Object additionalInfo) {
				//get the HttpMethodType
				HttpMethodType httpMethodType = HttpMethodType.valueOf(type);
				// TODO need to think
				EventContext context = new EventContext();
				loadContextForCommonInfo(message, context);
				
				switch (httpMethodType) {
				case GET:
					handleGetAndDeleteRequest(message, context);
					break;
				case POST:
					handlePostRequest(message, context);
					break;
				case PUT:
					handlePutRequest(message, context);
					break;
				case DELETE:
					// load flag that De-Serialization is not required
					handleGetAndDeleteRequest(message, context);
					break;
				default :
					_logger.error("Unsupported HTTP method. Only GET, POST, PUT,DELETE are supported. Received : " + httpMethodType);
					break;
				}
			}
			
		});

		try {
			CompletableFuture<Boolean> startServerResult = this.serverChannel.start();
			if(startServerResult.get()) {
				_logger.info("Host Server started successfully. Host listening on IP: {}, Port: {}", endpoint.getAddress(),
						endpoint.getPort());
			} else {
				_logger.error("Host Server failed to start. Host: {}, Port: {}", endpoint.getAddress(),
						endpoint.getPort());
			}
		} catch (Exception e) {
			_logger.error("Error while starting host server.", e);
		}
	}

	private boolean startTCPServer(String address, int port) {
		TCPServerConfig config = new TCPServerConfig().setBindAddress(address).setPort(port);
		this.serverChannel = new TCPServerChannel(config);
		serverChannel.setEventHandler(new IChannelEvent<TCPChannelMessage>() {
			public void onEvent(String type, TCPChannelMessage message, Object additionalInfo) {
				// TODO need to think
				EventContext context = new EventContext();
				context.set(IConstants.EVENT_CTX_SOURCE_NODE_NAME_KEY, sourceNode);// TODO need to get it from runtime
																					// or configuration
				_logger.debug("Protocol Context {}",message.getProtocolContext());
				context.set(IConstants.SERVER_MSG_PROTOCOL_CTX, message.getProtocolContext());
				System.out.println("Reqeust receivevd:1 " + new String(message.getData()));
				_logger.debug("Request received on the Host Server. Process event published for same.");
				processMessageEventPublisher.publish(message.getData(), context);
			}
		});

		try {
			_logger.debug("inside  sstartServerResult ::::: ...");
			Thread.sleep(4000);
			CompletableFuture<Boolean> startServerResult = this.serverChannel.start();
			_logger.info("Host Server started successfully. Host listening on IP: {}, Port: {}", address, port);
			return startServerResult.get();
		} catch (Exception e) {
			_logger.error("Error while starting host server.", e);
			return false;
		}
	}

	private void replyToInitiator(String message, IEventContext context, boolean success) {
		EventMessage originalMessage = context.get(ORI_REQUEST_CTX_KEY);
		EventContext replyContext = new EventContext();
		originalMessage.reply(message, success, replyContext);
	}

	public Vertx getVertx() {
		return vertx;
	}

	private void handlePutRequest(HttpChannelMessage message, EventContext context) {
		loadContextForRequestParam(message, context);
		_logger.debug("Request received on the Host Server. Process event published for same.");
		processMessageEventPublisher.publish(message.getData().getBytes(), context);
	}

	private void handlePostRequest(HttpChannelMessage message, EventContext context) {
		context.set(IConstants.IS_REQUEST_PARAM_DESERIALIZE_SERIALIZE_REQUIRED, false);
		_logger.debug("Request received on the Host Server. Process event published for same.");
		processMessageEventPublisher.publish(message.getData().getBytes(), context);
	}

	private void handleGetAndDeleteRequest(HttpChannelMessage message, EventContext context) {
		loadContextForRequestParam(message, context);
		
		context.set(IConstants.HTTP_MESSAGE_NAME_PROPS_KEY,
				message.getProps().get(IConstants.HTTP_MESSAGE_NAME_PROPS_KEY));

		_logger.debug("Request received on the Host Server. Process event published for same.");
		processMessageEventPublisher.publish(null, context);
	}
	 
	private void loadContextForRequestParam(HttpChannelMessage message, EventContext context) {
		context.set(IConstants.IS_REQUEST_PARAM_DESERIALIZE_SERIALIZE_REQUIRED, true);
		context.set(IConstants.HTTP_REQUEST_PARAM_FIELDS_KEY,
				message.getProps().get(IConstants.HTTP_REQUEST_PARAM_FIELDS_KEY));
	}
	
	private void loadContextForCommonInfo(HttpChannelMessage message, EventContext context) {
		context.set(IConstants.EVENT_CTX_SOURCE_NODE_NAME_KEY, sourceNode);
		context.set(IConstants.SERVER_MSG_PROTOCOL_CTX, message.getProtocolContext());
		context.set(IConstants.IS_HTTP_REQUEST_MESSAGE_PROPS_KEY, true);
	}

}

package com.opusconsulting.pegasus.runtime.mapper.layman;

public class MappingNotFound extends Exception {
}

package com.opusconsulting.pegasus.runtime.mapper.layman;

import java.util.List;

import com.opusconsulting.pegasus.runtime.IMessage;

public interface IMessageMapping {
    void map(IMessage originMessage, IMessage targetMessage, List<IKey> contextFields);

    void map(IMessage originMessage, IMessage targetMessage, IMessage targetRequestMessage);
    
    IMappingMetaData getMetaData();
}

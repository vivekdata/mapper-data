package com.opusconsulting.pegasus.runtime.mapper;

import com.opusconsulting.pegasus.flow.impl.FlowFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MapperMain {
    @Autowired
    Workflows workflows;

    public static void main(String[] args) {
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext(new String[]{"spring.xml"});


        FlowFactory factory = (FlowFactory) applicationContext.getBean("flowFactory");
//        factory.createInstance()
    }
}

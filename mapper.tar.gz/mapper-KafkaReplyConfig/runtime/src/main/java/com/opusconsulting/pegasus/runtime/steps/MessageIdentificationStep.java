package com.opusconsulting.pegasus.runtime.steps;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.opusconsulting.pegasus.flow.IFlowContext;
import com.opusconsulting.pegasus.flow.impl.AbstractStepInstance;
import com.opusconsulting.pegasus.format.iso.metadata.ExistenceType;
import com.opusconsulting.pegasus.format.iso.metadata.ISONodeDetail;
import com.opusconsulting.pegasus.format.iso.metadata.MessageDetail;
import com.opusconsulting.pegasus.format.iso.metadata.MessageFieldDetail;
import com.opusconsulting.pegasus.format.iso.metadata.NodeDetail;
import com.opusconsulting.pegasus.runtime.IConstants;
import com.opusconsulting.pegasus.runtime.IMessage;
import com.opusconsulting.pegasus.runtime.TransformationResult;
import com.opusconsulting.pegasus.runtime.mapper.layman.CacheAlreadyExists;
import com.opusconsulting.pegasus.runtime.mapper.layman.CacheFactory;
import com.opusconsulting.pegasus.runtime.mapper.layman.CacheMetaData;
import com.opusconsulting.pegasus.runtime.mapper.layman.CacheNotFound;
import com.opusconsulting.pegasus.runtime.mapper.layman.ContextKeyFactory;
import com.opusconsulting.pegasus.runtime.mapper.layman.ICache;
import com.opusconsulting.pegasus.runtime.mapper.layman.IKey;
import com.opusconsulting.pegasus.runtime.mapper.layman.IMessageIdentifier;
import com.opusconsulting.pegasus.runtime.mapper.layman.IMessageMetaData;
import com.opusconsulting.pegasus.runtime.mapper.layman.MessageIdentifierFactory;
import com.opusconsulting.pegasus.runtime.mapper.layman.MessageKey;
import com.opusconsulting.pegasus.runtime.mapper.layman.UnknownMessageType;
import org.springframework.beans.factory.annotation.Value;

public class MessageIdentificationStep extends AbstractStepInstance {
	private static final Logger _logger = LoggerFactory.getLogger(MessageIdentificationStep.class);
	@Autowired
	MessageIdentifierFactory messageIdentifierFactory;

	Map<String, ISONodeDetail> nodeDetails;
	
	boolean computeEvenIfExist;

	@Value("${node.cache.enable}")
	String nodeCacheEnable;

	@PostConstruct
	void init() {

	}

	@Override
	public <I, R> R process(IFlowContext context, I previousStepResult, Map<String, Object> flowProps) {
		IMessage message = (IMessage) flowProps.get(IConstants.FLOW_PROPS_REQUEST_KEY);// context.get(IConstants.SOURCE_MESSAGE);
		if (message == null) {
			_logger.error("No message received in the flow properties for this step to perform.");
			return (R) previousStepResult;
		}

		// new code added by santosh
		context.put(IConstants.FLOW_PROPS_NODE_NAME_KEY, (String) flowProps.get(IConstants.FLOW_PROPS_NODE_NAME_KEY));

		try {
			processIncomingMessage((String) flowProps.get(IConstants.FLOW_PROPS_NODE_NAME_KEY), message);
			context.put(IConstants.SOURCE_MESSAGE_NAME, message.getMetaData().getName());
			_logger.debug("Source Message identified. Message Name: {}, Request: {} ", message.getMetaData().getName(), message.getMetaData().isRequest());

			// validate for mandatory fields
			final NodeDetail nodeDetail = nodeDetails
					.get((String) flowProps.get(IConstants.FLOW_PROPS_NODE_NAME_KEY));
			message.getNodeMetaData().setName(nodeDetail.getName());
			// set the message in the context for next steps if any
			context.put(IConstants.SOURCE_MESSAGE, message);
			_logger.debug("validating the message...");
			boolean valid = validateForMandatoryFields(nodeDetail, (String) context.get(IConstants.SOURCE_MESSAGE_NAME),
					message);
			_logger.debug("Message validation completed. Valid: {}", valid);
			if (valid) {
				updateContextCache((String) flowProps.get(IConstants.FLOW_PROPS_NODE_NAME_KEY), message);
				return (R) previousStepResult;
			} else {
				_logger.error("Invalid message found. Rejecting the message.");
				context.remove(IConstants.SOURCE_MESSAGE_NAME);
				return null;
			}
		} catch (UnknownMessageType unknownMessageType) {
			_logger.error("Error occured while processing incoming message.", unknownMessageType);
			handleUnknownMessageType(context, message, flowProps, unknownMessageType);
			_logger.error("Message identification failed. Rejecting the message.");
			context.remove(IConstants.SOURCE_MESSAGE_NAME);
			return null;
		} catch (CacheAlreadyExists cacheAlreadyExists) {
			_logger.error("Cached value already present in the cache. Duplicate request received for the transformation.");
			return handleDuplicateRequestCache(context, message, flowProps, cacheAlreadyExists);
		} catch (CacheNotFound e) {
			_logger.error("Error occured while processing incoming message.", e);
			onError(context, message, flowProps, e);
			return null;
		}
	}

	private <I> I handleDuplicateRequestCache(IFlowContext context, IMessage message, Map<String, Object> flowProps,
			CacheAlreadyExists cacheAlreadyExists) {
		onError(context, message, flowProps, cacheAlreadyExists);
		return (I) processDuplicateRequest(message, flowProps);
	}

	private TransformationResult processDuplicateRequest(IMessage message, Map<String, Object> flowProps) {
		final IMessage cachedResponseMessage = fetchResponseFromCache((String) flowProps.get(IConstants.FLOW_PROPS_NODE_NAME_KEY), message);
		if(!isRequest(cachedResponseMessage)) {
			//prepare the transformation result params
			final Map<String, Object> params = new HashMap<>();
			params.put(IConstants.TRANSFORM_RESULT_PARAM_SEND_RESPONSE_KEY, true);
			return  new TransformationResult(cachedResponseMessage, params);
		} else {
			_logger.info("No response available in the cache for the provided data. It may be possible that the transaction is still in process...");
			return new TransformationResult(null, null);
		}
	}

	private void updateContextCache(final String nodeName, IMessage message) throws CacheAlreadyExists, CacheNotFound {
		if (isRequest(message)) {
			addToRequestCache(nodeName, message);
		}
	}

	private boolean isRequest(IMessage message) {
		IMessageMetaData metaData = message.getMetaData();
		return (metaData == null || metaData.isRequest());
	}

	private void addToRequestCache(String origin, IMessage message) throws CacheAlreadyExists, CacheNotFound {
		if(nodeCacheEnable.equalsIgnoreCase("true")) {
			ICache cache = CacheFactory.getCache(origin);
			if (cache == null) throw new CacheNotFound();
			String cacheKey = getCacheKey(message, ContextKeyFactory.getKey(origin + "." + message.getMetaData().getName()));
			if (cache.exists(cacheKey)) {
				throw new CacheAlreadyExists();
			}

			cache.push(cacheKey, new CacheMetaData(message, origin));
		}
	}

	private String getCacheKey(IMessage targetMessage, List<IKey> contextFields) {
		StringBuilder keyBuilder = new StringBuilder();
		for (IKey contextField : contextFields) {
			Object value = null;
			if(contextField.getValue().contains(".")){
				List<String> keyValues = Arrays.asList(contextField.getValue().split("\\."));
				value = fetchFieldValue(keyValues, targetMessage, 0);
			} else {
				value = targetMessage.getValue(contextField);
			}
			keyBuilder.append(((value == null) ? "null" : value.toString()));
			keyBuilder.append("$");
		}
		return keyBuilder.toString();
	}
	
	private Object fetchFieldValue(List<String> keyValues, IMessage message, int keyIndex){
		Object fieldValue = message.getValue(new MessageKey(keyValues.get(keyIndex)));
		keyIndex++;
		if(keyIndex == keyValues.size()) return fieldValue;
		return fetchFieldValue(keyValues, (IMessage)fieldValue, keyIndex);
	}
	
	private IMessage fetchResponseFromCache(String origin, IMessage message) {
		ICache cache = CacheFactory.getCache(origin);
		String cacheKey = getCacheKey(message, ContextKeyFactory.getKey(origin+"."+message.getMetaData().getName()));
		if (cache.exists(cacheKey)) {
			return cache.fetch(cacheKey);
		} else {
			return null;
		}
	}

	void processIncomingMessage(String origin, IMessage message) throws UnknownMessageType {
		// find message type and set
		if (!isMessageTypeKnown(message)) {
			findAndSetMessageType(origin, message);
		}
	}

	private boolean isMessageTypeKnown(IMessage message) {
		return message.getMetaData() != null;
	}

	protected void handleUnknownMessageType(IFlowContext context, IMessage message, Map<String, Object> flowProps, UnknownMessageType unknownMessageType) {
		onError(context, message, flowProps, unknownMessageType);
	}

	private void findAndSetMessageType(String origin, IMessage message) throws UnknownMessageType {
		IMessageIdentifier messageIdentifier = messageIdentifierFactory.getIdentifier(origin);
		IMessageMetaData metaData = messageIdentifier.identify(message);
		if (metaData == null) {
			_logger.error("No meta data identified for this message bytes. throwing Unknown message exception.");
			throw new UnknownMessageType();
		}
		message.setMetaData(metaData);
	}

	/*
	 * noneMatch() method returns true if none of the stream elements matches
	 * the given predicate if any single elements matches this returns false.
	 */
	private boolean validateForMandatoryFields(NodeDetail nodeDetail, String messageName, IMessage message) {
		if (messageName == null || nodeDetail == null)
			return false;

		Optional<MessageDetail> messageDetailOptional = nodeDetail.getMessages().stream().filter(messageDetail -> {// Filter
																		// the
																		// ISO
																		// message
																		// by
																		// identified
																		// name
			// System.out.println("isoMessage.getName().equalsIgnoreCase(" +
			// messageName + ") : - " +
			// isoMessage.getName().equalsIgnoreCase(messageName));
			return ((MessageDetail)messageDetail).getName().equalsIgnoreCase(messageName);
		}).findFirst();
		if(messageDetailOptional.isPresent()){
			MessageDetail messageDetail = messageDetailOptional.get();
			return messageDetail.getMessageFields().stream().filter(msgField -> {// filter
										// all
										// mandatory
										// fields
						// System.out.println("ExistenceType.Mandatory.equals(msgField.getType())
						// : - " + ExistenceType.Mandatory.equals(msgField.getType()));
						return ExistenceType.Mandatory.equals(((MessageFieldDetail)msgField).getType());
						}).noneMatch(msgField -> {
						// System.out.println("Checking for " +
						// msgField.getField().getName() + " ...");
						// System.out.println(message.get(msgField.getField().getName()) ==
						// null);
						return false; // TODO need to check here how to implement
						// return (message.get(msgField.getField().getName()) == null);
						// //check if message has those fields
						});
		} else {
			_logger.error("No message configuration found to validate the message. Message Name: {}", message.getMetaData().getName());
			return false;
		}
	}

	public void setNodeDetails(Map<String, ISONodeDetail> nodeDetails) {
		this.nodeDetails = nodeDetails;
	}
}
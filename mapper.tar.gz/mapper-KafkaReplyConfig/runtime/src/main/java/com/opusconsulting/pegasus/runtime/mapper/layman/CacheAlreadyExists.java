package com.opusconsulting.pegasus.runtime.mapper.layman;

public class CacheAlreadyExists extends Exception {
}

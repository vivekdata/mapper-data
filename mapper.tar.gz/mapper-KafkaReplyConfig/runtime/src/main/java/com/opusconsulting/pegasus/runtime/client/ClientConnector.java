package com.opusconsulting.pegasus.runtime.client;

import java.util.List;
import java.util.concurrent.CompletableFuture;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import com.opusconsulting.pegasus.channel.http.HttpChannelConfig;
import com.opusconsulting.pegasus.channel.http.HttpClientChannelFactory;
import com.opusconsulting.pegasus.channel.tcp.TCPChannelMessage;
import com.opusconsulting.pegasus.channel.tcp.TCPClientChannel;
import com.opusconsulting.pegasus.channel.tcp.TCPClientConfig;
import com.opusconsulting.pegasus.common.event.IEventPublisher;
import com.opusconsulting.pegasus.event.impl.EventContext;
import com.opusconsulting.pegasus.format.iso.metadata.EndPointDetail;
import com.opusconsulting.pegasus.format.iso.metadata.HttpEndPointDetail;
import com.opusconsulting.pegasus.runtime.IConstants;
import com.opusconsulting.pegasus.runtime.mapper.layman.ClientConnectionFactory;

import io.vertx.core.http.HttpMethod;

@Component
public class ClientConnector {

	@Autowired
	ClientConnectionFactory clientConnectionFactory;

	@Lazy
	@Autowired
	List<EndPointDetail> endpoints;

	@Autowired
	HttpClientChannelFactory httpClientChannelFactory;
	
	@Inject
	@Lazy
	IEventPublisher processMessageEventPublisher;

	private static final Logger _logger = LoggerFactory.getLogger(ClientConnector.class);

	public boolean connectToTCPClient(String nodeName, String address, int port) {
		try {
			TCPClientConfig config = new TCPClientConfig(address, port, nodeName);
			TCPClientChannel clientChannel = new TCPClientChannel(config);
			clientChannel.setEventHandler((type, message, additionalInfo) -> {
				final TCPChannelMessage channelMessage = ((TCPChannelMessage)message);
				if(channelMessage.getData() == null || channelMessage.getData().length == 0) {
					return;
				}
				EventContext context = new EventContext();
				context.set(IConstants.EVENT_CTX_SOURCE_NODE_NAME_KEY, nodeName);// TODO need to get it from runtime
																					// or configuration
				context.set(IConstants.SERVER_MSG_PROTOCOL_CTX, channelMessage.getProtocolContext());
				System.out.println("Reqeust receivevd :" + new String(channelMessage.getData()));
				_logger.debug("Request received at Client. Process event published for same.");
				processMessageEventPublisher.publish(channelMessage.getData(), context);
			});
			_logger.info("Connecting to Client. Node: {}, IP: {}, Port: {}", nodeName, address, port);
			CompletableFuture<Boolean> start = clientChannel.start();
			clientConnectionFactory.register(nodeName, clientChannel);
			return start.get();
		} catch (Exception e) {
			_logger.error("Error while connecting the Client on IP: {}, Port: {}", address, port);
			_logger.error("Connection Error.", e);
			return false;
		}
	}

	public boolean connectToHttpClient(EndPointDetail endpoint) {

		if (!endpoint.getClass().isAssignableFrom(HttpEndPointDetail.class)) {
			_logger.error(
					"Invalid endpoint details provided for the HTTP client connection. The endpoint should be of type HttpEndPointDetail.");
			return false;
		}
		HttpEndPointDetail httpEndPoint = (HttpEndPointDetail) endpoint;
		httpEndPoint.getHttpEndPoints().stream().map(endPoint -> {
			final HttpChannelConfig config = new HttpChannelConfig();
			config.setMessageName(endPoint.getMessageName());
			config.setMethod(HttpMethod.valueOf(endPoint.getMethod()));
			config.setUrl(endPoint.getUrl());
			config.setHostName(httpEndPoint.getAddress());
			config.setPort(httpEndPoint.getPort());
			return config;
		}).map(config -> {
			try {
				return httpClientChannelFactory.getHttpClientChannel(config);
			} catch (Exception e) {
				_logger.error("Unable to build the HTTP Client channel. Method: {}, Message : {}, Url: {} ",
						config.getMethod(), config.getMessageName(), config.getUrl(), e);
				return null;
			}
		}).forEach(httpClientChannel -> {
			if (httpClientChannel != null) {
				try {
					CompletableFuture<Boolean> success = httpClientChannel.start();
					if (success.get()) {
						clientConnectionFactory.register(
								prepareHttpChannelRegisterKey(httpEndPoint.getNodeName(),
										((HttpChannelConfig) httpClientChannel.getConfig()).getMessageName()),
								httpClientChannel);
					} else {
						_logger.error("Failed to start the HTTP Client channel. Method: {}, Message : {}, Url: {} ",
								((HttpChannelConfig) httpClientChannel.getConfig()).getMethod(),
								((HttpChannelConfig) httpClientChannel.getConfig()).getMessageName(),
								((HttpChannelConfig) httpClientChannel.getConfig()).getUrl());
					}
				} catch (Exception e) {
					if (httpClientChannel.getClass().isAssignableFrom(HttpChannelConfig.class)) {
						_logger.error("Unable to start the HTTP Client channel. Method: {}, Message : {}, Url: {} ",
								((HttpChannelConfig) httpClientChannel.getConfig()).getMethod(),
								((HttpChannelConfig) httpClientChannel.getConfig()).getMessageName(),
								((HttpChannelConfig) httpClientChannel.getConfig()).getUrl(), e);
					} else {
						_logger.error("Unable to start the HTTP Client channel. Config: {}",
								httpClientChannel.getConfig(), e);
					}
				}
			}
		});
		;
		return true;
	}

	/**
	 * This method builds the key for the channel to be stored in the registry.
	 * 
	 * @param nodeName
	 * @param messageName
	 * @return
	 */
	public String prepareHttpChannelRegisterKey(final String nodeName, final String messageName) {
		final StringBuilder channelNameKey = new StringBuilder();
		channelNameKey.append(nodeName);
		channelNameKey.append("_");
		channelNameKey.append(messageName);
		return channelNameKey.toString();
	}
}

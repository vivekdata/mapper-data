package com.opusconsulting.pegasus.runtime.event.handler;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import com.opusconsulting.pegasus.common.event.IEventContext;
import com.opusconsulting.pegasus.common.event.IEventHandler;
import com.opusconsulting.pegasus.common.event.IEventMessage;
import com.opusconsulting.pegasus.common.event.IEventPublisher;
import com.opusconsulting.pegasus.common.event.IReplyEventContext;
import com.opusconsulting.pegasus.common.event.ReplyType;
import com.opusconsulting.pegasus.event.impl.EventContext;
import com.opusconsulting.pegasus.event.impl.EventMessage;
import com.opusconsulting.pegasus.event.impl.ReplyEventContext;
import com.opusconsulting.pegasus.flow.IFlowInstance;
import com.opusconsulting.pegasus.flow.impl.FlowFactory;
import com.opusconsulting.pegasus.runtime.IConstants;
import com.opusconsulting.pegasus.runtime.IMessage;
import com.opusconsulting.pegasus.runtime.TransformationResult;
import com.opusconsulting.pegasus.runtime.flow.AbstractIWorkflow;
import com.opusconsulting.pegasus.runtime.flow.IWorkflow;

@Component
public class ProcessMessageBufferEventHandler implements IEventHandler {
	private static final Logger _logger = LoggerFactory.getLogger(ProcessMessageBufferEventHandler.class);
	@Inject
	FlowFactory flowFactory;

	@Inject
	IEventPublisher clientActivityEventPublisher;

	@Inject
	@Lazy
	IEventPublisher startServerEventPublisher;

	@Override
	public void handle(IEventMessage eventMessage, IEventContext context) {
		_logger.debug("Process message event received. Is Reply: " + eventMessage.isReply());
		_logger.debug("Context Process message event received. Is Reply: " + context.get(IConstants.IS_PROCESS_EVENT_MESSAGE_RECEIVED_KEY));
		if(eventMessage.isReply() || (null != context.get(IConstants.IS_PROCESS_EVENT_MESSAGE_RECEIVED_KEY) && context.get(IConstants.IS_PROCESS_EVENT_MESSAGE_RECEIVED_KEY).equals("true")) ){
			processEventReply(eventMessage, context);
		} else {
			processEvent(eventMessage, context);
		}
	}

	private void processEventReply(IEventMessage eventMessage, IEventContext context) {

		_logger.debug("Process Event Reply");

		if(ReplyType.Failure.equals(eventMessage.getReplyType())){
			//TODO think of failure scenario
		} else {
			final byte[] respBuffer = context.get(ClientCommunicationEventHandler.RESPONSE_BUFFER);
			_logger.debug("MSG> {}", new String(respBuffer));
			try {
				//TODO update the node name in the context to destination node.
				final byte[] serializedRespBuffer = executeTransform(context, respBuffer, true);
				//TODO Need to re-think on the logic
				sendResponseToServer(context, serializedRespBuffer);
			} catch (InterruptedException | ExecutionException e) {
				_logger.error("Error while sending Response to Server", e);
			}
		}
	}

	private void sendResponseToServer(IEventContext context, byte[] serializedRespBuffer) {

		_logger.debug("Send Response To Server");
		_logger.debug("Resp Topic: {}", context.get(IConstants.KF_TOPIC).toString());

		final Object ctx = fetchResponseChannelCtx(context);
		_logger.info("Request message was initially received from the HOST to OpusMapper. Responding back to HOST.");
		EventContext eventContext = new EventContext();
		eventContext.set(IConstants.EVENT_CTX_SERIALIZED_RESPONSE_BUFFER, serializedRespBuffer);
		eventContext.set(IConstants.EVENT_CTX_CHANNEL_CONTEXT, ctx);
		eventContext.set(IConstants.EVENT_CTX_SOURCE_NODE_NAME_KEY, context.get(IConstants.EVENT_CTX_SOURCE_NODE_NAME_KEY));

		eventContext.set(IConstants.KF_TOPIC, context.get(IConstants.KF_TOPIC));

		startServerEventPublisher.publish("RESPOND_TO_SERVER", eventContext);
	}

	private Object fetchResponseChannelCtx(IEventContext context) {
		_logger.debug("Fetch Response Channel Ctx");
		if (context.getClass().isAssignableFrom(ReplyEventContext.class)) {
			IReplyEventContext replyEventContext = (IReplyEventContext) context;
			IEventContext originalContext = replyEventContext.getOriginalContext();
			return originalContext.get(IConstants.SERVER_MSG_PROTOCOL_CTX);
		} else {
			return context.get(IConstants.SERVER_MSG_PROTOCOL_CTX);
		}
	}
 
	private void processEvent(IEventMessage eventMessage, IEventContext context) {
		_logger.debug("Process Event");
		final byte[] messageBuffer = eventMessage.getData();
		try {
			_logger.debug("Transformation begins... ");
			final byte[] serializedBuffer = executeTransform(context, messageBuffer, false);
			_logger.debug("Transformation Ends. ");
			if(isSerialized(context, serializedBuffer)) {
				//publish to client communication event
				EventContext sendMsgToClientEvntContext = new EventContext();
				sendMsgToClientEvntContext.set(ORI_REQUEST_CTX_KEY, eventMessage);
				sendMsgToClientEvntContext.set(ClientCommunicationEventHandler.SERIALIZED_BUFFER, serializedBuffer);
				sendMsgToClientEvntContext.set(IConstants.EVENT_CTX_DESTINATION_NODE_NAME_KEY,
						context.get(IConstants.EVENT_CTX_DESTINATION_NODE_NAME_KEY));
				sendMsgToClientEvntContext.set(IConstants.DESTINATION_MESSAGE_NAME, context.get(IConstants.SOURCE_MESSAGE_NAME));
				sendMsgToClientEvntContext.set(IConstants.FLOW_PROPS_TRANSFORMED_MESSAGE_FIELDS,context.get(IConstants.FLOW_PROPS_TRANSFORMED_MESSAGE_FIELDS));

				// KAFKA TOPIC
				sendMsgToClientEvntContext.set( IConstants.KF_TOPIC, (String) context.get("topic") );
_logger.debug("Topid>>>>>>>>>>>>> {}", sendMsgToClientEvntContext.get(IConstants.KF_TOPIC).toString());
				clientActivityEventPublisher.publish(ClientCommunicationEventHandler.SEND_RECEIVE_EVT_DATA,
						sendMsgToClientEvntContext);
			}
		} catch (InterruptedException | ExecutionException e) {
			_logger.error("Error occured while processing the event.", e);
		}
	}

	private boolean isSerialized(IEventContext context, final byte[] serializedBuffer) {
		_logger.debug("isSerialized");

		if (serializedBuffer == null && context.get(IConstants.FLOW_PROPS_TRANSFORMED_MESSAGE_FIELDS)==null) {
			_logger.error(
					"No serialized buffer available to send to outside system. It might possible that an error occured or a duplicate request received");
			return false;
		}
		return true;
	}

	private byte[] executeTransform(IEventContext context, final byte[] messageBuffer, Boolean isEventReply)
			throws InterruptedException, ExecutionException {
		_logger.debug("Execute Transform");
		final String sourceNodeName = context.get(IConstants.EVENT_CTX_SOURCE_NODE_NAME_KEY);
		_logger.debug("Deserializing message bytes started... {}", sourceNodeName);
		final Map<String, Object> flowProps = new HashMap<>();

		loadFlowPropsWithContextFields(context,flowProps);

		flowProps.put(IConstants.IS_PROCESS_EVENT_MESSAGE_RECEIVED_KEY, isEventReply);
		// de-serialize buffer
		final IMessage deserializedBuffer = deserialize(sourceNodeName, messageBuffer, flowProps);
		_logger.debug("Deserializing message bytes completed.");
		if (deserializedBuffer == null) {
			_logger.error("No message returned from deserializing process. Aborting the process.");
			return null;
		}
		flowProps.put(IConstants.FLOW_PROPS_REQUEST_KEY, deserializedBuffer);
		_logger.debug("Transformation  started...");
		// transformation buffer
		final TransformationResult transformedResult = transform(flowProps);
		if (postTransform(context, sourceNodeName, transformedResult, flowProps)) {
			final String destNodeName = (String) transformedResult.getParams()
					.get(IConstants.EVENT_CTX_DESTINATION_NODE_NAME_KEY);// transformedBuffer.getValue(new
																			// MessageKey(IConstants.EVENT_CTX_DESTINATION_NODE_NAME_KEY));
			context.set(IConstants.EVENT_CTX_DESTINATION_NODE_NAME_KEY, destNodeName);
			flowProps.put(IConstants.FLOW_PROPS_TRANSFORMED_REQUEST_KEY, transformedResult.getiMessage());
			flowProps.put(IConstants.FLOW_PROPS_NODE_NAME_KEY, destNodeName);
			_logger.debug("Serializing to message bytes started...");
			// serialize buffer
			final byte[] serializedBuffer = serialize(destNodeName, flowProps);
			_logger.debug("Serializing to message bytes completed.");
			
			//in case of HTTP get and delete
			if(flowProps.get(IConstants.FLOW_PROPS_TRANSFORMED_MESSAGE_FIELDS)!=null) {
				context.set(IConstants.FLOW_PROPS_TRANSFORMED_MESSAGE_FIELDS,flowProps.get(IConstants.FLOW_PROPS_TRANSFORMED_MESSAGE_FIELDS));
			}
			
			context.set(IConstants.SOURCE_MESSAGE_NAME,transformedResult.getiMessage().getMetaData().getName());
			return serializedBuffer;
		} else {
			return null;
		}
	}

	private void loadFlowPropsWithContextFields(IEventContext context, Map<String, Object> flowProps) {
		_logger.debug("Load Flow Props With Context Fields");
		//load the HTTP specific information to the flow props
		if(context.get(IConstants.IS_REQUEST_PARAM_DESERIALIZE_SERIALIZE_REQUIRED) != null
				&& (boolean) context.get(IConstants.IS_REQUEST_PARAM_DESERIALIZE_SERIALIZE_REQUIRED)) {

			flowProps.put(IConstants.IS_REQUEST_PARAM_DESERIALIZE_SERIALIZE_REQUIRED, context.get(IConstants.IS_REQUEST_PARAM_DESERIALIZE_SERIALIZE_REQUIRED));
			if (context.get(IConstants.HTTP_REQUEST_PARAM_FIELDS_KEY) != null) {
				flowProps.put(IConstants.HTTP_REQUEST_PARAM_FIELDS_KEY, context.get(IConstants.HTTP_REQUEST_PARAM_FIELDS_KEY));
			}
			flowProps.put(IConstants.HTTP_MESSAGE_NAME_PROPS_KEY, context.get(IConstants.HTTP_MESSAGE_NAME_PROPS_KEY));
			flowProps.put(IConstants.IS_HTTP_REQUEST_MESSAGE_PROPS_KEY, context.get(IConstants.IS_HTTP_REQUEST_MESSAGE_PROPS_KEY));
		
		}
		
	}

	/**
	 * This method perform checks after transformation
	 * 
	 * @param context
	 * @param nodeName
	 * @param transformedResult
	 * @param flowProps
	 * @return
	 * @throws InterruptedException
	 * @throws ExecutionException
	 */
	private boolean postTransform(final IEventContext context, final String nodeName,
			final TransformationResult transformedResult, Map<String, Object> flowProps)
			throws InterruptedException, ExecutionException {
		_logger.debug("performing checks post to transformation...");
		if (transformedResult == null) {
			_logger.error("No message result returned from transformation process. Aborting the process.");
			return false;
		}
		final IMessage transformedBuffer = transformedResult.getiMessage();
		if (transformedBuffer == null && transformedResult.getParams() == null) {
			_logger.error("No message returned from transformation process. Aborting the process.");
			return false;
		}

		final boolean sendResponseFlag = transformedResult.getParams()
				.get(IConstants.TRANSFORM_RESULT_PARAM_SEND_RESPONSE_KEY) == null ? false
						: (boolean) transformedResult.getParams()
								.get(IConstants.TRANSFORM_RESULT_PARAM_SEND_RESPONSE_KEY);
		_logger.debug("Transformation workflow completed.");
		if (sendResponseFlag) {
			_logger.debug("Sending response back to caller with interupting process.");
			// serialize the fetched response
			flowProps.put(IConstants.FLOW_PROPS_TRANSFORMED_REQUEST_KEY, transformedBuffer);
			flowProps.put(IConstants.FLOW_PROPS_NODE_NAME_KEY, nodeName);
			byte[] serializedRespBuffer = serialize(nodeName, flowProps);
			sendResponseToServer(context, serializedRespBuffer);
			return false;
		}
		_logger.debug("performing checks post to transformation completed.");
		return true;
	}

	private IMessage deserialize(String sourceNodeName, byte[] messageBuffer, Map<String, Object> flowProps)
			throws InterruptedException, ExecutionException {
		_logger.debug("Deserialize {}", sourceNodeName);
		final IFlowInstance deserializeFlow = flowFactory
				.createInstance(AbstractIWorkflow.prepareMetaDataName(sourceNodeName, IWorkflow.DESERIALIZE));

		flowProps.put(IConstants.FLOW_PROPS_MESSAGE_BUFFER_KEY, messageBuffer);
		flowProps.put(IConstants.FLOW_PROPS_NODE_NAME_KEY, sourceNodeName);

		final CompletableFuture<IMessage> deserializedResult = deserializeFlow.process(flowProps);

		return deserializedResult.get();
	}

	private TransformationResult transform(Map<String, Object> flowProps)
			throws InterruptedException, ExecutionException {
		_logger.debug("Transformation Result");
		final IFlowInstance transformationFlow = flowFactory
				.createInstance(AbstractIWorkflow.prepareMetaDataName("", IWorkflow.TRANSFORM));
		final CompletableFuture<TransformationResult> transformedResult = transformationFlow.process(flowProps);
		return transformedResult.get();
	}

	private byte[] serialize(String destNodeName, Map<String, Object> flowProps)
			throws InterruptedException, ExecutionException {
		_logger.debug("Serialize {}", destNodeName);
		final IFlowInstance serializeFlow = flowFactory
				.createInstance(AbstractIWorkflow.prepareMetaDataName(destNodeName, IWorkflow.SERIALIZE));
		final CompletableFuture<byte[]> serializedResult = serializeFlow.process(flowProps);
		return serializedResult.get();
	}

}

package com.opusconsulting.pegasus.runtime.flow;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import com.opusconsulting.pegasus.flow.metadata.IFlowMetaData;
import com.opusconsulting.pegasus.flow.metadata.LinkInstanceInfo;
import com.opusconsulting.pegasus.flow.metadata.StepInstanceInfo;
import com.opusconsulting.pegasus.flow.metadata.impl.FlowMetaData;
import com.opusconsulting.pegasus.format.NodeFormat;
import com.opusconsulting.pegasus.format.iso.metadata.EndPointDetail;
import com.opusconsulting.pegasus.format.iso.metadata.ISONodeDetail;
import com.opusconsulting.pegasus.format.iso.metadata.MessageDetail;
import com.opusconsulting.pegasus.format.iso.metadata.NodeDetail;
import com.opusconsulting.pegasus.format.iso.metadata.XmlNodeDetail;
import com.opusconsulting.pegasus.runtime.IConstants;

@SuppressWarnings({ "unchecked", "rawtypes" })
@Component
public class DeserializeWorkflow extends AbstractIWorkflow {
	private static final Logger _logger = LoggerFactory.getLogger(DeserializeWorkflow.class);

	@Autowired
	@Lazy
	List<EndPointDetail> endpoints;
	
	@Override
	protected List<IFlowMetaData> buildFlowMetaDatas(Map<String, Object> workFlowData) {
		if (workFlowData == null) {
			_logger.error("Deserializer workflow failed to initiate due to missing meta data.");
			return null;
		}

		Map<String, NodeDetail<MessageDetail>> nodeDetails = (Map<String, NodeDetail<MessageDetail>>) workFlowData
				.get(IConstants.NODE_DETAILS_CONFIGS);

		return nodeDetails.entrySet().stream().map((nodeDetailEntry) -> {
			if (nodeDetailEntry.getValue().getClass().isAssignableFrom(ISONodeDetail.class)) {
				return buildIsoFlowMetaData(nodeDetailEntry.getValue());
			} else if (nodeDetailEntry.getValue().getFormat().equals(NodeFormat.JSON)) {
				return buildJsonFlowMetaData(nodeDetailEntry.getValue());
			} else if (nodeDetailEntry.getValue().getClass().isAssignableFrom(XmlNodeDetail.class) && nodeDetailEntry.getValue().getFormat().equals(NodeFormat.XML)) {
				return buildXmlFlowMetaData(nodeDetailEntry.getValue());

			} else {
				return null;
			}
		}).collect(Collectors.toList());
	}

	private IFlowMetaData buildXmlFlowMetaData(NodeDetail<MessageDetail> nodeDetail) {
		FlowMetaData flowMetaData = new FlowMetaData();
		flowMetaData.setName(prepareMetaDataName(nodeDetail.getName(), DESERIALIZE));
		Map<String, Object> xmlDeserializerProps = new HashMap<>();
		xmlDeserializerProps.put("nodeDetail", nodeDetail);

		StepInstanceInfo deserializerStepInstanceInfo = new StepInstanceInfo().setName("deserializer")
				.setStepName("XMLDeserializer").setProperties(xmlDeserializerProps);

		createDeserializerStepAndLink(flowMetaData, deserializerStepInstanceInfo,nodeDetail,"deserializer");
		
		return flowMetaData;
	}

	private IFlowMetaData buildIsoFlowMetaData(NodeDetail<MessageDetail> nodeDetail) {
		FlowMetaData flowMetaData = new FlowMetaData();
		flowMetaData.setName(prepareMetaDataName(nodeDetail.getName(), DESERIALIZE));
		Map<String, Object> isoDeserializerProps = new HashMap<>();
		isoDeserializerProps.put("nodeDetail", nodeDetail);

		StepInstanceInfo deserializerStepInstanceInfo = new StepInstanceInfo().setName("deserializer")
				.setStepName("ISODeserializer").setProperties(isoDeserializerProps);

		createDeserializerStepAndLink(flowMetaData, deserializerStepInstanceInfo,nodeDetail,"deserializer");
		
		return flowMetaData;
	}

	private IFlowMetaData buildJsonFlowMetaData(NodeDetail<MessageDetail> nodeDetail) {
		FlowMetaData flowMetaData = new FlowMetaData();
		flowMetaData.setName(prepareMetaDataName(nodeDetail.getName(), DESERIALIZE));
		Map<String, Object> jsonDeserializerProps = new HashMap<>();
		jsonDeserializerProps.put("nodeDetail", nodeDetail);

		StepInstanceInfo deserializerStepInstanceInfo = new StepInstanceInfo().setName("deserializer")
				.setStepName("JSONDeserializer").setProperties(jsonDeserializerProps);
		
		createDeserializerStepAndLink(flowMetaData, deserializerStepInstanceInfo,nodeDetail,"deserializer");
		return flowMetaData;
	}

	private void createDeserializerStepAndLink(FlowMetaData flowMetaData,
			StepInstanceInfo deserializerStepInstanceInfo,NodeDetail<MessageDetail> nodeDetail,String stepName) {
		Map<String, Object> httpDeserializerProps = new HashMap<>();
		httpDeserializerProps.put("nodeDetail", nodeDetail);
	
		StepInstanceInfo deserializerStepInstanceInfoHttpRequest = new StepInstanceInfo().setName("deserializer_1")
				.setStepName("httpRequestParamDeserializer").setProperties(httpDeserializerProps);
		
		final LinkInstanceInfo deserializerStep = buildLinkInstance(stepName, "deserializer_1");

		flowMetaData.setStartStepInstanceName("deserializer")
				.setStepInstancesInfo(Arrays.asList(deserializerStepInstanceInfo,deserializerStepInstanceInfoHttpRequest))
				.setLinkInstancesInfo(Arrays.asList(deserializerStep));
	}
}
package com.opusconsulting.pegasus.runtime.formula;


import com.opusconsulting.pegasus.runtime.IMessage;
import com.opusconsulting.pegasus.runtime.XmlIMessage;
import com.opusconsulting.pegasus.runtime.format.XmlUtility;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class ExcelFunctions {
    public static String CONCAT(Object... vals) {
        StringBuilder resultBuilder = new StringBuilder();
    	for (Object value : vals) {
			if(value.getClass().isAssignableFrom(String.class)){
				resultBuilder.append(value);
			}
		}
    	return resultBuilder.toString();
    }

    public static <T> Boolean EXACT(T lhs, T rhs) {
        if(lhs instanceof String && rhs instanceof String){
        	return lhs.equals(rhs);
        } else {
        	return lhs == rhs;
        }
    }
    
    public static String SUBSTR(String str, int startIndex, int endIndex){
    	return(str.substring(startIndex, endIndex));
    }
    
    public static int INDEXOF(String str, String subString) {
		return str.indexOf(subString);
	}
    
    public static int LENGTH(String str){
    	return str.length();
    }
    
    public static int INT(String str) {
		return Integer.parseInt(str);
	}
    
    public static long LONG(String str) {
		return Long.parseLong(str);
	}
    
    public static String LOWER(String str) {
    	return str.toLowerCase();
	}
    
    public static String NOW() {
    	DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
    	LocalDateTime now = LocalDateTime.now();
    	dtf.format(now);
		return now.toString();
	}
    
    public static String REPLACE(String oldStr, String matchStr, String replaceStr){
    	return oldStr.replace(matchStr, replaceStr);
    }
    
    public static String REPLACEALL(String oldStr, String matchStr, String replaceStr) {
		return oldStr.replaceAll(matchStr, replaceStr);
	}
    
    public static boolean STARTSWITH(String str, String pattern){
    	return str.startsWith(pattern);
    }
    
    public static <T> String STR(T val) {
		return String.valueOf(val);
	}
    
    public static int SUM(int...is) {
    	int sum=0;
    	for (int i : is){
    		sum+=i;
    	}
    	return sum;
	}
    
    public static String UPPER(String str) {
		return str.toUpperCase();
	}
    
    public static String TRIM(String str) {
		return str.trim();
	}
    
    public static boolean NOT(boolean bool){
    	return !bool;
    }
    
    public static String PAD(String str, int count, String ch, String direction){
    	String newStr="";
    	if(direction.equals("left")){
    		for(int i=0;i<count;i++){
    			newStr+= ch;
    		}
    		newStr+= str;
    		return(newStr);
    	}
    	else if (direction.equals("right")) {
    		newStr+= str;
    		for(int i=0;i<count;i++){
    			newStr+= ch;
    		}
    		return newStr;
		}
    	
    	return newStr;
    }

	public static <T> T FindXPathValue(IMessage message, String xPath){
    	return XmlUtility.readXPathValue((XmlIMessage) message, xPath);
    }
}

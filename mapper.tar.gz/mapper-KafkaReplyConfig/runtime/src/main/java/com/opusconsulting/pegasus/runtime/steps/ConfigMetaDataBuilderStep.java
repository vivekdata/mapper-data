package com.opusconsulting.pegasus.runtime.steps;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.eclipse.xtext.parser.IParseResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.opusconsulting.pegasus.flow.IFlowContext;
import com.opusconsulting.pegasus.flow.impl.AbstractStepInstance;
import com.opusconsulting.pegasus.format.NodeFormat;
import com.opusconsulting.pegasus.format.iso.metadata.FieldDetail;
import com.opusconsulting.pegasus.format.iso.metadata.ISONodeDetail;
import com.opusconsulting.pegasus.format.iso.metadata.MappingDetails;
import com.opusconsulting.pegasus.format.iso.metadata.MessageDetail;
import com.opusconsulting.pegasus.format.iso.metadata.MessageFieldDetail;
import com.opusconsulting.pegasus.format.iso.metadata.NodeDetail;
import com.opusconsulting.pegasus.format.iso.metadata.RoutingDetails;
import com.opusconsulting.pegasus.format.iso.metadata.RoutingFormulaDetails;
import com.opusconsulting.pegasus.format.iso.metadata.XmlMessageDetails;
import com.opusconsulting.pegasus.format.iso.metadata.XmlNodeDetail;
import com.opusconsulting.pegasus.formula.parser.FormulaParser;
import com.opusconsulting.pegasus.formula.parser.ParseException;
import com.opusconsulting.pegasus.runtime.ICondition;
import com.opusconsulting.pegasus.runtime.IValueProvider;
import com.opusconsulting.pegasus.runtime.bean.ConfigMetaDataBeanLoader;
import com.opusconsulting.pegasus.runtime.format.XmlUtility;
import com.opusconsulting.pegasus.runtime.formula.ISOMessageCodeProvider;
import com.opusconsulting.pegasus.runtime.formula.util.IConditionUtility;
import com.opusconsulting.pegasus.runtime.formula.util.IValueProviderUtility;
import com.opusconsulting.pegasus.runtime.mapper.layman.ContextKeyFactory;
import com.opusconsulting.pegasus.runtime.mapper.layman.RoutingRule;
import com.opusconsulting.spartan.formula.excel.Constant;
import com.opusconsulting.spartan.formula.excel.Expression;
import com.opusconsulting.spartan.formula.excel.ExpressionType;
import com.opusconsulting.spartan.formula.excel.Function;
import com.opusconsulting.spartan.formula.excel.Model;
import com.opusconsulting.spartan.formula.excel.StringConstant;
import com.opusconsulting.spartan.formula.excel.Variable;

@SuppressWarnings({"rawtypes", "unchecked"})
public class ConfigMetaDataBuilderStep extends AbstractStepInstance {
	private static final Logger _logger = LoggerFactory.getLogger(ConfigMetaDataBuilderStep.class);
	String filePath;
	
	@Inject
	IConditionUtility conditionUtility;
	
	@Inject
	IValueProviderUtility valueProviderUtility;
	
	@Inject
	ConfigMetaDataBeanLoader configMetaDataBeanLoader;  

	@Autowired
	ContextKeyFactory  contextKeyFactory;


	@Inject
	FormulaParser parser;		
	
	@PostConstruct
	void init() {
	}

	@Override
	public <I, R> R process(IFlowContext context, I previousStepResult, Map<String, Object> flowProps) {
		_logger.debug("Processing loaded JSON data started...");
		Map<String, Object> pojoMetaDataMap = new HashMap<>();

		Map<String, NodeDetail> nodeDetailsMap = new HashMap<>();

		Map<String, List<MappingConfig>> mappingConfigMap = new HashMap<>();

		Map<String, List<RoutingRule>> routingMap = new HashMap<String, List<RoutingRule>>();

		Map<String, Map<MessageDetail, ICondition>> iconditionMap = new HashMap<>();
		
		try {

			List<NodeDetail> nodeDetailsList = (List<NodeDetail>) context.get("nodes");
			Map<String, List<MappingDetails>> mappingConfigurationMap = (Map<String, List<MappingDetails>>) context
					.get("mappingConfigs");
			
			List<RoutingDetails> routingDetailsList=(List<RoutingDetails>)context.get("routings");

			nodeDetailsMap = nodeDetailsList.stream().map(nodeDetail -> {
				_logger.debug("Processing Node: {}", nodeDetail.getName());
				if(NodeFormat.ISO87.equals(nodeDetail.getFormat())
						|| NodeFormat.ISO93.equals(nodeDetail.getFormat())){
					final Map<MessageDetail, ICondition> messageIdetificationFormulaMap = conditionUtility
							.buildIsoMessageIdentificationFormulas(((ISONodeDetail)nodeDetail).getMessages(),
									new ISOMessageCodeProvider("request"));
					iconditionMap.put(nodeDetail.getName(), messageIdetificationFormulaMap);
					return nodeDetail;
				} else if(NodeFormat.XML.equals(nodeDetail.getFormat())){
					generateXMLFormula((List<XmlMessageDetails>)nodeDetail.getMessages());
					final Map<MessageDetail, ICondition> messageIdetificationFormulaMap = conditionUtility
							.buildXmlMessageIdentificationFormulas(((XmlNodeDetail)nodeDetail).getMessages(),
									new ISOMessageCodeProvider("request"));
					iconditionMap.put(nodeDetail.getName(), messageIdetificationFormulaMap);
				}else if(NodeFormat.JSON.equals(nodeDetail.getFormat())){
					final Map<MessageDetail, ICondition> messageIdetificationFormulaMap = conditionUtility
							.buildXmlMessageIdentificationFormulas(((XmlNodeDetail)nodeDetail).getMessages(),
									new ISOMessageCodeProvider("request"));
					iconditionMap.put(nodeDetail.getName(), messageIdetificationFormulaMap);
				}
				return nodeDetail;
			}).collect(Collectors.toMap(NodeDetail::getName, (nodeDetail) ->{
				return nodeDetail;
			})) ;

			Set<String> keys = mappingConfigurationMap.keySet();
			for (String mapKey : keys) {
				List<MappingConfig> mappingConfigsList = new ArrayList<>();
				for (MappingDetails mappingDetails : mappingConfigurationMap.get(mapKey)) {
					ICondition iCondition = conditionUtility.buildCondition(mappingDetails.getMappingIdentificationFormula(),
							new ISOMessageCodeProvider("request"));

					MappingConfig mappingConfig = new MappingConfig(mappingDetails.getDestinationMessageName(),
							iCondition);

					Map<String, IValueProvider> fieldMappingMap = valueProviderUtility.buildMessageMappingDetails(
							mappingDetails.getFieldMapping(), new ISOMessageCodeProvider("request"));

					mappingConfig.setFieldMapping(fieldMappingMap);
					mappingConfig.setDestinationName(mappingDetails.getDestinationNodeName());
					mappingConfig.setDestinationFormat(mappingDetails.getDestinationFormat());
					mappingConfig.setSourceNodeName(mappingDetails.getSourceNodeName());
					mappingConfig.setSourceMessageName(mappingDetails.getSourceMessageName());
					mappingConfig.setSourceFormat(mappingDetails.getSourceFormat());
					mappingConfigsList.add(mappingConfig);
				}
				if (mappingConfigMap.containsKey(mapKey)) {
					List<MappingConfig> mappingList = mappingConfigMap.get(mapKey);
					mappingList.addAll(mappingConfigsList);
					mappingConfigMap.put(mapKey, mappingList);
				} else {
					mappingConfigMap.put(mapKey, mappingConfigsList);
				}
			}
			
			
			
			for(RoutingDetails routingDetails: routingDetailsList){
				List<RoutingRule> routingRules=new ArrayList<>();
				for(RoutingFormulaDetails routingFormulaDetails: routingDetails.getRoutingFormulas()){
					RoutingRule routingRule = new RoutingRule();
					routingRule.setDestinationNode(routingFormulaDetails.getDestinationNode());
					routingRule.setCondition(conditionUtility.buildCondition(routingFormulaDetails.getRoutingFormula(),
							new ISOMessageCodeProvider("request")));
					routingRules.add(routingRule);
				}
				
				routingMap.put(routingDetails.getNodeName(), routingRules);
			}

			
	/*Below code added for to read the message wise context fields from properties file*/
			
			nodeDetailsList.stream().forEach((node -> {
				((List<MessageDetail>) node.getMessages()).stream().forEach((message -> {
					contextKeyFactory.register(node.getName() + "." + message.getName());
				}));

			}));

		} catch (Exception e) {
			_logger.error("Exception while Processing JSON data.", e);
			onError(context, pojoMetaDataMap, flowProps, e);
		}

		pojoMetaDataMap.put("nodeDetails", nodeDetailsMap);
		pojoMetaDataMap.put("mappingConfigs", mappingConfigMap);
		pojoMetaDataMap.put("routings", routingMap);
		pojoMetaDataMap.put("messageFormulas", iconditionMap);
		pojoMetaDataMap.put("virtualizationDetails", context.get("virtualizationDetails"));
		pojoMetaDataMap.put("endPoints", context.get("endPoints"));
		_logger.debug("Loading spring bean for processed meta data...");
		loadConfigMetaDataFactory(pojoMetaDataMap);
		return (R) pojoMetaDataMap;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	private void loadConfigMetaDataFactory(Map<String, Object> completeConfigMetaDataMap) {
		Map<String, List<RoutingRule>> routingConfigs = (Map<String, List<RoutingRule>>) completeConfigMetaDataMap
				.get("routings");
		configMetaDataBeanLoader.loadRoutingRuleBeans(routingConfigs);
		_logger.debug("Routing beans registered successfully");
		Map<String, Map<MessageDetail<MessageFieldDetail<FieldDetail>>, ICondition>> messageConfigs = (Map<String, Map<MessageDetail<MessageFieldDetail<FieldDetail>>, ICondition>>) completeConfigMetaDataMap
				.get("messageFormulas");
		configMetaDataBeanLoader.loadMessageIdentifierBeans(messageConfigs);
		_logger.debug("Message Identification beans registered successfully");
		configMetaDataBeanLoader.loadMessageCreatorBeans(messageConfigs);
		_logger.debug("Message creator beans registered successfully");

		Map<String, List<MappingConfig>> mappingConfigs = (Map<String, List<MappingConfig>>) completeConfigMetaDataMap
				.get("mappingConfigs");
		configMetaDataBeanLoader.loadMappingConfigBeans(mappingConfigs);
		_logger.debug("Message mapping config beans registered successfully");
		configMetaDataBeanLoader.buildEndPointBeans((Map<String, NodeDetail>) completeConfigMetaDataMap.get("nodeDetails"));
		_logger.debug("Node End point beans registered successfully");
	}
	
	private Map<XmlMessageDetails, String> generateXMLFormula(List<XmlMessageDetails> xmlMessageDetails) {
		_logger.debug("Generating Message Identification formula for a messages started...");
		Map<XmlMessageDetails, String> formulasMap = new HashMap<>();

		for (XmlMessageDetails xmlMessageDetail : xmlMessageDetails) {
			_logger.debug("Formula : {}, Message Name: {}", xmlMessageDetail.getMessageIdentificationFormula(), xmlMessageDetail.getName());
			IParseResult parseResult = parser.parse(xmlMessageDetail.getMessageIdentificationFormula());
			if (parseResult.hasSyntaxErrors()) {
				_logger.error("Formula parsing error occured.", new ParseException(parseResult.getSyntaxErrors()));
				continue;
			}

			Model model = (Model) parseResult.getRootASTElement();
			StringBuilder formulaBuilder = new StringBuilder();
			Expression expression = model.getExpression();
			processExpression(expression, formulaBuilder, xmlMessageDetail);
			formulasMap.put(xmlMessageDetail, formulaBuilder.toString());
			xmlMessageDetail.setMessageIdentificationFormula(formulaBuilder.toString());
			_logger.debug("Message Name: {}, Generated XML formula : {} ", xmlMessageDetail.getName(), formulaBuilder.toString());
		}
		_logger.debug("Generating Message Identification formula for a messages finished.");
		return formulasMap;
	}
	
	
	private void processExpression(Expression expression, StringBuilder formulaBuilder,XmlMessageDetails xmlMessageDetails)
            throws RuntimeException {
        processExpressionType(expression.getType(), formulaBuilder,xmlMessageDetails);
    }

    private void processExpressionType(ExpressionType type, StringBuilder formulaBuilder,XmlMessageDetails xmlMessageDetails) throws RuntimeException {
        if (type instanceof Function) {
            processFunction((Function) type, formulaBuilder,xmlMessageDetails);
        } else if (type instanceof Variable) {
            processVariable((Variable) type, formulaBuilder,xmlMessageDetails);
        } else if (type instanceof Constant) {
            processConstant((Constant) type, formulaBuilder);
        } else {
            throw new RuntimeException("Invalid expression type ... " + type.getClass());
        }
    }

	private void processConstant(Constant type, StringBuilder formulaBuilder) {
		formulaBuilder.append("\"");
		formulaBuilder.append(((StringConstant)type.getValue()).getValue());
		formulaBuilder.append("\"");
	}

	private void processVariable(Variable type, StringBuilder formulaBuilder,XmlMessageDetails xmlMessageDetails) {
		formulaBuilder.append("FIND_XPATH_VALUE(\""+XmlUtility.getfieldXpath(xmlMessageDetails.getMessageFields(), type.getIds().get(type.getIds().size()-1))+"\") ");
	}

	private void processFunction(Function type, StringBuilder formulaBuilder,XmlMessageDetails xmlMessageDetails) {
		formulaBuilder.append(type.getName());
		formulaBuilder.append("(");
		formulaBuilder.append(type.getParams().stream().map((param) -> {
			StringBuilder subBuilder = new StringBuilder();
			processExpression(param, subBuilder,xmlMessageDetails);
			return subBuilder.toString();
		}).collect(Collectors.joining(",")));
		formulaBuilder.append(")");
	}
}

package com.opusconsulting.pegasus.runtime.steps;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.opusconsulting.pegasus.flow.IFlowContext;
import com.opusconsulting.pegasus.flow.impl.AbstractStepInstance;
import com.opusconsulting.pegasus.runtime.IConstants;
import com.opusconsulting.pegasus.runtime.IMessage;
import com.opusconsulting.pegasus.runtime.TransformationResult;
import com.opusconsulting.pegasus.runtime.mapper.layman.CacheAlreadyExists;
import com.opusconsulting.pegasus.runtime.mapper.layman.CacheFactory;
import com.opusconsulting.pegasus.runtime.mapper.layman.CacheMetaData;
import com.opusconsulting.pegasus.runtime.mapper.layman.CacheNotFound;
import com.opusconsulting.pegasus.runtime.mapper.layman.ContextKeyFactory;
import com.opusconsulting.pegasus.runtime.mapper.layman.ICache;
import com.opusconsulting.pegasus.runtime.mapper.layman.IKey;
import com.opusconsulting.pegasus.runtime.mapper.layman.IMessageCreator;
import com.opusconsulting.pegasus.runtime.mapper.layman.IMessageMapping;
import com.opusconsulting.pegasus.runtime.mapper.layman.IMessageMetaData;
import com.opusconsulting.pegasus.runtime.mapper.layman.MappingNotFound;
import com.opusconsulting.pegasus.runtime.mapper.layman.MessageCreatorFactory;
import com.opusconsulting.pegasus.runtime.mapper.layman.MessageKey;
import com.opusconsulting.pegasus.runtime.mapper.layman.MessageMapperFactory;
import org.springframework.beans.factory.annotation.Value;

public class TransformationStep extends AbstractStepInstance {
	private static final Logger _logger = LoggerFactory.getLogger(TransformationStep.class);
    @Autowired
    MessageMapperFactory messageMapperFactory;
    
    @Autowired
    MessageCreatorFactory messageCreatorFactory;

	@Value("${node.cache.enable}")
	String nodeCacheEnable;

    @Override
    public <I, R> R process(IFlowContext context, I previousStepResult, Map<String, Object> flowProps) {
        String sourceMessageName = context.get(IConstants.SOURCE_MESSAGE_NAME);
        if (sourceMessageName == null) {
        	_logger.error("No Source message information available in the flow context for this step to perform.");
        	return (R) previousStepResult;
        }

        IMessage message = context.get(IConstants.SOURCE_MESSAGE);
        if (message == null) {
        	_logger.error("No message received in the flow context for this step to perform.");
        	return (R) previousStepResult;
        }
        //TODO Earlier it was a condition in the MappingConfig which decide what mapping config to be picked for the mapping. Now, it is the MappingFactory which
        //does the same. However we still has the condition property in the MappingConfig POJO. Need to discuss and work on this.
        //Currently, it is assumed that the source message name and destination message name will be same.
        String destinationMessageName = sourceMessageName;
		try {
			final TransformationResult transformationResult = processOutgoingMessage(context.get(IConstants.FLOW_PROPS_NODE_NAME_KEY), message, context.get(IConstants.DESTINATION_NODE_NAME), destinationMessageName,flowProps);
			return (R) transformationResult;
		} catch (CacheAlreadyExists e) {
			_logger.error("Error while processing the trasformation. Duplicate message received for the transformation", e);
			handleDuplicateRequestCache(context, message, flowProps, e);
			return (R) new TransformationResult(null, flowProps);
		} catch (MappingNotFound e) {
			_logger.error("Error while processing the trasformation. Target mapping not found for the transformation. Failed with error.", e);
			handleTargetMappingNotFound(context, message, flowProps, e);
			return (R) previousStepResult;
		} catch (CacheNotFound e) {
			_logger.error("Error while processing the trasformation. Cache not found error occured.", e);
			handleCacheNotFound(context, message, flowProps, e);
			return (R) previousStepResult;
		}

        /*if (transformationResult == null) {
        	_logger.error("No mapping result returned from the process.");
        	return (R) previousStepResult;
        }
        
        if(transformationResult.getiMessage()==null) {
        	_logger.error("No transformed message in the mapping result returned from the process.");
        	return (R) previousStepResult;
        }*/
//        return (R) transformationResult;
    }

	private TransformationResult processOutgoingMessage(String origin, IMessage message, String target, String targetMessageName,Map<String, Object> flowProps) throws CacheAlreadyExists, MappingNotFound, CacheNotFound {
		_logger.debug("Mapping performing for Source Node: {}, Source Message: {}, Destination Node: {}, Destination message: {}", origin, message.getMetaData().getName(), target, targetMessageName);
		IMessage targetMessage = createNewMessage(target, targetMessageName);
		_logger.debug("Blank message created successfully.");
		_logger.debug("Message fields mapping started...");
		mapFields(origin, message, target, targetMessageName, targetMessage);
		_logger.debug("Message fields mapping completed.");
		if (isRequest(targetMessage)) {
			addToRequestCache(target, targetMessage);
		} /*else {
			//this replaces the cached request with response. Replace as it will have same context key as request.
			addToResponseCache(target, targetMessage);
		}*/
		
		//Commented to handle idempotence
		else {
			_logger.debug("Remove Cache....");
			removeFromRequestCache(origin, message);
			
			removeFromRequestCache(target, targetMessage);
		}
		
		 flowProps.put(IConstants.EVENT_CTX_DESTINATION_NODE_NAME_KEY, target);
	     return new TransformationResult(targetMessage, flowProps);
	}

	private IMessage createNewMessage(String target, String targetMessageName) {
		IMessageCreator messageCreator = messageCreatorFactory.getCreator(target);
		return messageCreator.create(targetMessageName);
	}

	private boolean isRequest(IMessage message) {
		IMessageMetaData metaData = message.getMetaData();
		return (metaData == null || metaData.isRequest());
	}

	private void addToRequestCache(String origin, IMessage message) throws CacheAlreadyExists {
		if(nodeCacheEnable.equalsIgnoreCase("true")) {
			ICache cache = CacheFactory.getCache(origin);
			String cacheKey = getCacheKey(message, ContextKeyFactory.getKey(origin + "." + message.getMetaData().getName()));
			if (cache.exists(cacheKey)) {
				throw new CacheAlreadyExists();
			}

			cache.push(cacheKey, new CacheMetaData(message, origin));
		}
	}
	
	private void addToResponseCache(String target, IMessage message) throws CacheAlreadyExists {
		ICache cache = CacheFactory.getCache(target);
		String cacheKey = getCacheKey(message, ContextKeyFactory.getKey(target+"."+message.getMetaData().getName()));
		//replace if any available else create new entry. Ideally there should be one entry already present with request data.
		cache.push(cacheKey, new CacheMetaData(message, target));
	}
	
	private void removeFromRequestCache(String origin, IMessage message) {
		ICache cache = CacheFactory.getCache(origin);
		String cacheKey = getCacheKey(message, ContextKeyFactory.getKey(origin+"."+message.getMetaData().getName()));
		if (cache.exists(cacheKey)) {
			cache.pop(cacheKey);
		}
	}

	private String getCacheKey(IMessage targetMessage, List<IKey> contextFields) {
		StringBuilder keyBuilder = new StringBuilder();
		for (IKey contextField : contextFields) {
			Object value = null;
			if(contextField.getValue().contains(".")){
				List<String> keyValues = Arrays.asList(contextField.getValue().split("\\."));
				value = fetchFieldValue(keyValues, targetMessage, 0);
			} else {
				value = targetMessage.getValue(contextField);
			}
			if(value == null){
				_logger.error("Context Key value is null while preparing the cache key. Context Key : {0}", contextField.getValue());
				keyBuilder.append("null");
			} else {
				keyBuilder.append(value.toString());
			}
			keyBuilder.append("$");
		}
		return keyBuilder.toString();
	}
	
	private Object fetchFieldValue(List<String> keyValues, IMessage message, int keyIndex){
		Object fieldValue = message.getValue(new MessageKey(keyValues.get(keyIndex)));
		keyIndex++;
		if(keyIndex == keyValues.size()) return fieldValue;
		return fetchFieldValue(keyValues, (IMessage)fieldValue, keyIndex);
	}

	private void mapFields(String origin, IMessage originMessage, String target, String targetMessageName,
			IMessage targetMessage) throws MappingNotFound, CacheNotFound {
		String sourceMessageName = originMessage.getMetaData().getName();
		IMessageMapping mapping = messageMapperFactory.getMapping(origin, sourceMessageName, target, targetMessageName,originMessage);
		if(mapping == null ){
			_logger.error("No Message fields mapping configuration found for Source Node: {}, Source Message: {}, Destination Node: {}, Destination message: {}", origin, originMessage.getMetaData().getName(), target, targetMessageName);
			return;
		}
		IMessage targetRequestMessage = null;
		if (!isRequest(targetMessage)) {
			_logger.debug("This is response and fetching the cached request message.");
			List<IKey> contextFields = getContextFields(target, targetMessage);
			mapping.map(originMessage, targetMessage, contextFields);
			targetRequestMessage = pullRequestFromCache(target, targetMessage);
		}
		_logger.debug("Field to field mapping started for the target message...");
		mapping.map(originMessage, targetMessage, targetRequestMessage);
		_logger.debug("Field to field mapping completed for the target message.");
	}

	private List<IKey> getContextFields(String target, IMessage targetMessage) {
		return ContextKeyFactory.getKey(target+"."+targetMessage.getMetaData().getName());
	}

	private IMessage pullRequestFromCache(String origin, IMessage message) throws CacheNotFound {
		if(nodeCacheEnable.equalsIgnoreCase("true")) {
			ICache cache = CacheFactory.getCache(origin);
			String cacheKey = getCacheKey(message, ContextKeyFactory.getKey(origin + "." + message.getMetaData().getName()));
//		IMessage cachedMessage = cache.pop(cacheKey); //TODO currently commented as response should be in the cache, to handle Idempotence
			IMessage cachedMessage = cache.fetch(cacheKey);
			if (cachedMessage == null) {
				throw new CacheNotFound();
			}

			return cachedMessage;
		}
		return null;
	}

	//TODO
	private void handleCacheNotFound(IFlowContext context, IMessage message, Map<String, Object> flowProps, CacheNotFound e) {
		//TODO need to discuss and work
		_logger.error("Cache not found for the transformation. Failed with error.");
		onError(context, message, flowProps, e);
	}

	//TODO
	private void handleDuplicateRequestCache(IFlowContext context, IMessage message, Map<String, Object> flowProps, CacheAlreadyExists e) {
		//TODO need to discuss and work
		_logger.error("Duplicate request received for the transformation. Failed with error.");
		onError(context, message, flowProps, e);
	}

	//TODO
	private void handleTargetMappingNotFound(IFlowContext context, IMessage message, Map<String, Object> flowProps, MappingNotFound mappingNotFound) {
		//TODO need to discuss and work
		_logger.error("Target mapping not found for the transformation. Failed with error.");
		onError(context, message, flowProps, mappingNotFound);
	}
}

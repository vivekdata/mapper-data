package com.opusconsulting.pegasus.runtime.steps;

import java.util.Map;

import com.opusconsulting.pegasus.format.iso.metadata.NodeDetail;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.opusconsulting.pegasus.common.resource.exception.ApplicationException;
import com.opusconsulting.pegasus.flow.IFlowContext;
import com.opusconsulting.pegasus.flow.impl.AbstractStepInstance;
import com.opusconsulting.pegasus.runtime.IConstants;
import com.opusconsulting.pegasus.runtime.IMessage;
import com.opusconsulting.pegasus.runtime.steps.iso.ByteParser;

public class JSONByteBufferDeserializerStep extends AbstractStepInstance {

	private static final Logger _logger = LoggerFactory.getLogger(JSONByteBufferDeserializerStep.class);
	@Autowired
	private ByteParser parser;

	private NodeDetail nodeDetail;

	@Override
	public <I, R> R process(IFlowContext context, I previousStepResult, Map<String, Object> flowProps) {
		_logger.debug("{} JSON process ... {} ", this.nodeDetail.getName(), flowProps.get(IConstants.FLOW_PROPS_NODE_NAME_KEY));
		_logger.debug("JSON process event message received:isReply: {} ", flowProps.get(IConstants.IS_PROCESS_EVENT_MESSAGE_RECEIVED_KEY));

		byte[] messageBytes = (byte[]) flowProps.get(IConstants.FLOW_PROPS_MESSAGE_BUFFER_KEY);

		if (messageBytes == null) {
			_logger.error("No message byte received to the step execution in the Flow properties. It might possible that server receives the HTTP GET/DELETE.");
			return null;
		}

		if (flowProps.get("nodeName") == null) {
			_logger.error(
					"No necessary artefacts are available to complete the message byte deserialization step. No parser or Nodename.");
			return (R) messageBytes;
		}
		final String nodeName = (String) flowProps.get(IConstants.FLOW_PROPS_NODE_NAME_KEY);
		final Boolean isEventReply = (Boolean) flowProps.get(IConstants.IS_PROCESS_EVENT_MESSAGE_RECEIVED_KEY);

		try {
			return (R) this.parser.unpack(messageBytes, nodeName, isEventReply);
		} catch (ApplicationException e) {
			_logger.error(e.getMessage(), e);
			onError(context, null, flowProps, e);
			return null;
		}

	}
	public void setNodeDetail(NodeDetail nodeDetail) {
		this.nodeDetail = nodeDetail;
	}
}

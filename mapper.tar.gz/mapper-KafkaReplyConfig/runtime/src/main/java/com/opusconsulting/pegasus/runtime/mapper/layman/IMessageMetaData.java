package com.opusconsulting.pegasus.runtime.mapper.layman;

public interface IMessageMetaData {
    String getName();

    boolean isRequest();
}

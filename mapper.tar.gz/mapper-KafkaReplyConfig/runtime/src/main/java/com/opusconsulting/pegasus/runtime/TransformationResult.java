package com.opusconsulting.pegasus.runtime;

import java.util.Map;

public class TransformationResult {

	private IMessage iMessage;
	private Map<String, Object> params;
	
	
	public TransformationResult(IMessage iMessage, Map<String, Object> params) {
		super();
		this.iMessage = iMessage;
		this.params = params;
	}
	
	public IMessage getiMessage() {
		return iMessage;
	}
	public Map<String, Object> getParams() {
		return params;
	}
	
	
	
}

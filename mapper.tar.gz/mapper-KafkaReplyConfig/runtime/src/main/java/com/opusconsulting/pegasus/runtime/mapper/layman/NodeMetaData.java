package com.opusconsulting.pegasus.runtime.mapper.layman;

import java.io.Serializable;

public class NodeMetaData implements INodeMetaData,Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1242885469145745436L;
	String nodeName;
	
	public NodeMetaData(String nodeName) {
		super();
		this.nodeName = nodeName;
	}

	@Override
	public String getName() {
		return this.nodeName;
	}

	@Override
	public void setName(String name) {
		this.nodeName = name;		
	}

}

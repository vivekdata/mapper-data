package com.opusconsulting.pegasus.runtime.mapper.layman;

import java.util.List;

import com.opusconsulting.pegasus.runtime.IMessage;

public class IRoutingRulesImpl implements IRoutingRules {

	List<RoutingRule> routingRules;
	String originNodeName;

	public IRoutingRulesImpl(String originNodeName, List<RoutingRule> routingRules) {
		super();
		this.originNodeName = originNodeName;
		this.routingRules = routingRules;
	}

	@Override
	public MatchingDetail match(IMessage message) {
		MatchingDetail matchingDetail = null;
		for (RoutingRule routing : routingRules) {
			if (routing.getCondition().check(message, null, null)) {
				matchingDetail = new MatchingDetail(message.getMetaData().getName(), routing.getDestinationNode());
				break;
			}
		}
		return matchingDetail;
	}

	@Override
	public String getOriginName() {
		return this.originNodeName;
	}

}

package com.opusconsulting.pegasus.runtime.brokers.consumer;

import com.opusconsulting.pegasus.common.event.IEventPublisher;
import com.opusconsulting.pegasus.event.impl.EventContext;
import com.opusconsulting.pegasus.runtime.IConstants;
import com.opusconsulting.pegasus.runtime.event.handler.ClientCommunicationEventHandler;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.header.Header;
import org.apache.kafka.common.header.Headers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import javax.inject.Inject;

@Component
public class TopicListener {
    private static final Logger _logger = LoggerFactory.getLogger(TopicListener.class);

    @Inject
    @Lazy
    IEventPublisher processMessageEventPublisher;

    @Inject
    String sourceNode;

    @KafkaListener(topics = {"${topic.name.consumer}"})
    public void consume(ConsumerRecord<String, String> payload){
        _logger.debug("key: {}", payload.key());
        _logger.debug("Headers: {}", payload.headers());
        _logger.debug("Partition: {}", payload.partition());
        _logger.debug("value: {}", payload.value());

        EventContext context = new EventContext();
        // Default source node
        context.set(IConstants.EVENT_CTX_SOURCE_NODE_NAME_KEY, sourceNode);

        // KAFKA TOPIC HEADER
        Headers headers =  payload.headers();
        if (headers != null) {
            for (Header header : headers) {
                _logger.debug("Kafka Header: {} / {} ",header.key(), new String(header.value()));
                if(header.key().equals(IConstants.KF_TOPIC)) {
                    context.set( header.key(), new String(header.value()) );
                }
                if(header.key().equals(IConstants.EVENT_CTX_SOURCE_NODE_NAME_KEY)) {
                    if(!sourceNode.equals(new String(header.value()))) {
                        context.set( IConstants.IS_PROCESS_EVENT_MESSAGE_RECEIVED_KEY, "true");
                    }
                    context.set( IConstants.EVENT_CTX_SOURCE_NODE_NAME_KEY, new String(header.value()));
                }
            }
        }

        context.set(ClientCommunicationEventHandler.RESPONSE_BUFFER, payload.value().getBytes());
        processMessageEventPublisher.publish(payload.value().getBytes(), context);
    }
}

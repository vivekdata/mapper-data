package com.opusconsulting.pegasus.runtime.brokers.producer;

import com.opusconsulting.pegasus.runtime.IConstants;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.header.Header;
import org.apache.kafka.common.header.internals.RecordHeader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class TopicProducer {
    private static final Logger _logger = LoggerFactory.getLogger(TopicProducer.class);

    @Autowired
    KafkaTemplate<String, String> kafkaTemplate;

    @Value("${topic.name.consumer}")
    private String consumerTopic;

    public void send(String message, String topic, String nodeName){
        _logger.debug("Payload : {}",  message);
        _logger.debug("Payload topic: {}",  topic);
        _logger.debug("Payload nodeName: {}",  nodeName);
        List<Header> headers = new ArrayList<>();
        ProducerRecord<String, String> record = new ProducerRecord<>(topic, null, "Key_"+topic, message, headers);

        if(null != nodeName) {
            headers.add(new RecordHeader(IConstants.KF_TOPIC, topic.getBytes()));
            headers.add(new RecordHeader(IConstants.EVENT_CTX_SOURCE_NODE_NAME_KEY, nodeName.getBytes()));
            record = new ProducerRecord<>(consumerTopic, null, "Reply_Key_"+topic, "1110"+message.substring(4 , message.length()), headers);
        }

        kafkaTemplate.send(record);
    }

    /*public void send(String message, String nodeName){
        _logger.debug("Virtual Payload: {}",  message);
        _logger.debug("Virtual Payload Destination Node: {}",  nodeName);

        List<Header> headers = new ArrayList<>();
        headers.add(new RecordHeader(IConstants.KF_TOPIC, topicName.getBytes()));
        headers.add(new RecordHeader(IConstants.EVENT_CTX_DESTINATION_NODE_NAME_KEY, nodeName.getBytes()));
        headers.add(new RecordHeader(IConstants.IS_PROCESS_EVENT_MESSAGE_RECEIVED_KEY, "true".getBytes()));

        ProducerRecord<String, String> record = new ProducerRecord<>(producerTopicName, null, "111", message, headers);
        kafkaTemplate.send(record);
    }

    public void send(String message){
        _logger.debug("Msg Payload: {}",  message);
        kafkaTemplate.send("topic.producer", message);
    }*/
}

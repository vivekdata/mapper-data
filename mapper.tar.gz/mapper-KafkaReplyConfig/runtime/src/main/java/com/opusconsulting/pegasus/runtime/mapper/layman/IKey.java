package com.opusconsulting.pegasus.runtime.mapper.layman;

public interface IKey {
	String getValue();
}

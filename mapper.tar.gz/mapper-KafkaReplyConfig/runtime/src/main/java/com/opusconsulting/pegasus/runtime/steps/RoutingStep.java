package com.opusconsulting.pegasus.runtime.steps;

import java.util.Map;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.opusconsulting.pegasus.flow.IFlowContext;
import com.opusconsulting.pegasus.flow.impl.AbstractStepInstance;
import com.opusconsulting.pegasus.runtime.IConstants;
import com.opusconsulting.pegasus.runtime.IMessage;
import com.opusconsulting.pegasus.runtime.mapper.layman.IRoutingRules;
import com.opusconsulting.pegasus.runtime.mapper.layman.MatchingDetail;
import com.opusconsulting.pegasus.runtime.mapper.layman.RoutingDestinationNotFound;
import com.opusconsulting.pegasus.runtime.mapper.layman.RoutingRulesFactory;

public class RoutingStep extends AbstractStepInstance {
	private static final Logger _logger = LoggerFactory.getLogger(RoutingStep.class);
	@Autowired
	RoutingRulesFactory routingRulesFactory;
	
	@Autowired
	String sourceNode;

	@PostConstruct
	void init() {

	}

	@Override
	public <I, R> R process(IFlowContext context, I previousStepResult, Map<String, Object> flowProps){
		IMessage message = context.get(IConstants.SOURCE_MESSAGE);
		if (message == null) {
			_logger.error("No message received in the flow context for this step to perform.");
			return (R) previousStepResult;
		}
		
		final String sourceMessageName = context.get(IConstants.SOURCE_MESSAGE_NAME);
		if (sourceMessageName == null) {
			_logger.error("No Source message information available in the flow context for this step to perform.");
			return (R) previousStepResult;
		}

		if(context.get(IConstants.DESTINATION_NODE_NAME) != null) {
			context.remove(IConstants.DESTINATION_NODE_NAME);
		}
		_logger.debug("Routing match details analyzing...");
		MatchingDetail matchingDetail;
		try {
			if (!message.getMetaData().isRequest()){
				if(sourceNode == null){
					_logger.error("No source node information available to determine the response destination.");
					throw new RoutingDestinationNotFound("Source node not defined in runtimeConfig file");
				}
				matchingDetail = new MatchingDetail(sourceMessageName, sourceNode);
			} else {
				matchingDetail = routing(context.get(IConstants.FLOW_PROPS_NODE_NAME_KEY), message);
			}
			
			if (matchingDetail != null) {
				context.put(IConstants.DESTINATION_NODE_NAME, matchingDetail.getNodeName());
				flowProps.put(IConstants.DESTINATION_NODE_NAME, matchingDetail.getNodeName());
			}
			_logger.debug("Routing match details successfully identified. Destination Node name: {}", matchingDetail.getNodeName());
		} catch (RoutingDestinationNotFound e) {
			_logger.error("Error while analyzing routing match details.", e);
			onError(context, previousStepResult, flowProps, e);
		}
			
		return (R) previousStepResult;
	}

	private MatchingDetail routing(String origin, IMessage message) throws RoutingDestinationNotFound {
		IRoutingRules rules = routingRulesFactory.getRules(origin);
		MatchingDetail match = rules.match(message);
		if (match == null) {
			throw new RoutingDestinationNotFound();
		}

		return match;
	}
}

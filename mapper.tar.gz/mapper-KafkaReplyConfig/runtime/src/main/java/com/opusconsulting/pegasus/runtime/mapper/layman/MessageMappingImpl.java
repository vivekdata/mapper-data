package com.opusconsulting.pegasus.runtime.mapper.layman;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import com.opusconsulting.pegasus.format.NodeFormat;
import com.opusconsulting.pegasus.runtime.DefaultIMessage;
import com.opusconsulting.pegasus.runtime.IConstants;
import com.opusconsulting.pegasus.runtime.IMessage;
import com.opusconsulting.pegasus.runtime.IValueProvider;
import com.opusconsulting.pegasus.runtime.steps.MappingConfig;
import io.vertx.core.json.JsonObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MessageMappingImpl implements IMessageMapping {

	private static final Logger _logger = LoggerFactory.getLogger(MessageMappingImpl.class);
	private MappingConfig mappingConfig;
	private IMappingMetaData metaData;

	public MessageMappingImpl(MappingConfig mappingConfig, IMappingMetaData metaData) {
		super();
		this.mappingConfig = mappingConfig;
		this.metaData = metaData;
	}

	@Override
	public void map(IMessage originMessage, IMessage targetMessage, List<IKey> contextFields) {
		mappingConfig.getFieldMapping().entrySet().stream().filter((entry) -> {
			return contextFields.stream().anyMatch((iKey ->{
				return entry.getKey().equalsIgnoreCase(iKey.toString());
			}));
		}).forEach(entry ->{
			Object value = entry.getValue().get(originMessage, null, null);
//			targetMessage.setValue(new MessageKey(entry.getKey()), value);
			loadMessageValue(targetMessage, entry.getKey(), value);
		});
	}

	@Override
	public void map(IMessage originMessage, IMessage targetMessage, IMessage targetRequestMessage) {

		//_logger.debug("SourceFormat {}, DestinationFormat {}", mappingConfig.getSourceFormat(), mappingConfig.getDestinationFormat() );
		//param required in case to retrieve the values from the context messages
		Map<String, Object> params = new HashMap<>();
		params.put(IConstants.CONTEXT_MESSAGE, targetRequestMessage);
		for (Map.Entry<String, IValueProvider> valueProviderEntry : mappingConfig.getFieldMapping().entrySet()) {
			String key = valueProviderEntry.getKey();
			Object value = valueProviderEntry.getValue().get(originMessage, null, params);
			////_logger.debug("Key: {} Value: {} ",key, value);

			if( ( mappingConfig.getSourceFormat().equals(NodeFormat.ISO87.name()) || mappingConfig.getSourceFormat().equals(NodeFormat.ISO93.name()) ) && key.contains(".") ) {
				String parentValue = String.valueOf(value);
				if(parentValue.startsWith("T_")) {
					parentValue = parentValue.replace("T_", "");
					Hashtable<String, Object> subDataElement = originMessage.getValue(new MessageKey(parentValue.substring(0, parentValue.indexOf("."))));
					value = subDataElement.get(parentValue.substring((parentValue.lastIndexOf(".") + 1)));
					value = (value != null ? value : "");
					//_logger.debug("Final value: {}",value);
				}
			} else if( mappingConfig.getSourceFormat().equals(NodeFormat.JSON.name())  && key.contains(".") ) {
				String parentValue = String.valueOf(value);
				if(parentValue.startsWith("T_")) {
					parentValue = parentValue.replace("T_", "");
					JsonObject subDataElement = ((DefaultIMessage) originMessage.getValue(new MessageKey(parentValue.substring(0, parentValue.indexOf("."))))).format();
					String childElement = parentValue.substring((parentValue.lastIndexOf(".") + 1));
					value = subDataElement.getValue(childElement);
					value = (value != null ? value : "");
					//_logger.debug("JSON Final value: {}",value);
				}
			}

			loadMessageValue(targetMessage, valueProviderEntry.getKey(), value);
		}
	}

	/**
	 * This function checks if the field name is of type "Composite" then it prepare the object hierarchy
	 * @param targetMessage
	 * @param fieldName
	 * @param value
	 */
	private void loadMessageValue(IMessage targetMessage, String fieldName,
			Object value) {
		if(fieldName.contains(".")){
			populateSubFieldsForMapping(targetMessage, fieldName.split("\\."), 0, value);
		} else {
			targetMessage.setValue(new MessageKey(fieldName), value);
		}
	}

	private void populateSubFieldsForMapping(IMessage message, String[] compositeFields, int fieldStartIndex, Object value) {
		DefaultIMessage subFieldIMessage = message.getValue(new MessageKey(compositeFields[fieldStartIndex]));
		if(subFieldIMessage == null){
			subFieldIMessage = new DefaultIMessage(message.getNodeMetaData());
		}
		message.setValue(new MessageKey(compositeFields[fieldStartIndex]),
				subFieldIMessage);
		fieldStartIndex++;
		if(fieldStartIndex < (compositeFields.length - 1)){
			populateSubFieldsForMapping(subFieldIMessage, compositeFields, fieldStartIndex, value);
		} else {
			subFieldIMessage.setValue(new MessageKey(compositeFields[fieldStartIndex]), value);
		}
	}

	@Override
	public IMappingMetaData getMetaData() {
		return this.metaData;
	}

}

package com.opusconsulting.pegasus.runtime.steps;

import java.util.Map;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.opusconsulting.pegasus.common.resource.exception.ApplicationException;
import com.opusconsulting.pegasus.flow.IFlowContext;
import com.opusconsulting.pegasus.flow.impl.AbstractStepInstance;
import com.opusconsulting.pegasus.format.iso.metadata.ISONodeDetail;
import com.opusconsulting.pegasus.runtime.IConstants;
import com.opusconsulting.pegasus.runtime.steps.iso.ByteParser;
import com.opusconsulting.pegasus.runtime.steps.iso.ISOBufferParser;

public class ISOByteBufferDeserializerStep extends AbstractStepInstance {
	private static final Logger _logger = LoggerFactory.getLogger(ISOByteBufferDeserializerStep.class);
	private ISONodeDetail nodeDetail;
	private ByteParser parser;
	
	@PostConstruct
	void init() {
		this.parser = new ISOBufferParser(nodeDetail.getFieldDetails(), nodeDetail.getMessages());
	}
	
	@Override
	public <I, R> R process(IFlowContext context, I previousStepResult, Map<String, Object> flowProps) {
		_logger.debug("ISO process ... {} ", flowProps.get(IConstants.FLOW_PROPS_NODE_NAME_KEY));
		_logger.debug("ISO process event message received:isReply: {} ", flowProps.get(IConstants.IS_PROCESS_EVENT_MESSAGE_RECEIVED_KEY));


		byte[] messageBytes = (byte[]) flowProps.get(IConstants.FLOW_PROPS_MESSAGE_BUFFER_KEY);
		
		if(messageBytes == null){
			_logger.error("No message byte received to the step execution in the Flow properties.");
            return null;
		}
		if(this.parser == null || flowProps.get("nodeName") == null){
			_logger.error("No necessary artefacts are available to complete the message byte deserialization step. No parser or Nodename.");
			return (R) messageBytes;
		}
		final String nodeName = (String) flowProps.get(IConstants.FLOW_PROPS_NODE_NAME_KEY);
		final Boolean isEventReply = (Boolean) flowProps.get(IConstants.IS_PROCESS_EVENT_MESSAGE_RECEIVED_KEY);

		try {
			return (R) this.parser.unpack((byte[])messageBytes, nodeName, isEventReply);
		} catch (ApplicationException e) {
			_logger.error(e.getMessage(), e);
			onError(context, null, flowProps, e);
			return null;
		}
		
	}

	public void setNodeDetail(ISONodeDetail nodeDetail) {
		this.nodeDetail = nodeDetail;
	}
}

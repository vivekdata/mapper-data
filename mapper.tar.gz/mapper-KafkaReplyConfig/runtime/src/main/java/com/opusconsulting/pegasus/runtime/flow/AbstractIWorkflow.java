package com.opusconsulting.pegasus.runtime.flow;

import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.springframework.stereotype.Component;

import com.opusconsulting.pegasus.flow.impl.FlowFactory;
import com.opusconsulting.pegasus.flow.impl.FlowMetaDataFactory;
import com.opusconsulting.pegasus.flow.metadata.IFlowMetaData;
import com.opusconsulting.pegasus.flow.metadata.LinkInstanceInfo;

@Component
public abstract class AbstractIWorkflow implements IWorkflow {
	@Inject
	FlowFactory flowFactory;
	
	@Inject
	FlowMetaDataFactory flowMetaDataFactory;
	
	@Override
	public final void registerToFactory(Map<String, Object> workFlowData) {
		final List<IFlowMetaData> flowMetaDatas = this.buildFlowMetaDatas(workFlowData);
		if(flowMetaDatas == null)
			return;
		
		flowMetaDatas.stream().forEach(flowMetaData -> {
			if(flowMetaData != null)
				flowFactory.register(flowMetaData);
		});
	}

	protected abstract List<IFlowMetaData> buildFlowMetaDatas(Map<String, Object> workFlowData);
	
	protected LinkInstanceInfo buildLinkInstance(final String sourceStepName, final String destinationStepName) {
		return new LinkInstanceInfo().setSourceStepInstanceName(sourceStepName)
				.setDestinationStepInstanceName(destinationStepName);
	}
	
	public static String prepareMetaDataName(String nodeName, String flowName) {
		return nodeName + "_" + flowName;
	}

}

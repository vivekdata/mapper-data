package com.opusconsulting.pegasus.runtime.mapper.layman;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import com.opusconsulting.pegasus.runtime.IMessage;

@Component
public class MessageMapperFactory {

	private static final Logger _logger = LoggerFactory.getLogger(MessageMapperFactory.class);

	@Lazy
	@Autowired
	List<IMessageMapping> mappingConfigurations;

	public IMessageMapping getMapping(String origin, String sourceMessageName, String target, String targetMessageName,
			IMessage originMessage) throws MappingNotFound {
		//_logger.debug("getMapping:> Origin: {} OriginMessageName: {} Target: {} TargetMessageName: {}",origin, sourceMessageName, target, targetMessageName);
		if (mappingConfigurations != null) {
			final Optional<IMessageMapping> mapping = mappingConfigurations.stream().filter(mappingConfig -> {
				_logger.debug("Origin: {} OriginMessageName: {} Target: {} TargetMessageName: {}", mappingConfig.getMetaData().getOrigin(), mappingConfig.getMetaData().getOriginMessageName(), mappingConfig.getMetaData().getTarget(), mappingConfig.getMetaData().getTargetMessageName());
				return mappingConfig.getMetaData().getOrigin().equalsIgnoreCase(origin)
						&& mappingConfig.getMetaData().getOriginMessageName().equalsIgnoreCase(sourceMessageName)
						&& mappingConfig.getMetaData().getTarget().equalsIgnoreCase(target)
						&& mappingConfig.getMetaData().getTargetMessageName().equalsIgnoreCase(targetMessageName);
			}).map(mappingConfiguration -> {
				return mappingConfiguration;
			}).findFirst();

			if (mapping.isPresent()) {
				return mapping.get();
			} else {
				return null;
			}
		}
		return null;
	}
}

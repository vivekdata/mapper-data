package com.opusconsulting.pegasus.runtime.mapper.layman;

import com.opusconsulting.pegasus.runtime.IMessage;

public interface ICache {
    void push(String cacheKey, CacheMetaData cacheMetaData);

    boolean exists(String cacheKey);

    IMessage pop(String cacheKey);

	IMessage fetch(String cacheKey);
}

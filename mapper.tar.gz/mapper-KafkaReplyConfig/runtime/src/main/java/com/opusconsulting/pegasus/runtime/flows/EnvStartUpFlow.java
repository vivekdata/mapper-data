package com.opusconsulting.pegasus.runtime.flows;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.opusconsulting.pegasus.flow.metadata.IFlowMetaData;
import com.opusconsulting.pegasus.flow.metadata.LinkInstanceInfo;
import com.opusconsulting.pegasus.flow.metadata.StepInstanceInfo;
import com.opusconsulting.pegasus.flow.metadata.impl.FlowMetaData;
import com.opusconsulting.pegasus.runtime.flow.AbstractIWorkflow;
import com.opusconsulting.pegasus.runtime.flow.IWorkflow;

@Component
public class EnvStartUpFlow extends AbstractIWorkflow {
	
	@Override
	protected List<IFlowMetaData> buildFlowMetaDatas(Map<String, Object> workFlowData) {
		final List<IFlowMetaData> metaDatas = new ArrayList<>();
		StepInstanceInfo parseJsonMetaStepInfo = new StepInstanceInfo().setName("readDBConfiguration")
				.setStepName("JSONReader");

		StepInstanceInfo buildMetaStepInfo = new StepInstanceInfo().setName("configMetaDataBuilder")
				.setStepName("ConfigMetaDataBuilder");

		LinkInstanceInfo startupFlowLink = new LinkInstanceInfo()
				.setSourceStepInstanceName("readDBConfiguration").setDestinationStepInstanceName("configMetaDataBuilder");

		FlowMetaData flowMetaData = new FlowMetaData();
		flowMetaData.setName(prepareMetaDataName("", STARTUP));
		flowMetaData.setStartStepInstanceName("readDBConfiguration");
		flowMetaData.setStepInstancesInfo(Arrays.asList(parseJsonMetaStepInfo, buildMetaStepInfo));
		flowMetaData.setLinkInstancesInfo(Arrays.asList(startupFlowLink));
		metaDatas.add(flowMetaData);
		return metaDatas;
	}
	
	
}

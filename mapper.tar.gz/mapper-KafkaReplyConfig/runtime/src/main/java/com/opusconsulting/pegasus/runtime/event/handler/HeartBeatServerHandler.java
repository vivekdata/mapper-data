package com.opusconsulting.pegasus.runtime.event.handler;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import com.opusconsulting.pegasus.channel.tcp.TCPClientChannel;
import com.opusconsulting.pegasus.common.event.IEventContext;
import com.opusconsulting.pegasus.common.event.IEventHandler;
import com.opusconsulting.pegasus.common.event.IEventMessage;
import com.opusconsulting.pegasus.format.iso.metadata.EndPointDetail;
import com.opusconsulting.pegasus.runtime.IConstants;
import com.opusconsulting.pegasus.runtime.client.ClientConnector;
import com.opusconsulting.pegasus.runtime.mapper.layman.ClientConnectionFactory;

@Component
public class HeartBeatServerHandler implements IEventHandler {

	private static final Logger _logger = LoggerFactory.getLogger(HeartBeatServerHandler.class);

	@Autowired
	ClientConnectionFactory clientConnectionFactory;

	@Lazy
	@Autowired
	List<EndPointDetail> endpoints;
	
	@Autowired
	ClientConnector clientConnector;

	@Override
	public void handle(IEventMessage eventMessage, IEventContext context) {

		String nodeName = context.get(IConstants.EVENT_CTX_NODE_NAME_KEY);
		String address = context.get(IConstants.EVENT_CTX_ADDRESS);
		int port = context.get(IConstants.EVENT_CTX_PORT);
		try {
			boolean isComplete = clientConnector.connectToTCPClient(nodeName, address, port);
			if (isComplete) {
				TCPClientChannel reconnectedClientChannel = (TCPClientChannel) clientConnectionFactory
						.getClientChannel(nodeName);
				if (reconnectedClientChannel.isTCPClientChannelOpen()) {
					_logger.info("Application re-connected sucessfully to Client on IP: {}, Port: {}", address, port);
				} else {
					_logger.info("Connection to client failed on IP: {}, Port: {}", address, port);
				}
			}

		} catch (Exception e) {
			_logger.error("Error while connecting the Client on IP: {}, Port: {}", address, port);
			_logger.error("Connection Error.", e);
		}

	}
}

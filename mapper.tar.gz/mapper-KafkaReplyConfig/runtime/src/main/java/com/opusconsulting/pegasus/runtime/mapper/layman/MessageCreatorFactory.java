package com.opusconsulting.pegasus.runtime.mapper.layman;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

@Component
public class MessageCreatorFactory {
	
	@Lazy
	@Autowired
	List<IMessageCreator> messageCreators;
	
    public IMessageCreator getCreator(String target) {
    	if(messageCreators != null){
			final Optional<IMessageCreator> msgCreator = messageCreators.stream().filter(msgCreatorConfig -> {
				return msgCreatorConfig.getOriginName().equalsIgnoreCase(target);
			}).findFirst();
			if(msgCreator.isPresent()){
				return msgCreator.get();
			} else {
				return null;
			}
		} else {
			return null;
		}
    }
}

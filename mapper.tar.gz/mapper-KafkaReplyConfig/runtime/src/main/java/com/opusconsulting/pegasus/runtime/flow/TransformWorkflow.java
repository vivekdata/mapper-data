package com.opusconsulting.pegasus.runtime.flow;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.opusconsulting.pegasus.flow.metadata.IFlowMetaData;
import com.opusconsulting.pegasus.flow.metadata.LinkInstanceInfo;
import com.opusconsulting.pegasus.flow.metadata.StepInstanceInfo;
import com.opusconsulting.pegasus.flow.metadata.impl.FlowMetaData;
import com.opusconsulting.pegasus.runtime.IConstants;

@Component
public class TransformWorkflow extends AbstractIWorkflow {
	private static final Logger _logger = LoggerFactory.getLogger(TransformWorkflow.class);

	@Override
	protected List<IFlowMetaData> buildFlowMetaDatas(Map<String, Object> workFlowData) {
		if(workFlowData == null){
			_logger.error("Transformation workflow intiation failed due to missing workflow meta data.");
			return null;
		}
		
		final List<IFlowMetaData> metaDatas = new ArrayList<>();
		FlowMetaData flowMetaData = new FlowMetaData();
		flowMetaData.setName(prepareMetaDataName("", TRANSFORM));

		_logger.debug("building message identification step...");
		// Message Identification step
		final StepInstanceInfo messageIdStep = buildMessageIdentificationStepInfo(workFlowData);

		_logger.debug("building routing identification step...");
		// Routing step
		final StepInstanceInfo routingStep = buildRoutingStepInfo(workFlowData);

		_logger.debug("building Mapping fields step...");
		// Transformation step
		final StepInstanceInfo transformationStepInfo = buildTransformationnStepInfo(workFlowData);

		_logger.debug("Creating link for message identification and routing step...");
		final LinkInstanceInfo msgIdentificationToRouting = buildLinkInstance("messageIdentification", "routing");

		_logger.debug("Creating link for routing and mapping fields step...");
		final LinkInstanceInfo routingToTransformation = buildLinkInstance("routing", "transformation");

		final LinkInstanceInfo msgIdToTransform = new LinkInstanceInfo();
		msgIdToTransform.setSourceStepInstanceName("messageIdentification")
				.setDestinationStepInstanceName("transformation");

		flowMetaData.setStartStepInstanceName("messageIdentification")
				.setStepInstancesInfo(Arrays.asList(messageIdStep, routingStep, transformationStepInfo))
				.setLinkInstancesInfo(Arrays.asList(msgIdentificationToRouting, routingToTransformation));
		metaDatas.add(flowMetaData);		
		return metaDatas;
	}

	private StepInstanceInfo buildMessageIdentificationStepInfo(Map<String, Object> workFlowData) {
		Map<String, Object> messageIdentificationProps = new HashMap<>();
		messageIdentificationProps.put("nodeDetails", workFlowData.get(IConstants.NODE_DETAILS_CONFIGS));
		return new StepInstanceInfo().setName("messageIdentification")
				.setStepName("MessageIdentification").setProperties(messageIdentificationProps);
	}
	
	private StepInstanceInfo buildRoutingStepInfo(Map<String, Object> workFlowData) {
		Map<String, Object> routingStepProps = new HashMap<>();
		return  new StepInstanceInfo().setName("routing").setStepName("Routing")
				.setProperties(routingStepProps);
	}
	
	private StepInstanceInfo buildTransformationnStepInfo(Map<String, Object> workFlowData) {
		Map<String, Object> transformationStepProps = new HashMap<>();
		return new StepInstanceInfo().setName("transformation")
				.setStepName("Transformation").setProperties(transformationStepProps);
	}
}

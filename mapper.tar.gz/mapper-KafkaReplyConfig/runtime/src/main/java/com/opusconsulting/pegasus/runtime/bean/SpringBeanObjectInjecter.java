package com.opusconsulting.pegasus.runtime.bean;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

@Component
public class SpringBeanObjectInjecter implements ApplicationContextAware {
	private static final Logger _logger = LoggerFactory.getLogger(SpringBeanObjectInjecter.class);
	private ApplicationContext applicationContext;
	
	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		this.applicationContext = applicationContext;
	}
	
	public <T> void inject(String beanName, T singletonObject){
		try{
			DefaultListableBeanFactory beanFactory = (DefaultListableBeanFactory) applicationContext.getAutowireCapableBeanFactory();
			beanFactory.registerSingleton(beanName, singletonObject);
		} catch(IllegalStateException exception){
			_logger.error("Error occured while loading the bean into spring context.", exception);
			//TODO
		}
	}

}

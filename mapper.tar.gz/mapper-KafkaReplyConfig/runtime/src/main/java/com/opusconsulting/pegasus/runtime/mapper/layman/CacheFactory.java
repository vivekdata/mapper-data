package com.opusconsulting.pegasus.runtime.mapper.layman;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.ehcache.CacheManager;
import org.ehcache.config.builders.CacheManagerBuilder;
import org.ehcache.xml.XmlConfiguration;
import org.ehcache.xml.exceptions.XmlConfigurationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.Environment;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Component;
@Component
public class CacheFactory {
	private static CacheManager manager;
	private static Map<String, ICache> cachePool = new HashMap<>();
	private static final Logger _logger = LoggerFactory.getLogger(CacheFactory.class);

	//@Autowired
	//Environment env;
	 @Value("${cache.config.path}")
	 Resource cacheConfig;

	//@Autowired
	//ResourceLoader resourceLoader;
	//String path ;//= env.getProperty("cache.config.path");;

	@PostConstruct
	public void init(){
		try {
		/*	path	= env.getProperty("cache.config.path");
			System.out.println("path of ehcache::::::::::"+path);
			Resource cacheConfig = resourceLoader.getResource(path);
		*/	//Resource Resource = cacheConfig;


			_logger.debug ("path of ehcache: {}", cacheConfig.getURL());
			XmlConfiguration xmlConfig = new XmlConfiguration(cacheConfig.getURL());

			manager = CacheManagerBuilder.newCacheManager(xmlConfig);
			manager.init();
			manager.getRuntimeConfiguration().getCacheConfigurations().entrySet().stream().forEach(entry -> {
				cachePool.put(entry.getKey(), new EhCache(manager.getCache(entry.getKey(), String.class, CacheMetaData.class)));
				//System.out.println("path of nodeJSONFilePath:::::"+nodeJSONFilePath);
			});
		} catch (XmlConfigurationException | IOException e) {
			_logger.error("Exception while postconstruct init method for xmlconfiguration", e);
		}

	}

	@PreDestroy
	public void shutDown(){
		if(manager != null)
			manager.close();
	}

	public static ICache getCache(String origin) {
		if(manager == null)
			return null;
		else
			return cachePool.get(origin);
	}

	/*@Bean
	public String getSourceNodeName(){//TODO need to think about this.
		path = env.getProperty("cache.config.path");
		//System.out.println("property value::::::::::sourceNodeName"+path);
		return path;
	}*/
}

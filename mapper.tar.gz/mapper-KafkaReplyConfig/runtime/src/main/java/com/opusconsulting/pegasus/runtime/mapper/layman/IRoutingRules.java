package com.opusconsulting.pegasus.runtime.mapper.layman;

import com.opusconsulting.pegasus.runtime.IMessage;

public interface IRoutingRules {
    MatchingDetail match(IMessage message);
    
    String getOriginName();
}

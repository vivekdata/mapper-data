package com.opusconsulting.pegasus.runtime.steps;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.opusconsulting.pegasus.flow.IFlowContext;
import com.opusconsulting.pegasus.flow.impl.AbstractStepInstance;
import com.opusconsulting.pegasus.format.iso.metadata.NodeDetail;
import com.opusconsulting.pegasus.runtime.DefaultIMessage;
import com.opusconsulting.pegasus.runtime.IConstants;
import com.opusconsulting.pegasus.runtime.mapper.layman.IMessageMetaData;
import com.opusconsulting.pegasus.runtime.mapper.layman.IMessageMetaDataImpl;
import com.opusconsulting.pegasus.runtime.mapper.layman.MessageIdentifierFactory;
import com.opusconsulting.pegasus.runtime.mapper.layman.MessageKey;
import com.opusconsulting.pegasus.runtime.mapper.layman.NodeMetaData;

public class HttpRequestParamDeserializerStep extends AbstractStepInstance {
	private static final Logger _logger = LoggerFactory.getLogger(HttpRequestParamDeserializerStep.class);
	private NodeDetail nodeDetail;

	@Autowired
	MessageIdentifierFactory messageIdentifierFactory;

	@Override
	public <I, R> R process(IFlowContext context, I previousStepResult, Map<String, Object> flowProps) {
		final NodeMetaData nodeMetaData = new NodeMetaData(this.nodeDetail.getName());
		if (previousStepResult != null && !previousStepResult.getClass().isAssignableFrom(DefaultIMessage.class)) {
			_logger.error(
					"Unable to extract the HTTP request parameter to DefaultIMessage due to incompatible previous result. It has to be {}",
					DefaultIMessage.class);
			return (R) previousStepResult;
		}
		DefaultIMessage iMessage = (DefaultIMessage) previousStepResult;
		boolean isRequestParamRequired = flowProps.containsKey(IConstants.IS_REQUEST_PARAM_DESERIALIZE_SERIALIZE_REQUIRED)
				? (boolean) flowProps.get(IConstants.IS_REQUEST_PARAM_DESERIALIZE_SERIALIZE_REQUIRED)
				: false;
		
		_logger.debug("Condition to update/create DefaultImessage from HTTP request parameter is : {}", isRequestParamRequired);
		if (isRequestParamRequired && previousStepResult != null) {
			loadMessageFieldsFromFlowProps(flowProps, iMessage);
			return (R) iMessage;
		} else if (isRequestParamRequired && previousStepResult == null) {
			iMessage = new DefaultIMessage(nodeMetaData);
			loadMessageFieldsFromFlowProps(flowProps, iMessage);
			IMessageMetaData iMessageMetaData = new IMessageMetaDataImpl(
					(String) flowProps.get(IConstants.HTTP_MESSAGE_NAME_PROPS_KEY),
					(boolean) flowProps.get(IConstants.IS_HTTP_REQUEST_MESSAGE_PROPS_KEY));
			iMessage.setMetaData(iMessageMetaData);
			return (R) iMessage;
		} else {
			return (R) previousStepResult;
		}
	}

	private void loadMessageFieldsFromFlowProps(Map<String, Object> flowProps, DefaultIMessage iMessage) {
		Map<String, String> props = (Map) flowProps.get(IConstants.HTTP_REQUEST_PARAM_FIELDS_KEY);

		props.entrySet().stream().forEach(entry -> {
			iMessage.setValue(new MessageKey(entry.getKey()), entry.getValue());
		});
	}

	public void setNodeDetail(NodeDetail nodeDetail) {
		this.nodeDetail = nodeDetail;
	}
}

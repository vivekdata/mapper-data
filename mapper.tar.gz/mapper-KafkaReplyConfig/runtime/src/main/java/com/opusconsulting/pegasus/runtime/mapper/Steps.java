package com.opusconsulting.pegasus.runtime.mapper;

import com.opusconsulting.pegasus.flow.EchoStepInstance;
import com.opusconsulting.pegasus.flow.metadata.IStepMetaData;
import com.opusconsulting.pegasus.flow.metadata.impl.StepMetaData;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class Steps {

    @Bean
    public static IStepMetaData addRequestCtxToCacheStep() {
        return new StepMetaData().setName("addRequestCtxToCacheStep").setType(EchoStepInstance.class);
    }

    @Bean
    public static IStepMetaData pullRequestCtxFromCacheStep() {
        return new StepMetaData().setName("pullRequestCtxFromCacheStep").setType(EchoStepInstance.class);
    }

    @Bean
    public static IStepMetaData transformStep() {
        return new StepMetaData().setName("transformStep").setType(EchoStepInstance.class);
    }

}

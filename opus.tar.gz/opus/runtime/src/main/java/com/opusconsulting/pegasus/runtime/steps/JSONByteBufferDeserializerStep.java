package com.opusconsulting.pegasus.runtime.steps;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.opusconsulting.pegasus.common.resource.exception.ApplicationException;
import com.opusconsulting.pegasus.flow.IFlowContext;
import com.opusconsulting.pegasus.flow.impl.AbstractStepInstance;
import com.opusconsulting.pegasus.runtime.IConstants;
import com.opusconsulting.pegasus.runtime.IMessage;
import com.opusconsulting.pegasus.runtime.steps.iso.ByteParser;

public class JSONByteBufferDeserializerStep extends AbstractStepInstance {

	private static final Logger _logger = LoggerFactory.getLogger(JSONByteBufferDeserializerStep.class);
	@Autowired
	private ByteParser parser;


	@Override
	public <I, R> R process(IFlowContext context, I previousStepResult, Map<String, Object> flowProps) {
		byte[] messageBytes = (byte[]) flowProps.get(IConstants.FLOW_PROPS_MESSAGE_BUFFER_KEY);

		if (messageBytes == null) {
			_logger.error("No message byte received to the step execution in the Flow properties. It might possible that server receives the HTTP GET/DELETE.");
			return null;
		}

		if (flowProps.get("nodeName") == null) {
			_logger.error(
					"No necessary artefacts are available to complete the message byte deserialization step. No parser or Nodename.");
			return (R) messageBytes;
		}
		try {
			return (R) this.parser.unpack(messageBytes);
		} catch (ApplicationException e) {
			_logger.error(e.getMessage(), e);
			onError(context, null, flowProps, e);
			return null;
		}

	}

}

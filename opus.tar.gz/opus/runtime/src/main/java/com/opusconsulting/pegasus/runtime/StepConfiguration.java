package com.opusconsulting.pegasus.runtime;

import com.opusconsulting.pegasus.flow.metadata.IStepMetaData;
import com.opusconsulting.pegasus.flow.metadata.impl.StepMetaData;
import com.opusconsulting.pegasus.runtime.steps.*;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = {"com.opusconsulting.pegasus"})
public class StepConfiguration {

    @Bean
    public static IStepMetaData createMessageIdentificationStepMetaData() {
        return new StepMetaData().setName("MessageIdentification").setType(MessageIdentificationStep.class);
    }

    @Bean
    public static IStepMetaData createTransformationStepMetaData() {
        return new StepMetaData().setName("Transformation").setType(TransformationStep.class);
    }
    

    @Bean
    public static IStepMetaData createISOByteBufferDeserializerStepMetaData() {
        return new StepMetaData().setName("ISODeserializer").setType(ISOByteBufferDeserializerStep.class);
    }
    
    @Bean
    public static IStepMetaData createXmlByteBufferDeserializerStepMetaData() {
        return new StepMetaData().setName("XMLDeserializer").setType(XmlByteBufferDeserializerStep.class);
    }
    
    @Bean
    public static IStepMetaData createISOByteBufferSerializerStepMetaData() {
        return new StepMetaData().setName("ISOSerializer").setType(ISOByteBufferSerializerStep.class);
    }

    @Bean
    public static IStepMetaData createRoutingStepMetaData() {
        return new StepMetaData().setName("Routing").setType(RoutingStep.class);
    }
    
    @Bean
    public static IStepMetaData createJSONReaderStepMetaData() {
        return new StepMetaData().setName("JSONReader").setType(JSONReaderStep.class);
    }
    
    @Bean
    public static IStepMetaData createConfigMetaDataBuilderStepMetaData() {
        return new StepMetaData().setName("ConfigMetaDataBuilder").setType(ConfigMetaDataBuilderStep.class);
    }
    
    @Bean
    public static IStepMetaData XmlByteBufferSerializerStepMetaData() {
        return new StepMetaData().setName("XMLSerializer").setType(XmlByteBufferSerializerStep.class);
    }
    
    @Bean
    public static IStepMetaData createJSONByteBufferDeserializerStepMetaData(){
    	return new StepMetaData().setName("JSONDeserializer").setType(JSONByteBufferDeserializerStep.class);
    }
    
    @Bean
    public static IStepMetaData createJSONByteBufferSerializerMetaData(){
    	return new StepMetaData().setName("JSONSerializer").setType(JSONByteBufferSerializerStep.class);
    }
    
    @Bean
    public static IStepMetaData createRequestParamBufferDeserializerMetaData(){
    	return new StepMetaData().setName("httpRequestParamDeserializer").setType(HttpRequestParamDeserializerStep.class);
    }
    
    @Bean
    public static IStepMetaData createRequestParamBufferSerializerMetaData(){
    	return new StepMetaData().setName("httpRequestParamSerializer").setType(HttpRequestParamSerializerStep.class);
    }
    
    /*@Bean
    public static IStepMetaData createReadConfigurationStepMetaData() {
        return new StepMetaData().setName("ReadConfiguration").setType(ReadConfigurationStep.class);
    }*/
}

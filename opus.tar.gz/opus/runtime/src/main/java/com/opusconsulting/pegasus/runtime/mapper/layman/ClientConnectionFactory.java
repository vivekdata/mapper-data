package com.opusconsulting.pegasus.runtime.mapper.layman;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.opusconsulting.pegasus.common.channel.IChannel;

@Component
public class ClientConnectionFactory {
	
	private static Map<String,IChannel<?, ?>> clientChannelMap=new HashMap<>();
	
	public void register(String nodeName,IChannel<?, ?> tcpClientChannel){
		clientChannelMap.put(nodeName, tcpClientChannel);
	}
	
	public IChannel<?, ?> getClientChannel(String nodeName){
		return clientChannelMap.get(nodeName);
	}
}

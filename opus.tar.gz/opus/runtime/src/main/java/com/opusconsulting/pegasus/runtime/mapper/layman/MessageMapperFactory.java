package com.opusconsulting.pegasus.runtime.mapper.layman;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import com.opusconsulting.pegasus.runtime.IMessage;

@Component
public class MessageMapperFactory {

	@Lazy
	@Autowired
	List<IMessageMapping> mappingConfigurations;

	public IMessageMapping getMapping(String origin, String sourceMessageName, String target, String targetMessageName,
			IMessage originMessage) throws MappingNotFound {
		if (mappingConfigurations != null) {
			final Optional<IMessageMapping> mapping = mappingConfigurations.stream().filter(mappingConfig -> {
				return mappingConfig.getMetaData().getOrigin().equalsIgnoreCase(origin)
						&& mappingConfig.getMetaData().getOriginMessageName().equalsIgnoreCase(sourceMessageName)
						&& mappingConfig.getMetaData().getTarget().equalsIgnoreCase(target)
						&& mappingConfig.getMetaData().getTargetMessageName().equalsIgnoreCase(targetMessageName);
			}).map(mappingConfiguration -> {
				return mappingConfiguration;
			}).findFirst();

			if (mapping.isPresent()) {
				return mapping.get();
			} else {
				return null;
			}
		}
		return null;
	}
}

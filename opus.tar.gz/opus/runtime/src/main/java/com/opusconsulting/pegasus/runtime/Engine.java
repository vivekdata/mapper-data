package com.opusconsulting.pegasus.runtime;

import java.util.HashMap;
import java.util.Map;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.opusconsulting.pegasus.flow.IStepInstance;
import com.opusconsulting.pegasus.flow.IStepInstanceCreator;
import com.opusconsulting.pegasus.flow.impl.DefaultFlowContext;
import com.opusconsulting.pegasus.flow.metadata.StepInstanceInfo;
import com.opusconsulting.pegasus.runtime.mapper.layman.MessageKey;

public class Engine {
    

    public static void main(String[] args) {
        AnnotationConfigApplicationContext applicationContext = new AnnotationConfigApplicationContext();
        applicationContext.register(StepConfiguration.class);
        applicationContext.refresh();

        IStepInstanceCreator stepInstanceCreator = (IStepInstanceCreator) applicationContext.getBean("stepInstanceCreator");

        Map<String, Object> messageIdentificationProps = new HashMap<>();

        Map<String, ICondition> formulas = new HashMap<>();
        formulas.put("BIRequest", (message, ctx, params) -> {
            return message.getValue(new MessageKey("DE_0")).equals("0800");
        });
        formulas.put("BIResponse", (message, ctx, params) -> {
            return message.getValue(new MessageKey("DE_0")).equals("0810");
        });
        messageIdentificationProps.put("formulas", formulas);

        messageIdentificationProps.put("computeEvenIfExists", true);

        StepInstanceInfo stepInstanceInfo = new StepInstanceInfo()
                .setName("MessageIdentification")
                .setStepName("MessageIdentification")
                .setProperties(messageIdentificationProps);

        IStepInstance instance = stepInstanceCreator.create(stepInstanceInfo);
        DefaultFlowContext flowContext = new DefaultFlowContext(null, true);

        flowContext.put("REQUEST", new DefaultIMessage(null));
        instance.process(flowContext, null, null);
        System.out.println(flowContext.get("MESSAGE_NAME").toString());

        flowContext.put("REQUEST", new DefaultIMessage(null));
        instance.process(flowContext, null, null);
        System.out.println(flowContext.get("MESSAGE_NAME").toString());
    }
}

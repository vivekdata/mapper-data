package com.opusconsulting.pegasus.runtime.mapper;

public class ExcelFunctions {

}

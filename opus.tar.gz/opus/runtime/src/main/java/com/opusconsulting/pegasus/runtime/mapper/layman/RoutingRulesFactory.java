package com.opusconsulting.pegasus.runtime.mapper.layman;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

@Component
public class RoutingRulesFactory {
	//@Autowired(required=false)
	@Lazy
	@Autowired
	List<IRoutingRules> iRoutingList;
	
	public IRoutingRules getRules(String origin) {
		final Optional<IRoutingRules> rule = iRoutingList.stream().filter(ruleConfig -> {
			return ruleConfig.getOriginName().equalsIgnoreCase(origin);
		}).findFirst();
		if(rule.isPresent()){
			return rule.get();
		} else {
			return null;
		}
    }
}

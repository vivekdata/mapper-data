package com.opusconsulting.pegasus.runtime.formula;


import com.opusconsulting.pegasus.formula.codegen.GetterCode;
import com.opusconsulting.pegasus.formula.codegen.ICodeProvider;
import com.opusconsulting.pegasus.formula.codegen.SetterCode;

public class ISOMessageCodeProvider implements ICodeProvider {
	
	String objectName;
	
	public ISOMessageCodeProvider(String objectName) {
		super();
		this.objectName = objectName;
	}

	@Override
	public GetterCode getGetterCode(String[] names) {
		GetterCode getterCode = new GetterCode();
		if(names.length > 0) {
			getterCode.setCode(buildComplexGetterCode(names));
		} else {
			getterCode.setCode(objectName + ".getValue(new com.opusconsulting.pegasus.runtime.mapper.layman.MessageKey(\"" + names[0] + "\"))");
		}
        return getterCode;
	}

	private String buildComplexGetterCode(String[] names) {
		StringBuilder getterCodeBuilder = new StringBuilder();
		for (int index = 1; index < names.length; index++) {
			getterCodeBuilder.append("((com.opusconsulting.pegasus.runtime.DefaultIMessage)");
		}
		for (int index = 0; index < names.length; index++) {
			if (index == 0){
				getterCodeBuilder.append(objectName);
			}
			getterCodeBuilder.append(".getValue(new com.opusconsulting.pegasus.runtime.mapper.layman.MessageKey(\""
					+ names[index] + "\"))");
			if (index != names.length - 1)
				getterCodeBuilder.append(")");
		}
		return getterCodeBuilder.toString();
	}

	@Override
	public SetterCode getSetterCode(String[] names) {
		return null;
	}

}

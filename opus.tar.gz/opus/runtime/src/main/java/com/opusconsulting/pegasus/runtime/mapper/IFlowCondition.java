package com.opusconsulting.pegasus.runtime.mapper;

import com.opusconsulting.pegasus.flow.IFlowContext;

public interface IFlowCondition {
    Boolean check(IFlowContext ctx);
}

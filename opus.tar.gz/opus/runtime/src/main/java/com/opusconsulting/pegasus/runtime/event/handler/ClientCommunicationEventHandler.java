package com.opusconsulting.pegasus.runtime.event.handler;

import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.opusconsulting.pegasus.channel.http.HttpChannelConfig;
import com.opusconsulting.pegasus.channel.http.HttpChannelMessage;
import com.opusconsulting.pegasus.channel.http.HttpClientChannelFactory;
import com.opusconsulting.pegasus.channel.http.HttpDeleteClientChannel;
import com.opusconsulting.pegasus.channel.http.HttpGetClientChannel;
import com.opusconsulting.pegasus.channel.http.HttpPostClientChannel;
import com.opusconsulting.pegasus.channel.http.HttpPutClientChannel;
import com.opusconsulting.pegasus.channel.http.handler.HttpChannelHandler.HttpMethodType;
import com.opusconsulting.pegasus.channel.tcp.TCPChannelMessage;
import com.opusconsulting.pegasus.channel.tcp.TCPClientChannel;
import com.opusconsulting.pegasus.channel.tcp.TCPClientConfig;
import com.opusconsulting.pegasus.common.event.IEventContext;
import com.opusconsulting.pegasus.common.event.IEventHandler;
import com.opusconsulting.pegasus.common.event.IEventMessage;
import com.opusconsulting.pegasus.event.impl.EventContext;
import com.opusconsulting.pegasus.event.impl.EventMessage;
import com.opusconsulting.pegasus.format.iso.metadata.EndPointDetail;
import com.opusconsulting.pegasus.format.iso.metadata.EndPointType;
import com.opusconsulting.pegasus.format.iso.metadata.EndpointProtocol;
import com.opusconsulting.pegasus.format.iso.metadata.HttpEndPointDetail;
import com.opusconsulting.pegasus.format.iso.metadata.HttpEndPointDetail.EndPoint;
import com.opusconsulting.pegasus.runtime.IConstants;
import com.opusconsulting.pegasus.runtime.client.ClientConnector;
import com.opusconsulting.pegasus.runtime.mapper.layman.ClientConnectionFactory;

import io.vertx.core.buffer.Buffer;
import io.vertx.core.http.HttpMethod;

@Component
public class ClientCommunicationEventHandler implements IEventHandler {
	private static final Logger _logger = LoggerFactory.getLogger(ClientCommunicationEventHandler.class);
	private static final String EVENT_DATA_CLIENT_RESPONSE = "CLIENT_RESPONSE";
	public static final String SERIALIZED_BUFFER = "serialized_buffer";
	public static final String RESPONSE_BUFFER = "response_message_buffer";
	public static final String SEND_RECEIVE_EVT_DATA = "SEND_RECEIVE";
	public static final String CONNECT_EVT_DATA = "CONNECT";

	@Autowired
	Environment env;

	@Inject
	/*@Autowired(required=true)
	@Qualifier("sourceNode")*/
	String sourceNode; // TODO This may be the configuration value. However currently injecting for
						// demo purpose

	@Lazy
	@Autowired
	List<EndPointDetail> endpoints;

	@Autowired
	ClientConnectionFactory clientConnectionFactory;

	@Autowired
	HttpClientChannelFactory httpClientChannelFactory;
	
	@Autowired
	ClientConnector clientConnector;

	@Override
	public void handle(IEventMessage eventMessage, IEventContext context) {
		_logger.debug("Client activity event processing started. Reply: {}, Message Data: {}", eventMessage.isReply(),
				eventMessage.getData());
		if (CONNECT_EVT_DATA.equalsIgnoreCase(eventMessage.getData())) {
			boolean success = connectToClient(context);
			if (success) {
				replyToInitiator("CLIENT_CONNECTED", context, true);
			} else {
				replyToInitiator("CLIENT_CONNECTION_FAILED", context, false);
			}
		} else if (SEND_RECEIVE_EVT_DATA.equalsIgnoreCase(eventMessage.getData())) {
			// if(this.clientChannel != null){
			byte[] msgBuffer = context.get(SERIALIZED_BUFFER);
			System.out.println("Request to client: " + new String(msgBuffer));
			_logger.debug("Sending request to Client...");
			try {
				String destNode = context.get(IConstants.EVENT_CTX_DESTINATION_NODE_NAME_KEY);
				endpoints.stream().filter(endpoint -> {
					return endpoint.getNodeName().equalsIgnoreCase(destNode);
				}).forEach((endpoint -> {
					if (EndpointProtocol.TCP.equals(endpoint.getProtocol())) {
						try {
							sendRequestOnTCPChannel(context, msgBuffer);
						} catch (Exception e) {
							_logger.error("Error while sending the request message to the TCP client.", e);
						}
					} else if (EndpointProtocol.HTTP.equals(endpoint.getProtocol())) {
						try {
							sendRequestOnHTTPChannel(msgBuffer, context, endpoint);
						} catch (Exception e) {
							_logger.error("Error while sending the request message to the HTTP client.", e);
						}
					}
				}));
			} catch (Exception e) {
				_logger.error("Error while communicating with Client.", e);
				eventMessage.reply("FAILED - " + e.getMessage(), false);
			}
		}

	}

	private void sendRequestOnHTTPChannel(byte[] msgBuffer, IEventContext context, EndPointDetail endpoint) throws Exception {
		if (!endpoint.getClass().isAssignableFrom(HttpEndPointDetail.class)) {
			_logger.error(
					"Invalid endpoint details provided for the HTTP server start up. The endpoint should be of type HttpEndPointDetail.");

		}
		HttpEndPointDetail httpEndPoint = (HttpEndPointDetail) endpoint;
		Optional<EndPoint> messageEndPointDetailsOptional = httpEndPoint.getHttpEndPoints().stream()
				.filter(httpendpoint -> httpendpoint.getMessageName()
						.equalsIgnoreCase(context.get(IConstants.DESTINATION_MESSAGE_NAME)))
				.findFirst();
		if (messageEndPointDetailsOptional.isPresent()) {
			final HttpMethodType methodType = HttpMethodType.valueOf(messageEndPointDetailsOptional.get().getMethod());
			switch (methodType) {
			case GET:
				sendRequestOnHttpGetClientChannel(msgBuffer, context);
				break;

			case POST:
				sendRequestOnHTTPPostChannel(msgBuffer, context);
				break;

			case DELETE:
				sendRequestOnHttpDeleteClientChannel(msgBuffer, context);
				break;
				
			case PUT:
				sendRequestOnHttpPutClientChannel(msgBuffer, context);
				break;
				
			default:
				break;
			}
		} else {
			_logger.error(
					"No endpoint available for the identified destination message. Please check the configuration. Message Name: {}",
					(String) context.get(IConstants.DESTINATION_MESSAGE_NAME));
		}

	}

	private void sendRequestOnHttpPutClientChannel(byte[] msgBuffer, IEventContext context) {
		HttpPutClientChannel getClientChannel = (HttpPutClientChannel) clientConnectionFactory
				.getClientChannel(clientConnector.prepareHttpChannelRegisterKey(context.get(IConstants.EVENT_CTX_DESTINATION_NODE_NAME_KEY),
						context.get(IConstants.DESTINATION_MESSAGE_NAME)));

		getClientChannel.setEventHandler((type, message, additionalInfo) -> {
			EventContext replyContext = new EventContext();
			replyContext.set(RESPONSE_BUFFER, ((HttpChannelMessage) message).getData().getBytes());
			replyContext.set(IConstants.EVENT_CTX_SOURCE_NODE_NAME_KEY,
					context.get(IConstants.EVENT_CTX_DESTINATION_NODE_NAME_KEY));
			replyContext.set(IConstants.EVENT_CTX_DESTINATION_NODE_NAME_KEY, sourceNode);
			replyContext.set(ORI_REQUEST_CTX_KEY, context.get(ORI_REQUEST_CTX_KEY));
			_logger.debug("Response received from the Client.");
			replyToInitiator(EVENT_DATA_CLIENT_RESPONSE, replyContext, true);
			
		});
		try {
			getClientChannel.send(new HttpChannelMessage(Buffer.buffer(msgBuffer), context.get(IConstants.FLOW_PROPS_TRANSFORMED_MESSAGE_FIELDS), null), null);
			_logger.debug("Request message sent to Client successfully.");
		} catch (Exception e) {
			_logger.error("Request cannot be send to client... " + e.getMessage());
		}
	}
		
		
	

	private void sendRequestOnHttpGetClientChannel(byte[] msgBuffer, IEventContext context) {
		HttpGetClientChannel getClientChannel = (HttpGetClientChannel) clientConnectionFactory
				.getClientChannel(clientConnector.prepareHttpChannelRegisterKey(context.get(IConstants.EVENT_CTX_DESTINATION_NODE_NAME_KEY),
						context.get(IConstants.DESTINATION_MESSAGE_NAME)));

		getClientChannel.setEventHandler((type, message, additionalInfo) -> {
			EventContext replyContext = new EventContext();
			replyContext.set(RESPONSE_BUFFER, ((HttpChannelMessage) message).getData().getBytes());
			replyContext.set(IConstants.EVENT_CTX_SOURCE_NODE_NAME_KEY,
					context.get(IConstants.EVENT_CTX_DESTINATION_NODE_NAME_KEY));
			replyContext.set(IConstants.EVENT_CTX_DESTINATION_NODE_NAME_KEY, sourceNode);
			replyContext.set(ORI_REQUEST_CTX_KEY, context.get(ORI_REQUEST_CTX_KEY));
			_logger.debug("Response received from the Client.");
			replyToInitiator(EVENT_DATA_CLIENT_RESPONSE, replyContext, true);
			
		});
		try {
			getClientChannel.send(new HttpChannelMessage(null, context.get(IConstants.FLOW_PROPS_TRANSFORMED_MESSAGE_FIELDS), null), null);
			_logger.debug("Request message sent to Client successfully.");
		} catch (Exception e) {
			_logger.error("Request cannot be send to client... " + e.getMessage());
		}
	}
	
	private void sendRequestOnHttpDeleteClientChannel(byte[] msgBuffer, IEventContext context) {
		HttpDeleteClientChannel getClientChannel = (HttpDeleteClientChannel) clientConnectionFactory
				.getClientChannel(clientConnector.prepareHttpChannelRegisterKey(context.get(IConstants.EVENT_CTX_DESTINATION_NODE_NAME_KEY),
						context.get(IConstants.DESTINATION_MESSAGE_NAME)));

		getClientChannel.setEventHandler((type, message, additionalInfo) -> {
			EventContext replyContext = new EventContext();
			replyContext.set(RESPONSE_BUFFER, ((HttpChannelMessage) message).getData().getBytes());
			replyContext.set(IConstants.EVENT_CTX_SOURCE_NODE_NAME_KEY,
					context.get(IConstants.EVENT_CTX_DESTINATION_NODE_NAME_KEY));
			replyContext.set(IConstants.EVENT_CTX_DESTINATION_NODE_NAME_KEY, sourceNode);
			replyContext.set(ORI_REQUEST_CTX_KEY, context.get(ORI_REQUEST_CTX_KEY));
			_logger.debug("Response received from the Client.");
			replyToInitiator(EVENT_DATA_CLIENT_RESPONSE, replyContext, true);
		});
		try {
			getClientChannel.send(new HttpChannelMessage(null, context.get(IConstants.FLOW_PROPS_TRANSFORMED_MESSAGE_FIELDS), null), null);
			_logger.debug("Request message sent to Client successfully.");
		} catch (Exception e) {
			_logger.error("Request cannot be send to client... " + e.getMessage());
		}
	}

	private void sendRequestOnHTTPPostChannel(byte[] msgBuffer, IEventContext context) throws Exception {
		HttpPostClientChannel clientChannel = (HttpPostClientChannel) clientConnectionFactory
				.getClientChannel(clientConnector.prepareHttpChannelRegisterKey(context.get(IConstants.EVENT_CTX_DESTINATION_NODE_NAME_KEY),
						context.get(IConstants.DESTINATION_MESSAGE_NAME)));
		if(clientChannel == null) {
			_logger.error("No channel available with factory for {} " + clientConnector.prepareHttpChannelRegisterKey(context.get(IConstants.EVENT_CTX_DESTINATION_NODE_NAME_KEY),
					context.get(IConstants.DESTINATION_MESSAGE_NAME)));
			return;
		}
		clientChannel.setEventHandler((type, message, additionalInfo) -> {
			EventContext replyContext = new EventContext();
			replyContext.set(RESPONSE_BUFFER, ((HttpChannelMessage) message).getData().getBytes());
			replyContext.set(IConstants.EVENT_CTX_SOURCE_NODE_NAME_KEY,
					context.get(IConstants.EVENT_CTX_DESTINATION_NODE_NAME_KEY));
			replyContext.set(IConstants.EVENT_CTX_DESTINATION_NODE_NAME_KEY, sourceNode);
			replyContext.set(ORI_REQUEST_CTX_KEY, context.get(ORI_REQUEST_CTX_KEY));
			_logger.debug("Response From Client received: {}", ((HttpChannelMessage) message).getData());
			_logger.debug("Response received from the Client.");
			replyToInitiator(EVENT_DATA_CLIENT_RESPONSE, replyContext, true);
		});
		clientChannel.send(new HttpChannelMessage(Buffer.buffer(msgBuffer), null, null), null);
		_logger.debug("Request message sent to Client successfully.");
	}

	private void sendRequestOnTCPChannel(IEventContext context, byte[] msgBuffer) throws Exception {
		TCPClientChannel clientChannel = (TCPClientChannel) clientConnectionFactory
				.getClientChannel(context.get(IConstants.EVENT_CTX_DESTINATION_NODE_NAME_KEY));
		clientChannel.setEventHandler((type, message, additionalInfo) -> {
			EventContext replyContext = new EventContext();
			replyContext.set(RESPONSE_BUFFER, message.getData());
			replyContext.set(IConstants.EVENT_CTX_SOURCE_NODE_NAME_KEY,
					context.get(IConstants.EVENT_CTX_DESTINATION_NODE_NAME_KEY));
			replyContext.set(IConstants.EVENT_CTX_DESTINATION_NODE_NAME_KEY, sourceNode);
			replyContext.set(ORI_REQUEST_CTX_KEY, context.get(ORI_REQUEST_CTX_KEY));
			System.out.println("Response From Client receivevd:" + new String((byte[]) message.getData()));
			_logger.debug("Response received from the Client.");
			replyToInitiator(EVENT_DATA_CLIENT_RESPONSE, replyContext, true);
		});
		clientChannel.send(new TCPChannelMessage(msgBuffer, null, null), null);
		_logger.debug("Request message sent to Client successfully.");
	}

	public boolean connectToClient(IEventContext context) {
		endpoints.stream().filter(endpoint -> {
			return EndPointType.CLIENT.equals(endpoint.getType());
		}).forEach((endpoint -> {
			if (EndpointProtocol.TCP.equals(endpoint.getProtocol())) {
				clientConnector.connectToTCPClient(endpoint.getNodeName(), endpoint.getAddress(), endpoint.getPort());
			} else if (EndpointProtocol.HTTP.equals(endpoint.getProtocol())){
				clientConnector.connectToHttpClient(endpoint);
			}
		}));
		return true;
	}
	
	private void replyToInitiator(String eventMessage, IEventContext context, boolean success) {
		// IReplyEventContext replyEventContext = (IReplyEventContext) context;
		// IEventContext originalContext = replyEventContext.getOriginalContext();
		EventMessage originalMessage = context.get(ORI_REQUEST_CTX_KEY);
		if (originalMessage == null) {
			return;
		}
		EventContext replyContext = new EventContext();
		replyContext.set(IConstants.EVENT_CTX_SOURCE_NODE_NAME_KEY,
				context.get(IConstants.EVENT_CTX_SOURCE_NODE_NAME_KEY));
		replyContext.set(IConstants.EVENT_CTX_DESTINATION_NODE_NAME_KEY,
				context.get(IConstants.EVENT_CTX_DESTINATION_NODE_NAME_KEY));
		replyContext.set(RESPONSE_BUFFER, context.get(RESPONSE_BUFFER));
		originalMessage.reply(eventMessage, success, replyContext);
	}
	/*@Bean(name="sourceNode")
	public String getSourceNodeName(){//TODO need to think about this.
		 sourceNode = env.getProperty("cache.sourceNodeName");
		System.out.println("property value::::::::::sourceNodeName"+sourceNode);
		return sourceNode;
	}*/
}

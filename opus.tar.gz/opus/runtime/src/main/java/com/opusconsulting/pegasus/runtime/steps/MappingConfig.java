package com.opusconsulting.pegasus.runtime.steps;

import com.opusconsulting.pegasus.runtime.ICondition;
import com.opusconsulting.pegasus.runtime.IValueProvider;

import java.util.Map;

public class MappingConfig {
	String sourceNodeName;
	String sourceMessageName;
    String destinationName;
    String destinationMessageName;
    ICondition condition;
    Map<String, IValueProvider> fieldMapping; // Destination_Msg_Field, Formulae

    public MappingConfig(String destinationMessageName, ICondition condition) {
        this.destinationMessageName = destinationMessageName;
        this.condition = condition;
    }

    public String getDestinationName() {
        return destinationName;
    }

    public void setDestinationName(String destinationName) {
        this.destinationName = destinationName;
    }

    public String getDestinationMessageName() {
        return destinationMessageName;
    }

    public void setDestinationMessageName(String destinationMessageName) {
        this.destinationMessageName = destinationMessageName;
    }

    public ICondition getCondition() {
        return condition;
    }

    public void setCondition(ICondition condition) {
        this.condition = condition;
    }

    public Map<String, IValueProvider> getFieldMapping() {
        return fieldMapping;
    }

    public void setFieldMapping(Map<String, IValueProvider> fieldMapping) {
        this.fieldMapping = fieldMapping;
    }

	public String getSourceNodeName() {
		return sourceNodeName;
	}

	public void setSourceNodeName(String sourceNodeName) {
		this.sourceNodeName = sourceNodeName;
	}

	public String getSourceMessageName() {
		return sourceMessageName;
	}

	public void setSourceMessageName(String sourceMessageName) {
		this.sourceMessageName = sourceMessageName;
	}
    
    
}

package com.opusconsulting.pegasus.runtime.steps.iso;

import java.util.List;

import org.jpos.iso.ISOBasePackager;
import org.jpos.iso.ISOException;
import org.jpos.iso.ISOFieldPackager;
import org.jpos.iso.ISOMsg;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.opusconsulting.pegasus.common.resource.exception.ApplicationException;
import com.opusconsulting.pegasus.format.iso.metadata.ISOFieldMetaData;
import com.opusconsulting.pegasus.format.message.jpos.JPOSDataTypeFactory;
import com.opusconsulting.pegasus.runtime.DefaultIMessage;
import com.opusconsulting.pegasus.runtime.IMessage;
import com.opusconsulting.pegasus.runtime.mapper.layman.NodeMetaData;

public class ISOBufferParser implements ByteParser {
	private static final Logger _logger = LoggerFactory.getLogger(ISOBufferParser.class);
	private JPOSParserWithJSONConfig config;
	private List<ISOFieldMetaData> fieldDetails;
	
	public ISOBufferParser(List<ISOFieldMetaData> fieldDetails) {
		super();
		this.fieldDetails = fieldDetails;
		init(fieldDetails);
	}
	
	private void init(List<ISOFieldMetaData> fieldDetails) {
		this.config = new JPOSParserWithJSONConfig(fieldDetails);
	}

	/**
	 * Unpacks the bytebuf to IMessage
	 * @param input
	 * @return
	 * @throws ApplicationException 
	 */
	@Override
	public IMessage unpack(byte[] input) throws ApplicationException {
		if(this.config == null)
			return null;
		final ISOMsg msg = new ISOMsg();
		msg.setPackager(this.config);
		try {
			msg.unpack(input);
			return format(msg);
		} catch (ISOException e) {
			_logger.error("Error while unpacking the iso message bytes.", e);
			throw new ApplicationException("Error while unpacking the iso message bytes.", e);
		} catch (Exception exception){
			_logger.error("Error while unpacking the iso message bytes.", exception);
			throw new ApplicationException("Error while unpacking the iso message bytes.", exception);
		}
	}
	
	/**
	 * Pack the IMessage to bytebuf
	 * @param message
	 * @return
	 */
	@Override
	public byte[] pack(IMessage message) throws ApplicationException{
		if(this.config == null)
			return null;
		try {
			final ISOMsg msg = format(message);
			msg.setPackager(this.config);
			return msg.pack();
		} catch (ISOException e) {
			_logger.error("Error while packing the iso message bytes.", e);
			throw new ApplicationException("Error while packing the iso message bytes.", e);
		} catch (Exception exception){
			_logger.error("Error while packing the iso message bytes.", exception);
			throw new ApplicationException("Error while packing the iso message bytes.", exception);
		}
	}
	
	private DefaultIMessage format(final ISOMsg msg) throws ISOException{
		final DefaultIMessage message = new DefaultIMessage(new NodeMetaData(null));
		message.build(msg, this.fieldDetails);
		return message;
	}
	
	private ISOMsg format(final IMessage message) throws ISOException{
		return ((DefaultIMessage)message).format(this.fieldDetails);
	}

	@SuppressWarnings("unused")
	private class JPOSParserWithJSONConfig extends ISOBasePackager {

		public JPOSParserWithJSONConfig(List<ISOFieldMetaData> fieldDetails) {
			super();
			initializePackager(fieldDetails);
		}

		private void initializePackager(List<ISOFieldMetaData> fieldDetails) {
			final ISOFieldPackager jposfieldPackagers[] = new ISOFieldPackager[fieldDetails.size()];
			int iFieldIndex = 0;
			for (ISOFieldMetaData isoFields : fieldDetails) {
				if (iFieldIndex == 0) {
					jposfieldPackagers[iFieldIndex++] = JPOSDataTypeFactory.getMTIPackager(isoFields.getLength(), isoFields.getName());
					continue;
				} else if (iFieldIndex == 1) {
					jposfieldPackagers[iFieldIndex++] = JPOSDataTypeFactory
							.getBitMapPackager(isoFields.getName(), isoFields.getEncodingType(), isoFields.getLength());
					continue;
				}
				ISOFieldPackager fieldPackager = buildISOMessageFieldPackager(isoFields);
				if (fieldPackager != null)
					jposfieldPackagers[iFieldIndex++] = fieldPackager;
			}
			setFieldPackager(jposfieldPackagers);
		}

		private ISOFieldPackager buildISOMessageFieldPackager(ISOFieldMetaData isoFields) {
			return JPOSDataTypeFactory.getFieldPackager(isoFields.getName(), isoFields.getEncodingType(), isoFields.getPrefixEncodingType(),
					isoFields.getType(), isoFields.getLength(), isoFields.getSizeType());
		}
	}
}
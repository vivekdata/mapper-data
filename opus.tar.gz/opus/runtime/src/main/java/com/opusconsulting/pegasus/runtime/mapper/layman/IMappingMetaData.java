package com.opusconsulting.pegasus.runtime.mapper.layman;

public interface IMappingMetaData {
	String getOrigin();
	
	String getTarget();
	
	String getOriginMessageName();
	
	String getTargetMessageName();
}

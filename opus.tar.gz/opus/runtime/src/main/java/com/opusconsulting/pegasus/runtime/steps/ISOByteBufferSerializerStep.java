package com.opusconsulting.pegasus.runtime.steps;

import java.util.Map;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.opusconsulting.pegasus.common.resource.exception.ApplicationException;
import com.opusconsulting.pegasus.flow.IFlowContext;
import com.opusconsulting.pegasus.flow.impl.AbstractStepInstance;
import com.opusconsulting.pegasus.format.iso.metadata.ISONodeDetail;
import com.opusconsulting.pegasus.runtime.IConstants;
import com.opusconsulting.pegasus.runtime.IMessage;
import com.opusconsulting.pegasus.runtime.steps.iso.ByteParser;
import com.opusconsulting.pegasus.runtime.steps.iso.ISOBufferParser;

public class ISOByteBufferSerializerStep extends AbstractStepInstance {
	private static final Logger _logger = LoggerFactory.getLogger(ISOByteBufferSerializerStep.class);
	private ISONodeDetail nodeDetail;
	private ByteParser parser;
	
	@PostConstruct
	void init() {
		this.parser = new ISOBufferParser(nodeDetail.getFieldDetails());
	}
	
	@Override
	public <I, R> R process(IFlowContext context, I previousStepResult, Map<String, Object> flowProps) {
		final IMessage message = (IMessage) flowProps.get(IConstants.FLOW_PROPS_TRANSFORMED_REQUEST_KEY);
		if(message == null){
			_logger.error("No message received to serialize from the flow properties of the step.");
			return (R) message;
		}
		if(this.parser == null){
			_logger.error("No message serializer available to serialize.");
			return (R) message;
		}
		final String nodeName = (String) flowProps.get(IConstants.FLOW_PROPS_NODE_NAME_KEY);
		
		try {
			return (R) this.parser.pack((IMessage) message);
		} catch (ApplicationException e) {
			_logger.error(e.getMessage(), e);
			onError(context, null, flowProps, e);
			return null;
		}
	}

	public void setNodeDetail(ISONodeDetail nodeDetail) {
		this.nodeDetail = nodeDetail;
	}
}

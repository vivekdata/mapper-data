package com.opusconsulting.pegasus.runtime;

import com.opusconsulting.pegasus.common.event.IEventPublisher;
import com.opusconsulting.pegasus.event.impl.*;
import com.opusconsulting.pegasus.runtime.event.RuntimeEventSubjects;
import com.opusconsulting.pegasus.runtime.event.handler.EnvStartupActivityEventHandler;
import com.opusconsulting.pegasus.runtime.scheduler.ScheduleExecutorInitializer;
import io.vertx.core.Vertx;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.*;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;

import javax.annotation.PreDestroy;
import java.util.Arrays;

@Configuration
@Import({StepConfiguration.class, EventHandlerConfiguration.class})

@SpringBootApplication
public class RuntimeMain {

	private static final Logger _logger = LoggerFactory.getLogger(Runtime.class);


	static EnvStartupActivityEventHandler envStartupActivityEventHandler;

	static EventManager eventManager;//TODO need to think about this static.

	private static ApplicationContext applicationContext;

	@Bean
	public Vertx getVertx(){
		return Vertx.vertx();
	}

	protected static ApplicationContext getApplicationContext() {
		return applicationContext;
	}

	public static void initEventManager() {
		eventManager = applicationContext.getBean(EventManager.class);
		EventConfig config = new ThreadBasedEventConfig("SPECIAL", EventUseType.UseBoth);
		Arrays.asList(RuntimeEventSubjects.values()).stream().forEach(eventSubject -> {
			config.addSubject(eventSubject.name());
		});
		eventManager.addConfig(config);
		eventManager.init();
	}

	@PreDestroy
	public void shutDown() {
		// shutdown application context
	}

	public static void main(String[] args) {
		applicationContext  = SpringApplication.run(RuntimeMain.class, args);
		_logger.info("****************** Boot-Up ************************");
		_logger.info("Booting up the process...");

		initEventManager();

		EventContext eventContext = new EventContext();
		eventContext.set("nodeJSONFilePath", applicationContext.getBean("nodeJSONFilePath"));
		eventContext.set("workFlowJSONFilePath", applicationContext.getBean("workFlowJSONFilePath"));
		eventContext.set("virtulizationJSONFilePath", applicationContext.getBean("virtulizationJSONFilePath"));
		//envStartupActivityEventHandler=applicationContext.getBean(EnvStartupActivityEventHandler.class);
		//envStartupActivityEventHandler.handle(null, null);
		try {
			((IEventPublisher)applicationContext.getBean("envStartupActivityEventPublisher")).publish("BOOT", eventContext);
			((ScheduleExecutorInitializer) applicationContext.getBean("scheduleExecutorInitializer")).initializeNodeScheduler((String)applicationContext.getBean("nodeNames"));
		} catch (BeansException e) {
			System.exit(0);
		}

	}

}

package com.opusconsulting.pegasus.runtime;

import java.io.Serializable;

import com.opusconsulting.pegasus.runtime.mapper.layman.IKey;
import com.opusconsulting.pegasus.runtime.mapper.layman.IMessageMetaData;
import com.opusconsulting.pegasus.runtime.mapper.layman.INodeMetaData;

public interface IMessage extends Serializable {
    IMessageMetaData getMetaData();

    INodeMetaData getNodeMetaData();

    void setMetaData(IMessageMetaData metaData);

    <T> T getValue(IKey key);

	<T> void setValue(IKey key, T value);
}

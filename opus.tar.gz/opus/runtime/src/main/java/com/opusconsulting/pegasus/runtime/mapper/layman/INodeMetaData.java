package com.opusconsulting.pegasus.runtime.mapper.layman;

public interface INodeMetaData {
    String getName();

	void setName(String name);
}

package com.opusconsulting.pegasus.runtime.mapper;

import com.opusconsulting.pegasus.formula.codegen.CodeMetaData;
import com.opusconsulting.pegasus.formula.codegen.FormulaCodeInfo;
import com.opusconsulting.pegasus.formula.codegen.FunctionMetaData;
import com.opusconsulting.pegasus.formula.codegen.GetterCode;
import com.opusconsulting.pegasus.formula.codegen.ICodeProvider;
import com.opusconsulting.pegasus.formula.codegen.ParamMetaData;
import com.opusconsulting.pegasus.formula.codegen.SetterCode;
import com.opusconsulting.pegasus.formula.codegen.impl.FormulaCodeGenerator;
import com.opusconsulting.pegasus.formula.compiler.JavaCodeCompiler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Arrays;

@Component
public class FlowConditionGenerator {

    @Autowired
    FormulaCodeGenerator codeGenerator;

    @Autowired
    JavaCodeCompiler compiler;

    public IFlowCondition getCondition(String excel) throws Exception {
        CodeMetaData codeMetaData = new CodeMetaData();
        codeMetaData.setPackageName("com.opusconsulting.pegasus.runtime.gen.condition");
        codeMetaData.addImport(IFlowCondition.class.getCanonicalName());
        codeMetaData.addImport("static " + ExcelFunctions.class.getCanonicalName() + ".*");
        codeMetaData.setImplementClasses(Arrays.asList(IFlowCondition.class.getSimpleName()));

        FunctionMetaData functionMetaData = new FunctionMetaData();
        functionMetaData.setName("check");
        functionMetaData.setReturnType("Boolean");
        functionMetaData.setParams(Arrays.asList(new ParamMetaData("ctx", "IFlowContext")));
        codeMetaData.setCallFunctionMetaData(functionMetaData);
        FormulaCodeInfo formulaCodeInfo = codeGenerator.create(excel, codeMetaData, new FlowConditionCodeProvider("ctx"));

        Class<Object> flowConditionClass = compiler.compile(formulaCodeInfo.getClassName(), formulaCodeInfo.getCode());
        return (IFlowCondition) flowConditionClass.newInstance();
    }


    public class FlowConditionCodeProvider implements ICodeProvider {

        String objectName;

        public FlowConditionCodeProvider(String objectName) {
            this.objectName = objectName;
        }

        @Override
        public GetterCode getGetterCode(String[] names) {
            GetterCode getterCode = new GetterCode();
            getterCode.setCode(objectName);
            return getterCode;
        }

        @Override
        public SetterCode getSetterCode(String[] names) {
            // TODO not supported
            return null;
        }
    }

}

package com.opusconsulting.pegasus.runtime.event;

public enum RuntimeEventSubjects {
	ENVIRONMENT_BOOT, ENV_STARTUP_ACTIVITY, PROCESS, CLIENT_ACTIVITY , HEARTBEAT;
}

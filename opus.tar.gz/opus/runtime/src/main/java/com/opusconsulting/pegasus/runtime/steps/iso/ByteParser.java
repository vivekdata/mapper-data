package com.opusconsulting.pegasus.runtime.steps.iso;

import com.opusconsulting.pegasus.common.resource.exception.ApplicationException;
import com.opusconsulting.pegasus.runtime.IMessage;

public interface ByteParser {
	IMessage unpack(byte[] input) throws ApplicationException;
	byte[] pack(IMessage message) throws ApplicationException;
}

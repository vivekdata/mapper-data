package com.opusconsulting.pegasus.runtime.steps;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.opusconsulting.pegasus.channel.http.HttpChannelUtility;
import com.opusconsulting.pegasus.flow.IFlowContext;
import com.opusconsulting.pegasus.flow.impl.AbstractStepInstance;
import com.opusconsulting.pegasus.format.iso.metadata.MessageDetail;
import com.opusconsulting.pegasus.format.iso.metadata.MessageFieldDetail;
import com.opusconsulting.pegasus.format.iso.metadata.NodeDetail;
import com.opusconsulting.pegasus.format.iso.metadata.NodeEndPoint;
import com.opusconsulting.pegasus.format.iso.metadata.NodeEndPointDetails;
import com.opusconsulting.pegasus.runtime.IConstants;
import com.opusconsulting.pegasus.runtime.IMessage;
import com.opusconsulting.pegasus.runtime.mapper.layman.IMessageIdentifier;
import com.opusconsulting.pegasus.runtime.mapper.layman.IMessageMetaDataImpl;
import com.opusconsulting.pegasus.runtime.mapper.layman.MessageKey;

import ch.qos.logback.core.net.SyslogOutputStream;

public class HttpRequestParamSerializerStep extends AbstractStepInstance {
	private static final Logger _logger = LoggerFactory.getLogger(HttpRequestParamSerializerStep.class);

	private NodeDetail<MessageDetail> nodeDetail;

	@Override
	public <I, R> R process(IFlowContext context, I previousStepResult, Map<String, Object> flowProps) {
		boolean value = flowProps.containsKey(IConstants.IS_REQUEST_PARAM_DESERIALIZE_SERIALIZE_REQUIRED)
				? (boolean) flowProps.get(IConstants.IS_REQUEST_PARAM_DESERIALIZE_SERIALIZE_REQUIRED)
				: false;
		if (value) {
			final IMessage message = (IMessage) flowProps.get(IConstants.FLOW_PROPS_TRANSFORMED_REQUEST_KEY);
			if (message == null) {
				_logger.error("No message received to serialize from the flow properties of the step.");
				return (R) message;
			}
			List<String> requestParams = getRequestParams(message, flowProps);
			Map<String, Object> messageFieldMap = loadMessageFieldsToFlowProps(message, requestParams);
			flowProps.put(IConstants.FLOW_PROPS_TRANSFORMED_MESSAGE_FIELDS, messageFieldMap);
		}
		return (R) previousStepResult;
	}

	private List<String> getRequestParams(IMessage message, Map<String, Object> flowProps) {
		String messageName = message.getMetaData().getName();
		String nodeName = (String) flowProps.get(IConstants.FLOW_PROPS_NODE_NAME_KEY);

		List<NodeEndPoint> endpointList = nodeDetail.getEndpoints();

		for (NodeEndPoint nodeEndPoint : endpointList) {
			NodeEndPointDetails nodeEndPointDetails = (NodeEndPointDetails) nodeEndPoint;
			if (nodeEndPointDetails.getMessageName().equalsIgnoreCase(messageName)
					&& nodeDetail.getName().equalsIgnoreCase(nodeName)) {
				return HttpChannelUtility.identifyAndNoteRequestParams(nodeEndPointDetails.getUrl());
			}
		}
		return null;
	}

	private Map<String, Object> loadMessageFieldsToFlowProps(final IMessage message, List<String> requestParams) {
		if(requestParams!=null) {
			Map<String, Object> messageFieldMap = new HashMap<String, Object>();
			
			for (MessageDetail messageDetail : nodeDetail.getMessages()) {
				List<MessageFieldDetail> messageFields = messageDetail.getMessageFields();
				for (MessageFieldDetail messageFieldDetail : messageFields) {
					String fieldName = messageFieldDetail.getField().getName();
					if (message.getValue(new MessageKey(fieldName)) != null && requestParams.contains(fieldName)) {
						messageFieldMap.put(fieldName, message.getValue(new MessageKey(fieldName)));
					}
				}
			}
			return messageFieldMap;
		}
		return null;
		
	}

	public void setNodeDetail(NodeDetail<MessageDetail> nodeDetail) {
		this.nodeDetail = nodeDetail;
	}

}

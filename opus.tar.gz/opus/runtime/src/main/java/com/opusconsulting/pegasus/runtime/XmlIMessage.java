package com.opusconsulting.pegasus.runtime;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.opusconsulting.pegasus.runtime.mapper.layman.IKey;
import com.opusconsulting.pegasus.runtime.mapper.layman.IMessageMetaData;
import com.opusconsulting.pegasus.runtime.mapper.layman.INodeMetaData;

public class XmlIMessage implements IMessage {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1154083081599656903L;
	INodeMetaData nodeMeataData;
	IMessageMetaData messageMetaData;
	
	String elementName;
	Object elementValue;
	Map<String, Object> attributes;
	List<XmlIMessage> children;
	XmlIMessage parent;
	
	public XmlIMessage(INodeMetaData nodeMeataData, String elementName, Object elementValue) {
		super();
		this.nodeMeataData = nodeMeataData;
		this.elementName = elementName;
		this.elementValue = elementValue;
	}

	@Override
	public IMessageMetaData getMetaData() {
		return this.messageMetaData;
	}

	@Override
	public INodeMetaData getNodeMetaData() {
		return this.nodeMeataData;
	}

	@Override
	public void setMetaData(IMessageMetaData metaData) {
		this.messageMetaData = metaData;
	}

	@Override
	public <T> T getValue(IKey key) {
		return (T) this.elementValue;
//		return (T) getFieldValue(this, key);
	}
	
	private static Object getFieldValue(XmlIMessage message, IKey key) {
		if (message == null)
			return null;
		if(message.getElementName().equalsIgnoreCase(key.getValue())){
			return message.getElementValue();
		} else {
			Optional<XmlIMessage> optionalXmlMessage = null;
			if(message.getChildren().stream().noneMatch((xmlChildMesg) -> {
				return xmlChildMesg.getElementName().equalsIgnoreCase(key.getValue());
			})){
				optionalXmlMessage = message.getChildren().stream().findFirst();
			} else {
				optionalXmlMessage = message.getChildren().stream().filter((xmlChildMesg) -> {
					return xmlChildMesg.getElementName().equalsIgnoreCase(key.getValue());
				}).findFirst();
			}
			
			if (optionalXmlMessage != null && optionalXmlMessage.isPresent()) {
				return getFieldValue(optionalXmlMessage.get(), key);
			} else {
				return null;
			}
		}
	}
	
	
	
	@Override
	public <T> void setValue(IKey key, T value) {
		this.elementValue = value;
	}

	public String getElementName() {
		return elementName;
	}

	public void setElementName(String elementName) {
		this.elementName = elementName;
	}

	public Object getElementValue() {
		return elementValue;
	}
	
	public void addChildren(XmlIMessage xmlMessage){
		if(this.children == null){
			this.children = new ArrayList<>();
		}
		this.children.add(xmlMessage);
		xmlMessage.setParent(this);
	}
	
	public void addAttribute(String attributeName, Object value){
		if(this.attributes == null){
			this.attributes = new HashMap<String, Object>();
		}
		this.attributes.put(attributeName, value);
	}

	public XmlIMessage getParent() {
		return parent;
	}

	public void setParent(XmlIMessage parent) {
		this.parent = parent;
	}

	public List<XmlIMessage> getChildren() {
		return children;
	}
	
	public Object getAttrribute(String attributeName){
		if(this.attributes == null){
			return null;
		}
		return this.attributes.get(attributeName);
	}

	public Map<String, Object> getAttributes() {
		return attributes;
	}

}

package com.opusconsulting.pegasus.runtime.steps;

import com.opusconsulting.pegasus.runtime.ICondition;

/**
 * 
 * @author sachin.deshmukh
 *
 */
public class RoutingRule {
	private String destinationNode;
	private ICondition condition; // Rule source code
	
	public String getDestinationNode() {
		return destinationNode;
	}
	public void setDestinationNode(String destinationNode) {
		this.destinationNode = destinationNode;
	}
	public ICondition getCondition() {
		return condition;
	}
	public void setCondition(ICondition condition) {
		this.condition = condition;
	}
}

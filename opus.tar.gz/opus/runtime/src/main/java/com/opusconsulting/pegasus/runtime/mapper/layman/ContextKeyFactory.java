package com.opusconsulting.pegasus.runtime.mapper.layman;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

@Component
//@PropertySource("file:${application.properties.path}")
public class ContextKeyFactory {
	private static final Map<String, List<IKey>> KEYS = new HashMap<>();
	
	@Value("${node.names}")
	String[] nodes;
	
	@Autowired
	Environment env;
	
	
	public void register(String key) {
		final String contextFields = env.getProperty("node." + key + ".contextfields");
		if (contextFields != null)
			KEYS.put(key, buildKeyList(contextFields.split(",")));

	}

	private List<IKey> buildKeyList(String[] keys) {
		List<IKey> ikeys = new ArrayList<>();
		for (String key : keys) {
			ikeys.add(new MessageKey(key));
		}
		return ikeys;
	}

	public static List<IKey> getKey(String origin) {
		return KEYS.get(origin);
	}
}

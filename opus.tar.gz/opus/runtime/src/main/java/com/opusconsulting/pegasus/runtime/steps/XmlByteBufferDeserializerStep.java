package com.opusconsulting.pegasus.runtime.steps;

import java.util.Map;
import java.util.Optional;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.opusconsulting.pegasus.common.resource.exception.ApplicationException;
import com.opusconsulting.pegasus.flow.IFlowContext;
import com.opusconsulting.pegasus.flow.impl.AbstractStepInstance;
import com.opusconsulting.pegasus.format.iso.metadata.NodeDetail;
import com.opusconsulting.pegasus.format.iso.metadata.XmlMessageDetails;
import com.opusconsulting.pegasus.format.iso.metadata.XmlNodeDetail;
import com.opusconsulting.pegasus.runtime.DefaultIMessage;
import com.opusconsulting.pegasus.runtime.IConstants;
import com.opusconsulting.pegasus.runtime.IMessage;
import com.opusconsulting.pegasus.runtime.XmlIMessage;
import com.opusconsulting.pegasus.runtime.mapper.layman.IMessageIdentifier;
import com.opusconsulting.pegasus.runtime.mapper.layman.IMessageMetaData;
import com.opusconsulting.pegasus.runtime.mapper.layman.MessageIdentifierFactory;
import com.opusconsulting.pegasus.runtime.mapper.layman.NodeMetaData;
import com.opusconsulting.pegasus.runtime.mapper.layman.UnknownMessageType;
import com.opusconsulting.pegasus.runtime.steps.iso.ByteParser;
import com.opusconsulting.pegasus.runtime.steps.iso.XmlByteParser;

public class XmlByteBufferDeserializerStep extends AbstractStepInstance {
	private static final Logger _logger = LoggerFactory.getLogger(XmlByteBufferDeserializerStep.class);
	private ByteParser parser;
	
	@Autowired
	MessageIdentifierFactory messageIdentifierFactory;
	
	NodeDetail nodeDetail;
	
	@PostConstruct
	public void init(){
		try {
			this.parser = new XmlByteParser();
		} catch (ApplicationException e) {
			_logger.error("Error while initializing the XML meesage deserializer.", e);
		}
	}
	
	
	@Override
	public <I, R> R process(IFlowContext context, I previousStepResult, Map<String, Object> flowProps) {
		byte[] messageBytes = (byte[]) flowProps.get(IConstants.FLOW_PROPS_MESSAGE_BUFFER_KEY);

		if (messageBytes == null) {
			_logger.error("No message byte received to the step execution in the Flow properties. It might possible that server receives the HTTP GET/DELETE.");
			return null;
		}

		if (this.parser == null || flowProps.get("nodeName") == null) {
			_logger.error(
					"No necessary artefacts are available to complete the message byte deserialization step. No parser or Nodename.");
			return (R) messageBytes;
		}
		IMessage message = null;
		try {
			message = this.parser.unpack((byte[]) messageBytes);
		} catch (ApplicationException e) {
			_logger.error(e.getMessage(), e);
			onError(context, null, flowProps, e);
			return (R) message;
		}

		try {
			return (R) processPostDeseriaze(message, (String) flowProps.get("nodeName"));
		} catch (UnknownMessageType unknownMessageType) {
			_logger.error("Error occured while processing post deserialize the message.", unknownMessageType);
			onError(context, previousStepResult, flowProps, unknownMessageType);
			return null;
		}
	}
	
	private IMessage processPostDeseriaze(IMessage message, String origin) throws UnknownMessageType {
		findAndSetMessageType(origin, message);
		return convertTreeXmlIMessageToInternalIMessage(message, nodeDetail);	
	}

	private void findAndSetMessageType(String origin, IMessage message) throws UnknownMessageType {
		IMessageIdentifier messageIdentifier = messageIdentifierFactory.getIdentifier(origin);
		IMessageMetaData metaData = messageIdentifier.identify(message);
		if (metaData == null) {
			_logger.error("No meta data identified for this message bytes. throwing Unknown message exception.");
			throw new UnknownMessageType();
		}
		_logger.debug("Message meta dataa identified successfully. Message name: {}, Request: {}", metaData.getName(), metaData.isRequest());
		message.setMetaData(metaData);
	}
	
	private IMessage convertTreeXmlIMessageToInternalIMessage(final IMessage message, NodeDetail nodeDetail) {
		_logger.debug("Parsed tree structured XML message formatting to internal message started...");
		if(!(nodeDetail instanceof XmlNodeDetail)){
			_logger.error(
					"Provided node details configuration is not of expected Type Expected: {}, Actual: {}, for XML tree to internal formatting.",
					XmlNodeDetail.class.getCanonicalName(), nodeDetail.getClass().getCanonicalName());
			return null;
		}
		final String nodeName = nodeDetail.getName();
		
		Optional<XmlMessageDetails> messageDetailOptinal = ((XmlNodeDetail)nodeDetail).getMessages().stream().filter((messageDetail) -> {
			return messageDetail.getName().equalsIgnoreCase(message.getMetaData().getName());
		}).findFirst();
		
		if(messageDetailOptinal.isPresent()){
			final XmlMessageDetails messageDetail = messageDetailOptinal.get();
			// TODO NodeMetaData to be injected
			final IMessage internalMessage = new DefaultIMessage(new NodeMetaData(nodeName));
			internalMessage.setMetaData(message.getMetaData());
			((DefaultIMessage)internalMessage).build(messageDetail.getMessageFields(), (XmlIMessage)message);
			_logger.debug("Parsed tree structured XML message formatting to internal message completed.");
			return internalMessage;
		} else {
			_logger.error("No message configuration found for the identified message. Node Name: {},  Message name: {}", nodeName, message.getMetaData().getName());
			return null;
		}
	}

	public void setNodeDetail(NodeDetail nodeDetail) {
		this.nodeDetail = nodeDetail;
	}
	
}

package com.opusconsulting.pegasus.runtime.formula.util;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.opusconsulting.pegasus.format.iso.metadata.MappingFieldDetails;
import com.opusconsulting.pegasus.formula.codegen.CodeMetaData;
import com.opusconsulting.pegasus.formula.codegen.FormulaCodeInfo;
import com.opusconsulting.pegasus.formula.codegen.FunctionMetaData;
import com.opusconsulting.pegasus.formula.codegen.ICodeProvider;
import com.opusconsulting.pegasus.formula.codegen.ParamMetaData;
import com.opusconsulting.pegasus.formula.codegen.impl.FormulaCodeGenerator;
import com.opusconsulting.pegasus.formula.compiler.JavaCodeCompiler;
import com.opusconsulting.pegasus.runtime.IValueProvider;

@Component
public class IValueProviderUtility {
	@Inject
	JavaCodeCompiler compiler;
	
	@Inject
	FormulaCodeGenerator codeGenerator;
	
	private static final Logger _logger = LoggerFactory.getLogger(IValueProviderUtility.class);
	
	public Map<String, IValueProvider> buildMessageMappingDetails(List<MappingFieldDetails> messageMappingDetails,
			ICodeProvider codeProvider) {
		final Map<String, IValueProvider> formulaValueProviders = new HashMap<>();
		messageMappingDetails.stream().forEach(mappingDetail -> {
			try {
				IValueProvider iValueProviderObj = buildValueProvider(mappingDetail.getMappingFormula(),
						codeProvider);
				if (iValueProviderObj != null)
					formulaValueProviders.put(mappingDetail.getDestinationFieldName(), iValueProviderObj);
			} catch (Exception e) {
				_logger.error("Failed to create message mapping formula classes ", e);
			}
		});
		return formulaValueProviders;
	}
	
	public IValueProvider buildValueProvider(String formula, ICodeProvider codeProvider) throws Exception {
		CodeMetaData codeMetaData = new CodeMetaData();
		codeMetaData.setPackageName("com.opusconsulting.pegasus.formula");
		codeMetaData.addImport("com.opusconsulting.pegasus.runtime.IValueProvider");
		codeMetaData.addImport("static com.opusconsulting.pegasus.runtime.formula.ExcelFunctions.*");
		codeMetaData.addImport("com.opusconsulting.pegasus.runtime.IMessage");
		codeMetaData.addImport("java.util.Map");
		codeMetaData.addImport("com.opusconsulting.pegasus.flow.IFlowContext");
		codeMetaData.setImplementClasses(Arrays.asList("IValueProvider"));

		FunctionMetaData functionMetaData = new FunctionMetaData();
		functionMetaData.setName("get");
		functionMetaData.setReturnType("T");
		functionMetaData.setParams(Arrays.asList(new ParamMetaData("request", "IMessage"),
				new ParamMetaData("ctx", "IFlowContext"), new ParamMetaData("params", "Map<String, Object>")));
		codeMetaData.setCallFunctionMetaData(functionMetaData);
		if (formula == null)
			return null;

		FormulaCodeInfo formulaCodeInfo = codeGenerator.create(formula, codeMetaData,
				codeProvider);

		Class<Object> valueProviderClass = compiler.compile(formulaCodeInfo.getClassName(), formulaCodeInfo.getCode());
		return (IValueProvider) valueProviderClass.newInstance();
	}
}

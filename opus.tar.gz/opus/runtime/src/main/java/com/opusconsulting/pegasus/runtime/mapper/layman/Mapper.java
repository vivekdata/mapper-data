package com.opusconsulting.pegasus.runtime.mapper.layman;

import java.util.List;

import com.opusconsulting.pegasus.runtime.IMessage;

public class Mapper {

    IMessage process(String origin, IMessage message) {
        if (processIncomingMessage(origin, message) == false) {
            return null;
        }
        
		if (isRequest(message)) {
			// add request to cache or pull from cache if request
			try {
				addToRequestCache(origin, message);
			} catch (CacheAlreadyExists cacheAlreadyExists) {
				handleDuplicateRequestCache(message);
				return null;
			}
			// check routing rules
			MatchingDetail match = null;
			try {
				match = routing(origin, message);
			} catch (RoutingDestinationNotFound routingDestinationNotFound) {
				handleRoutingDestinationNotFound(origin, message);
				return null;
			}
			return processOutgoingMessage(origin, message, match.getNodeName(), match.getMessageName());
		} else {
			IMessage targetRequestMessage = null;
			try {
				targetRequestMessage = pullRequestFromCache(origin, message);
			} catch (CacheNotFound cacheNotFound) {
				handleCacheNotFound(message);
				return null;
			}
			return processOutgoingMessage(origin, message, targetRequestMessage.getNodeMetaData().getName(),
					message.getMetaData().getName());
		}
    }

    boolean processIncomingMessage(String origin, IMessage message) {
        // find message type and set
        if (!isMessageTypeKnown(message)) {
            try {
                findAndSetMessageType(origin, message);
            } catch (UnknownMessageType unknownMessageType) {
                handleUnknownMessageType(message);
                return false;
            }
        }
        return true;
    }

    MatchingDetail routing(String origin, IMessage message) throws RoutingDestinationNotFound {
        IRoutingRules rules = new RoutingRulesFactory().getRules(origin);
        MatchingDetail match = rules.match(message);
        if (match == null) {
            throw new RoutingDestinationNotFound();
        }

        return match;
    }

    IMessage processOutgoingMessage(String origin, IMessage message, String target, String targetMessageName) {
        IMessage targetMessage = createNewMessage(target, targetMessageName);

        // add request to cache or pull from cache if request
        if (isRequest(targetMessage)) {
            try {
                addToRequestCache(target, targetMessage);
            } catch (CacheAlreadyExists cacheAlreadyExists) {
                handleDuplicateRequestCache(message);
                return message;
            }
        }

        try {
            mapFields(origin, message, target, targetMessageName, targetMessage);
        } catch (MappingNotFound mappingNotFound) {
            handleTargetMappingNotFound(origin, message, target, targetMessageName);
            return null;
        } catch (CacheNotFound cacheNotFound) {
            handleCacheNotFound(message);
            return null;
        }

        return targetMessage;
    }

    private void mapFields(String origin, IMessage originMessage, String target, String targetMessageName, IMessage targetMessage)
            throws MappingNotFound, CacheNotFound {
        String sourceMessageName = originMessage.getNodeMetaData().getName();
        IMessageMapping mapping = new MessageMapperFactory().getMapping(origin, sourceMessageName, target, targetMessageName, originMessage);

        IMessage targetRequestMessage = null;
        if (!isRequest(targetMessage)) {
            List<IKey> contextFields = getContextFields(target, targetMessage);
            mapping.map(originMessage, targetMessage, contextFields);
            targetRequestMessage = pullRequestFromCache(target, targetMessage);
        }

        mapping.map(originMessage, targetMessage, targetRequestMessage);
    }

    private void findAndSetMessageType(String origin, IMessage message) throws UnknownMessageType {
        IMessageIdentifier messageIdentifier = new MessageIdentifierFactory().getIdentifier(origin);
        IMessageMetaData metaData = messageIdentifier.identify(message);
        if (metaData == null) {
            throw new UnknownMessageType();
        }

        message.setMetaData(metaData);
    }

    private boolean isRequest(IMessage message) {
        IMessageMetaData metaData = message.getMetaData();
        return (metaData == null || metaData.isRequest());
    }

    private boolean isMessageTypeKnown(IMessage message) {
        return message.getMetaData() != null;
    }


    private String getCacheKey(IMessage targetMessage, List<IKey> contextFields) {
        String key = "";
        for (IKey contextField : contextFields) {
            Object value = targetMessage.getValue(contextField);
            key += ((value == null) ? "null" : value.toString()) + "$";
        }
        return key;
    }

    private List<IKey> getContextFields(String target, IMessage targetMessage) {
        return ContextKeyFactory.getKey(target);
    }

    private IMessage createNewMessage(String target, String targetMessageName) {
        IMessageCreator messageCreator = new MessageCreatorFactory().getCreator(target);
        return messageCreator.create(targetMessageName);
    }

    private IMessage pullRequestFromCache(String origin, IMessage message) throws CacheNotFound {
        ICache cache = CacheFactory.getCache(origin);
        String cacheKey = getCacheKey(message, ContextKeyFactory.getKey(origin));
        IMessage cachedMessage = cache.pop(cacheKey);
        if (cachedMessage == null) {
            throw new CacheNotFound();
        }

        return cachedMessage;
    }

    private void addToRequestCache(String origin, IMessage message) throws CacheAlreadyExists {
        ICache cache = CacheFactory.getCache(origin);
        String cacheKey = getCacheKey(message, ContextKeyFactory.getKey(origin));
        if (cache.exists(cacheKey)) {
            throw new CacheAlreadyExists();
        }

        cache.push(cacheKey, new CacheMetaData(message, origin));
    }

    private void handleCacheNotFound(IMessage message) {

    }

    private void handleDuplicateRequestCache(IMessage message) {

    }

    private void handleUnknownMessageType(IMessage message) {

    }

    private void handleTargetMappingNotFound(String origin, IMessage message, String target, String targetMessageName) {

    }

    private void handleRoutingDestinationNotFound(String origin, IMessage message) {

    }

    public static void main(String[] args) {

    }


}

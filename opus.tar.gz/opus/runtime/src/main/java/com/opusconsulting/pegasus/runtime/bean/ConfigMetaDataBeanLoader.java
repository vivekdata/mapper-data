package com.opusconsulting.pegasus.runtime.bean;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.opusconsulting.pegasus.format.iso.metadata.EndPointDetail;
import com.opusconsulting.pegasus.format.iso.metadata.EndPointType;
import com.opusconsulting.pegasus.format.iso.metadata.EndpointProtocol;
import com.opusconsulting.pegasus.format.iso.metadata.EventbusEndPointDetails;
import com.opusconsulting.pegasus.format.iso.metadata.FieldDetail;
import com.opusconsulting.pegasus.format.iso.metadata.HttpEndPointDetail;
import com.opusconsulting.pegasus.format.iso.metadata.MessageDetail;
import com.opusconsulting.pegasus.format.iso.metadata.MessageFieldDetail;
import com.opusconsulting.pegasus.format.iso.metadata.MessageKind;
import com.opusconsulting.pegasus.format.iso.metadata.NodeDetail;
import com.opusconsulting.pegasus.format.iso.metadata.NodeEndPointDetails;
import com.opusconsulting.pegasus.runtime.ICondition;
import com.opusconsulting.pegasus.runtime.mapper.layman.IMappingMetaData;
import com.opusconsulting.pegasus.runtime.mapper.layman.IMappingMetaDataImpl;
import com.opusconsulting.pegasus.runtime.mapper.layman.IMessageCreator;
import com.opusconsulting.pegasus.runtime.mapper.layman.IMessageIdentifier;
import com.opusconsulting.pegasus.runtime.mapper.layman.IMessageIdentifierImpl;
import com.opusconsulting.pegasus.runtime.mapper.layman.IRoutingRules;
import com.opusconsulting.pegasus.runtime.mapper.layman.IRoutingRulesImpl;
import com.opusconsulting.pegasus.runtime.mapper.layman.MessageConfig;
import com.opusconsulting.pegasus.runtime.mapper.layman.MessageCreatorImpl;
import com.opusconsulting.pegasus.runtime.mapper.layman.MessageMappingImpl;
import com.opusconsulting.pegasus.runtime.mapper.layman.RoutingRule;
import com.opusconsulting.pegasus.runtime.steps.MappingConfig;

@Component
public class ConfigMetaDataBeanLoader {
	private static final Logger _logger = LoggerFactory.getLogger(ConfigMetaDataBeanLoader.class);
	
	@Autowired
	SpringBeanObjectInjecter beanObjectInjecter;
	
	
	@Autowired
	Environment env;
	
	
	public void buildEndPointBeans(Map<String, NodeDetail> nodeDetailsMap){
		
		String nodesNames=env.getProperty("node.names");
		
		String []nodes=nodesNames.split(",");
		
		for (String nodeName : nodes) {
			final String ipaddress = env.getProperty("node." + nodeName + ".ipaddress");
			final String port = env.getProperty("node." + nodeName + ".port");
			final String type = env.getProperty("node." + nodeName + ".type");
			final String protocol = env.getProperty("node." + nodeName + ".protocol");
			EndPointDetail endPointDetail = buildEndPoint(nodeName, ipaddress, port, type, protocol);
			if (!EndPointType.EVENTBUS.equals(EndPointType.valueOf(type))) {
				updateWithNodeEndPoints(endPointDetail, nodeDetailsMap.get(nodeName));
			}
			beanObjectInjecter.inject(endPointDetail.getNodeName() + "_endpoint", endPointDetail);
			
		}
	}

	private EndPointDetail buildEndPoint(String nodeName, final String ipaddress, final String port, final String type,
			final String protocol) {
		final String inboundAddress = env.getProperty("node." + nodeName + ".inboundAddress");
		final String outboundAddress = env.getProperty("node." + nodeName + ".outboundAddress");

		EndPointType endPointType = EndPointType.valueOf(type);
		EndpointProtocol endpointProtocol = EndpointProtocol.valueOf(protocol);
		
		if (EndPointType.EVENTBUS.equals(endPointType)) {
			return new EventbusEndPointDetails(nodeName, ipaddress, Integer.parseInt(port),
					endpointProtocol, endPointType, inboundAddress, outboundAddress);
		} else {
			if(EndpointProtocol.HTTP.equals(endpointProtocol)){
				return new HttpEndPointDetail(nodeName, ipaddress, Integer.parseInt(port), endpointProtocol, EndPointType.valueOf(type)); 
			} else {
				return new EndPointDetail(nodeName, ipaddress, Integer.parseInt(port), endpointProtocol,
						EndPointType.valueOf(type));
			}
		}
	}
	
	public void loadRoutingRuleBeans(final Map<String, List<RoutingRule>> routings){
		routings.entrySet().stream().forEach(entry -> {
			final IRoutingRules routingRules = new IRoutingRulesImpl(entry.getKey(), entry.getValue());
			beanObjectInjecter.inject(entry.getKey() + "_routing", routingRules);
		});
	}
	
	public void loadMessageIdentifierBeans(
			final Map<String, Map<MessageDetail<MessageFieldDetail<FieldDetail>>, ICondition>> messageConfigs) {
		messageConfigs.entrySet().stream().forEach(nodeMessagesEntry -> {
			Map<String, MessageConfig> messageConfigurationMap = nodeMessagesEntry.getValue().entrySet().stream()
					.map(messageEntry -> {
						return new MessageConfig(messageEntry.getValue(), messageEntry.getKey().getName(),
								messageEntry.getKey().getKind().equals(MessageKind.Request) ? true : false);
					}).collect(Collectors.toMap(e -> e.getName(), e -> e));

			final IMessageIdentifier messageIdentifier = new IMessageIdentifierImpl(messageConfigurationMap,
					nodeMessagesEntry.getKey());
			beanObjectInjecter.inject(nodeMessagesEntry.getKey() + "_messageIdentification_" + Math.random(),
					messageIdentifier);
		});
	}
	
	public void loadMessageCreatorBeans(
			final Map<String, Map<MessageDetail<MessageFieldDetail<FieldDetail>>, ICondition>> messageConfigs) {
		messageConfigs.entrySet().stream().forEach(nodeMessagesEntry -> {
			List<MessageConfig> messageConfigurations = nodeMessagesEntry.getValue().entrySet().stream()
					.map(messageEntry -> {
						return new MessageConfig(messageEntry.getValue(), messageEntry.getKey().getName(),
								messageEntry.getKey().getKind().equals(MessageKind.Request) ? true : false);
					}).collect(Collectors.toList());

			final IMessageCreator messageCreator = new MessageCreatorImpl(nodeMessagesEntry.getKey(),
					messageConfigurations);
			beanObjectInjecter.inject(nodeMessagesEntry.getKey() + "_messageCreator_" + Math.random(), messageCreator);
		});
	}
	
	public void loadMappingConfigBeans(final Map<String, List<MappingConfig>> mappingConfigs) {
		mappingConfigs.entrySet().stream().forEach(nodeMappingsEntry -> {
			nodeMappingsEntry.getValue().stream().map(mappingConfig -> {
				final IMappingMetaData metaData = new IMappingMetaDataImpl(mappingConfig.getSourceNodeName(),
						mappingConfig.getDestinationName(), mappingConfig.getSourceMessageName(),
						mappingConfig.getDestinationMessageName());
				return new MessageMappingImpl(mappingConfig, metaData);
			}).forEach(mapping -> {
				beanObjectInjecter.inject(
						nodeMappingsEntry.getKey() + "_mapping_" + mapping.getMetaData().getOriginMessageName() + "_" + Math.random(),
						mapping);
			});
		});
	}
	
	private void updateWithNodeEndPoints(EndPointDetail endPointDetail, NodeDetail<?> nodeDetail) {
		if(EndpointProtocol.HTTP.equals(endPointDetail.getProtocol())){
			updateHttpEndPoints(endPointDetail, nodeDetail);
		}
	}

	private void updateHttpEndPoints(EndPointDetail endPointDetail, NodeDetail<?> nodeDetail) {
		if(!endPointDetail.getClass().isAssignableFrom(HttpEndPointDetail.class)){
			_logger.error("Invalid endpoint details provided for the HTTP node. The endpoint should be of type HttpEndPointDetail.");
			return;
		}
		HttpEndPointDetail httpEndPoint = (HttpEndPointDetail)endPointDetail;
		nodeDetail.getEndpoints().stream().forEach(endpoint -> {
			NodeEndPointDetails nodeEndPointDetails = (NodeEndPointDetails)endpoint;
			httpEndPoint.loadEndPoint(nodeEndPointDetails.getUrl(), nodeEndPointDetails.getMessageName(), nodeEndPointDetails.getMethodName());
		});
	}
}

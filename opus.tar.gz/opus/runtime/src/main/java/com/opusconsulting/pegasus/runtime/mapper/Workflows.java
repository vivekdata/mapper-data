package com.opusconsulting.pegasus.runtime.mapper;

import com.opusconsulting.pegasus.flow.metadata.IFlowMetaData;
import com.opusconsulting.pegasus.flow.metadata.LinkInstanceInfo;
import com.opusconsulting.pegasus.flow.metadata.StepInstanceInfo;
import com.opusconsulting.pegasus.flow.metadata.impl.FlowMetaData;
import com.opusconsulting.pegasus.flow.resource.FRFactory;
import com.opusconsulting.pegasus.flow.resource.FRI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.function.Function;

@Component
public class Workflows {

    @Autowired
    FRFactory frFactory;

    public IFlowMetaData processIncomingTransactionMessageFlow(String nodeName) throws Exception {
        // Start
        StepInstanceInfo start = new StepInstanceInfo()
                .setName("Start")
                .setStepName("Start");

        // AddToCache
        StepInstanceInfo addToCache = new StepInstanceInfo()
                .setName("AddRequestCtxToCache")
                .setStepName("AddToCache");

        // PopFromCache
        StepInstanceInfo popFromCache = new StepInstanceInfo()
                .setName("PullRequestCtxFromCache")
                .setStepName("PopFromCache");

        // End
        StepInstanceInfo end = new StepInstanceInfo()
                .setName("End")
                .setStepName("End");

        Function<?, Boolean> isRequestCondition = frFactory.getValue(FRI.create("excel://flowCondition/isRequest(ctx)"));
        Function<?, Boolean> isResponseCondition = frFactory.getValue(FRI.create("excel://flowCondition/isResponse(ctx)"));

        LinkInstanceInfo startToAddRequestCtxToCacheLink = new LinkInstanceInfo();
        startToAddRequestCtxToCacheLink.setDescription("isRequest")
                .setSourceStepInstanceName("Start")
                .setDestinationStepInstanceName("AddRequestCtxToCache")
                .setCondition(isRequestCondition);

        LinkInstanceInfo startToPullRequestCtxFromCacheLink = new LinkInstanceInfo();
        startToPullRequestCtxFromCacheLink.setDescription("isResponse")
                .setSourceStepInstanceName("Start")
                .setDestinationStepInstanceName("PullRequestCtxFromCache")
                .setCondition(isResponseCondition);

        LinkInstanceInfo addRequestCtxToCacheToStopLink = new LinkInstanceInfo();
        addRequestCtxToCacheToStopLink
                .setSourceStepInstanceName("AddRequestCtxToCache")
                .setDestinationStepInstanceName("Stop");

        LinkInstanceInfo pullRequestCtxFromCacheToStopLink = new LinkInstanceInfo();
        pullRequestCtxFromCacheToStopLink
                .setSourceStepInstanceName("PullRequestCtxFromCache")
                .setDestinationStepInstanceName("Stop");

        FlowMetaData metaData = new FlowMetaData();
        metaData.setName(nodeName + "_IncomingProcessing");
        metaData.setStartStepInstanceName("Start")
                .setStepInstancesInfo(Arrays.asList(start, addToCache, popFromCache, end))
                .setLinkInstancesInfo(Arrays.asList(startToAddRequestCtxToCacheLink,
                        startToPullRequestCtxFromCacheLink,
                        addRequestCtxToCacheToStopLink,
                        pullRequestCtxFromCacheToStopLink));

        return metaData;
    }

    public static IFlowMetaData processOutgoingTransactionMessageFlow() {
        return null;
    }

}

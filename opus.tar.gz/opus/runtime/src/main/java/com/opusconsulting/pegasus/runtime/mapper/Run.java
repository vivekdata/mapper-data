package com.opusconsulting.pegasus.runtime.mapper;

import com.opusconsulting.pegasus.flow.impl.FlowFactory;
import com.opusconsulting.pegasus.flow.metadata.IFlowMetaData;

import java.util.List;

public class Run {


    public void start() {
        initializeWorkflow();
        initializeChannels();
        startChannels();
    }

    private void startChannels() {

    }

    private void initializeChannels() {

    }

    private void initializeWorkflow() {
        FlowFactory flowFactory = getFlowFactory();
        for (IFlowMetaData flowMetaData : getFlowMetaDatas()) {
            flowFactory.register(flowMetaData);
        }

    }

    private List<IFlowMetaData> getFlowMetaDatas() {
        /**
         *
         */



        return null;
    }

    private FlowFactory getFlowFactory() {
        return null;
    }


}

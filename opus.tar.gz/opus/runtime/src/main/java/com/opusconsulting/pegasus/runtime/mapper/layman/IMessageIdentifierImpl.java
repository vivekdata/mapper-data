package com.opusconsulting.pegasus.runtime.mapper.layman;

import java.util.Map;
import java.util.Optional;

import com.opusconsulting.pegasus.runtime.IMessage;

public class IMessageIdentifierImpl implements IMessageIdentifier {

	Map<String, MessageConfig> messageConfigs;
	String originNodeName;

	public IMessageIdentifierImpl(Map<String, MessageConfig> messageConfigs, String originNodeName) {
		super();
		this.messageConfigs = messageConfigs;
		this.originNodeName = originNodeName;
	}

	@Override
	public IMessageMetaData identify(IMessage message) {
		IMessageMetaDataImpl iMessageMetaDataImpl = null;
		final Optional<IMessageMetaDataImpl> messageMetaData = messageConfigs.entrySet().stream().filter(entry -> {
			return entry.getValue().getCondition().check(message, null, null);
		}).map(entry -> {
			return new IMessageMetaDataImpl(entry.getKey(), entry.getValue().isRequest());
		}).findFirst();
		if(messageMetaData.isPresent()){
			return messageMetaData.get();
		} else {
			return iMessageMetaDataImpl;
		}
	}

	@Override
	public String getOriginName() {
		return originNodeName;
	}

}

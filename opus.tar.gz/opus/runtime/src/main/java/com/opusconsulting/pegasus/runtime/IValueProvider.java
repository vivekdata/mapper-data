package com.opusconsulting.pegasus.runtime;

import java.util.Map;

import com.opusconsulting.pegasus.flow.IFlowContext;

public interface IValueProvider {
    <T> T get(IMessage message, IFlowContext ctx, Map<String, Object> params);
}

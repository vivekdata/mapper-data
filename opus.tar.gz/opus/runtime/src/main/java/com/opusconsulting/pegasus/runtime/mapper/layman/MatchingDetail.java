package com.opusconsulting.pegasus.runtime.mapper.layman;

public class MatchingDetail {
    private String messageName;
    private String nodeName;

    
    public MatchingDetail(String messageName, String nodeName) {
		super();
		this.messageName = messageName;
		this.nodeName = nodeName;
	}

	public MatchingDetail() {
		// TODO Auto-generated constructor stub
	}

	public String getMessageName() {
        return messageName;
    }

    public String getNodeName() {
        return nodeName;
    }
    
    
}

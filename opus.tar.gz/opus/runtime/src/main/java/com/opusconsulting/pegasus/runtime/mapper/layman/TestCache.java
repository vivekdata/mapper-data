package com.opusconsulting.pegasus.runtime.mapper.layman;

import java.net.URL;

import org.ehcache.CacheManager;
import org.ehcache.config.builders.CacheManagerBuilder;
import org.ehcache.xml.XmlConfiguration;

public class TestCache {
	public static void main(String[] args) {
		final URL myUrl = TestCache.class.getResource("/ehcache2.xml"); 
		XmlConfiguration xmlConfig = new XmlConfiguration(myUrl); 
		CacheManager manager = CacheManagerBuilder.newCacheManager(xmlConfig);
		manager.getRuntimeConfiguration().getCacheConfigurations().entrySet().stream().forEach(entry ->{
			System.out.println("cache name: " + entry.getKey());
		});
	}
}

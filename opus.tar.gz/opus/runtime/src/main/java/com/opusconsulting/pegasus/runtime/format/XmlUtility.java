package com.opusconsulting.pegasus.runtime.format;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import com.opusconsulting.pegasus.format.iso.metadata.MessageFieldDetail;
import com.opusconsulting.pegasus.format.iso.metadata.XmlFieldMetaData;
import com.opusconsulting.pegasus.runtime.DefaultIMessage;
import com.opusconsulting.pegasus.runtime.XmlIMessage;
import com.opusconsulting.pegasus.runtime.mapper.layman.MessageKey;

/**
 * 
 * @author Anup.Warke 27/03/2018
 *
 */
public class XmlUtility {
	private static final String XPATH_SEPARATOR_REGEX = "/";

	@SuppressWarnings("unchecked")
	public static <T> T readXPathValue(XmlIMessage xmlMessage, String xPath) {
		if (xPath == null)
			return (T) new DefaultIMessage(null);
		List<String> xPathFields = parseXPath(xPath);
		int index = 1;
		
			return (T) getXpathFieldValue(xPathFields, index, xmlMessage);
		
	}

	private static Object getXpathFieldValue(List<String> xPathFields, int index, XmlIMessage message) {
        if (message == null || xPathFields == null)
            return null;
        final String fieldName = xPathFields.get(index);
        index++;
        
        boolean fieldNameIsElementIndex = fieldName.matches("\\[\\d*\\]");//xpath has the index of the element to be read
        XmlIMessage fieldXmlMessage = null;
        for (int childIndex = 0; childIndex < message.getChildren().size(); childIndex++) {
            final XmlIMessage xmlChildMesg = message.getChildren().get(childIndex);
            if(fieldNameIsElementIndex){
                int elementIndex = Integer.parseInt(fieldName.substring(1, fieldName.lastIndexOf("]")));
                if(childIndex == elementIndex){
                     fieldXmlMessage = xmlChildMesg;
                     break;
                }
            } else if(xmlChildMesg.getElementName().equalsIgnoreCase(fieldName)){
                fieldXmlMessage = xmlChildMesg;
                break;
            }
        }
        
        if (fieldXmlMessage != null) {
            if (index == (xPathFields.size() - 1)) {
                if (xPathFields.get(index).equalsIgnoreCase("TEXT")) {
                     return fieldXmlMessage.getValue(new MessageKey(fieldName));
                } else if (xPathFields.get(index).equalsIgnoreCase("TAG")) {
                     return fieldXmlMessage.getElementName();
                }
                return new DefaultIMessage(null);
            }
            else if (index == (xPathFields.size()-2) && xPathFields.get(index+1).equalsIgnoreCase("ATTR")) {
                return fieldXmlMessage.getAttrribute(xPathFields.get(index));
            }
            else {
                return getXpathFieldValue(xPathFields, index, fieldXmlMessage);
            }
        } else {
            return null;
        }
   }

	
	private static List<String> parseXPath(String xPath) {
		return Arrays.asList(xPath.split(XPATH_SEPARATOR_REGEX));
	}

	public static String getfieldXpath(List<MessageFieldDetail<XmlFieldMetaData>> messageFields, String fieldName) {
		for (MessageFieldDetail<XmlFieldMetaData> xmlFieldMetaData : messageFields) {
			if (xmlFieldMetaData.getField().getName().equalsIgnoreCase(fieldName)) {
				return xmlFieldMetaData.getField().getxPath();
			}

			if (xmlFieldMetaData.getField().getChildren() != null
					&& !xmlFieldMetaData.getField().getChildren().isEmpty()) {
				return getfieldXpath(xmlFieldMetaData.getField().getChildren(), fieldName);
			}
		}
		return null;
	}

}

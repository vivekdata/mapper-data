package com.opusconsulting.pegasus.runtime.mapper.layman;

import com.opusconsulting.pegasus.runtime.IMessage;

public interface IMessageCreator {
    IMessage create(String targetMessageName);
    
    String getOriginName();
}

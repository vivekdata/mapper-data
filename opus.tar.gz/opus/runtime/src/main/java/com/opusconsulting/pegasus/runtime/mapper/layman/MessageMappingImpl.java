package com.opusconsulting.pegasus.runtime.mapper.layman;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.opusconsulting.pegasus.runtime.DefaultIMessage;
import com.opusconsulting.pegasus.runtime.IConstants;
import com.opusconsulting.pegasus.runtime.IMessage;
import com.opusconsulting.pegasus.runtime.IValueProvider;
import com.opusconsulting.pegasus.runtime.steps.MappingConfig;

public class MessageMappingImpl implements IMessageMapping {

	private MappingConfig mappingConfig;
	private IMappingMetaData metaData;

	public MessageMappingImpl(MappingConfig mappingConfig, IMappingMetaData metaData) {
		super();
		this.mappingConfig = mappingConfig;
		this.metaData = metaData;
	}

	@Override
	public void map(IMessage originMessage, IMessage targetMessage, List<IKey> contextFields) {
		mappingConfig.getFieldMapping().entrySet().stream().filter((entry) -> {
			return contextFields.stream().anyMatch((iKey ->{
				return entry.getKey().equalsIgnoreCase(iKey.toString());
			}));
		}).forEach(entry ->{
			Object value = entry.getValue().get(originMessage, null, null);
//			targetMessage.setValue(new MessageKey(entry.getKey()), value);
			loadMessageValue(targetMessage, entry.getKey(), value);
		});
	}

	@Override
	public void map(IMessage originMessage, IMessage targetMessage, IMessage targetRequestMessage) {
		//param required in case to retrieve the values from the context messages
		Map<String, Object> params = new HashMap<String, Object>();
		params.put(IConstants.CONTEXT_MESSAGE, targetRequestMessage);
		for (Map.Entry<String, IValueProvider> valueProviderEntry : mappingConfig.getFieldMapping().entrySet()) {
			Object value = valueProviderEntry.getValue().get(originMessage, null, params);
			loadMessageValue(targetMessage, valueProviderEntry.getKey(), value);
		}
	}

	/**
	 * This function checks if the field name is of type "Composite" then it prepare the object hierarchy
	 * @param targetMessage
	 * @param fieldName
	 * @param value
	 */
	private void loadMessageValue(IMessage targetMessage, String fieldName,
			Object value) {
		if(fieldName.contains(".")){
			populateSubFieldsForMapping(targetMessage, fieldName.split("\\."), 0, value);
		} else {
			targetMessage.setValue(new MessageKey(fieldName), value);
		}
	}

	private void populateSubFieldsForMapping(IMessage message, String[] compositeFields, int fieldStartIndex, Object value) {
		DefaultIMessage subFieldIMessage = message.getValue(new MessageKey(compositeFields[fieldStartIndex]));
		if(subFieldIMessage == null){
			subFieldIMessage = new DefaultIMessage(message.getNodeMetaData());
		}
		message.setValue(new MessageKey(compositeFields[fieldStartIndex]),
				subFieldIMessage);
		fieldStartIndex++;
		if(fieldStartIndex < (compositeFields.length - 1)){
			populateSubFieldsForMapping(subFieldIMessage, compositeFields, fieldStartIndex, value);
		} else {
			subFieldIMessage.setValue(new MessageKey(compositeFields[fieldStartIndex]), value);
		}
	}

	@Override
	public IMappingMetaData getMetaData() {
		return this.metaData;
	}

}

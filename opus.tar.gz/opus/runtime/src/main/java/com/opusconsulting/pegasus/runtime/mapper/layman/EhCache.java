package com.opusconsulting.pegasus.runtime.mapper.layman;

import org.ehcache.Cache;

import com.opusconsulting.pegasus.runtime.IMessage;

public class EhCache implements ICache {
	private Cache<String, CacheMetaData> cache;

	public EhCache(Cache<String, CacheMetaData> cache) {
		super();
		this.cache = cache;
	}

	@Override
	public void push(String cacheKey, CacheMetaData cacheMetaData) {
		if(cache != null)
			cache.put(cacheKey, cacheMetaData);
	}

	@Override
	public boolean exists(String cacheKey) {
		if(cache != null)
			return cache.containsKey(cacheKey);
		else
			return false;
	}

	@Override
	public IMessage pop(String cacheKey) {
		if(cache != null && cache.containsKey(cacheKey)){
			IMessage message = cache.get(cacheKey).getMessage();
			cache.remove(cacheKey);
			return message;
		}
		return null;
	}

	@Override
	public IMessage fetch(String cacheKey) {
		if(cache != null && cache.containsKey(cacheKey)){
			return cache.get(cacheKey).getMessage();
		}
		return null;
	}

}

package com.opusconsulting.pegasus.runtime.flow;

import java.util.Map;

public interface IWorkflow {
	String STARTUP = "startup";
	String DESERIALIZE = "deserializer";
	String SERIALIZE = "serializer";
	String TRANSFORM = "transformation";

	void registerToFactory(Map<String, Object> workFlowData);
}

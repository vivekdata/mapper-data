package com.opusconsulting.pegasus.runtime.mapper.layman;

import com.opusconsulting.pegasus.runtime.ICondition;

public class MessageConfig {
	ICondition condition;
	String name;
	boolean request;
	
	public MessageConfig(ICondition condition, String name, boolean request) {
		super();
		this.condition = condition;
		this.name = name;
		this.request = request;
	}

	public ICondition getCondition() {
		return condition;
	}

	public String getName() {
		return name;
	}

	public boolean isRequest() {
		return request;
	}
}

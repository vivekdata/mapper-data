package com.opusconsulting.pegasus.runtime.steps;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.opusconsulting.pegasus.common.resource.exception.ApplicationException;
import com.opusconsulting.pegasus.flow.IFlowContext;
import com.opusconsulting.pegasus.flow.impl.AbstractStepInstance;
import com.opusconsulting.pegasus.format.iso.metadata.MessageDetail;
import com.opusconsulting.pegasus.format.iso.metadata.MessageFieldDetail;
import com.opusconsulting.pegasus.format.iso.metadata.NodeDetail;
import com.opusconsulting.pegasus.format.iso.metadata.XmlFieldMetaData;
import com.opusconsulting.pegasus.format.iso.metadata.XmlMessageDetails;
import com.opusconsulting.pegasus.format.iso.metadata.XmlNodeDetail;
import com.opusconsulting.pegasus.runtime.IConstants;
import com.opusconsulting.pegasus.runtime.IMessage;
import com.opusconsulting.pegasus.runtime.XmlIMessage;
import com.opusconsulting.pegasus.runtime.steps.iso.ByteParser;
import com.opusconsulting.pegasus.runtime.steps.iso.XmlByteParser;

public class XmlByteBufferSerializerStep extends AbstractStepInstance {
	private static final Logger _logger = LoggerFactory.getLogger(XmlByteBufferSerializerStep.class);

	private NodeDetail<MessageDetail> nodeDetail;

	private ByteParser parser;

	@Override
	public <I, R> R process(IFlowContext context, I previousStepResult, Map<String, Object> flowProps) {
		// TODO Auto-generated method stub
		final IMessage message = (IMessage) flowProps.get(IConstants.FLOW_PROPS_TRANSFORMED_REQUEST_KEY);

		if (message == null) {
			_logger.error("No message received to serialize from the flow properties of the step.");
			return (R) message;
		}

		XmlMessageDetails xmlMessageDetails = getXMLMessage(message, this.nodeDetail);
		this.parser = new XmlByteParser(
				(List<MessageFieldDetail<XmlFieldMetaData>>) xmlMessageDetails.getMessageFields());

		try {
			return (R) this.parser.pack((IMessage) message);
		} catch (ApplicationException e) {
			_logger.error(e.getMessage(), e);
			onError(context, null, flowProps, e);
			return null;
		}
	}

	private XmlMessageDetails getXMLMessage(final IMessage message, NodeDetail nodeDetail) {
		XmlMessageDetails xmlMessageDetails = null;
		Optional<XmlMessageDetails> messageDetailOptinal = ((XmlNodeDetail) nodeDetail).getMessages().stream()
				.filter((messageDetail) -> {
					return messageDetail.getName().equalsIgnoreCase(message.getMetaData().getName());
				}).findFirst();

		Map<String, XmlIMessage> iMessageMap = new HashMap<>();
		if (messageDetailOptinal.isPresent()) {
			xmlMessageDetails = messageDetailOptinal.get();
		} else {
			_logger.error("No message configuration found for the identified message while serialization.");
		}
		return xmlMessageDetails;
	}

	public void setNodeDetail(NodeDetail<MessageDetail> nodeDetail) {
		this.nodeDetail = nodeDetail;
	}

}

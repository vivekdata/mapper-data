package com.opusconsulting.pegasus.runtime.steps.iso;

import org.springframework.stereotype.Component;

import com.opusconsulting.pegasus.runtime.DefaultIMessage;
import com.opusconsulting.pegasus.runtime.IMessage;
import com.opusconsulting.pegasus.runtime.mapper.layman.NodeMetaData;

import io.vertx.core.buffer.Buffer;
import io.vertx.core.json.JsonObject;

@Component
public class JsonByteParser implements ByteParser {

	public JsonByteParser() {
		super();
	}

	@Override
	public IMessage unpack(byte[] input) {
		Buffer buff = Buffer.buffer(input);
		JsonObject jsonObject = buff.toJsonObject();
		DefaultIMessage message = new DefaultIMessage(new NodeMetaData(null));
		message.build(jsonObject);
		return message;
	}

	@Override
	public byte[] pack(IMessage message) {
		JsonObject messageJsonObject = ((DefaultIMessage) message).format();
		Buffer buffer = messageJsonObject.toBuffer();
		return buffer.getBytes();
	}

}

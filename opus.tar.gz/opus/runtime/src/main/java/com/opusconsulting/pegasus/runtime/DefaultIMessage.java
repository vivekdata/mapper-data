package com.opusconsulting.pegasus.runtime;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.IntStream;

import org.jpos.iso.ISOComponent;
import org.jpos.iso.ISOField;
import org.jpos.iso.ISOMsg;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.opusconsulting.pegasus.format.iso.metadata.ISOFieldMetaData;
import com.opusconsulting.pegasus.format.iso.metadata.MessageFieldDetail;
import com.opusconsulting.pegasus.format.iso.metadata.XmlFieldMetaData;
import com.opusconsulting.pegasus.runtime.event.handler.ClientCommunicationEventHandler;
import com.opusconsulting.pegasus.runtime.format.XmlUtility;
import com.opusconsulting.pegasus.runtime.mapper.layman.IKey;
import com.opusconsulting.pegasus.runtime.mapper.layman.IMessageMetaData;
import com.opusconsulting.pegasus.runtime.mapper.layman.INodeMetaData;
import com.opusconsulting.pegasus.runtime.mapper.layman.MessageKey;

import io.vertx.core.json.JsonObject;

public class DefaultIMessage implements IMessage {
	/**
	 * 
	 */
	private static final Logger _logger = LoggerFactory.getLogger(DefaultIMessage.class);
	private static final long serialVersionUID = -3490007184030634291L;
	IMessageMetaData metaData;
	INodeMetaData nodeMeataData;
	Map<String, Object> values;

	public DefaultIMessage(INodeMetaData nodeMetaData) {
		super();
		this.nodeMeataData = nodeMetaData;
		this.values = new HashMap<>();
	}

	public void build(ISOMsg msg, List<ISOFieldMetaData> fieldDetails) {
		final Map<Integer, Object> fields = msg.getChildren();
		fields.forEach((fieldNo, isoComponent) -> {
			final ISOComponent jposField = (ISOComponent) isoComponent;
			try {
				// System.out.println("Field No:" + jposField.getKey());
				// System.out.println("Field Value:" + jposField.getValue());
				if (((Integer) jposField.getKey()).intValue() == -1) {
					return;
				}
				// Assuming the key of the each ISO component from JPOS will be
				// the field number which will be an integer
				final ISOFieldMetaData fieldMetaData = fieldDetails.get((Integer) jposField.getKey());
				this.setValue(new MessageKey(fieldMetaData.getName()), jposField.getValue());
			} catch (Exception e) {
				_logger.error("Error while building ISO message", e);
			}
		});
	}

	public ISOMsg format(List<ISOFieldMetaData> fieldDetails) {
		final ISOMsg msg = new ISOMsg();
		this.values.entrySet().stream().forEach((entry) -> {
			IntStream.range(0, fieldDetails.size()).filter(i -> entry.getKey().equals(fieldDetails.get(i).getName()))
					.findFirst().ifPresent((index) -> {
						ISOComponent c = new ISOField(index);
						if (c == null || entry.getValue() == null)
							return;
						try {
							c.setValue(entry.getValue());
							msg.set(c);
						} catch (Exception e) {
							// TODO handle exception and continue loop
							_logger.error("Error while formatting ISO message ",e);
							
						}
					});
		});
		return msg;
	}

	public void formatToXml(List<MessageFieldDetail<XmlFieldMetaData>> messageFields, final XmlIMessage message) {
		this.values.entrySet().forEach(valueEntry -> {
			Optional<MessageFieldDetail<XmlFieldMetaData>> messageDetailOptional = messageFields.stream()
					.filter((messageField -> {
						return messageField.getField().getName().equalsIgnoreCase(valueEntry.getKey());
					})).findFirst();
			if (messageDetailOptional.isPresent()) {
				final MessageFieldDetail<XmlFieldMetaData> messageDetail = messageDetailOptional.get();
				loadXmlElementValue(messageDetail, message, valueEntry.getValue());
				if (messageDetail.getField().getChildren() != null
						&& !messageDetail.getField().getChildren().isEmpty()) {
					final DefaultIMessage currentCompositeFieldValue = (DefaultIMessage) valueEntry.getValue();
					currentCompositeFieldValue.formatToXml(messageDetail.getField().getChildren(), message);
				}

			}
		});
	}

	private void loadXmlElementValue(MessageFieldDetail<XmlFieldMetaData> messageField, final XmlIMessage rootMessage,
			final Object fieldValue) {
		String xpathValue = messageField.getField().getxPath();
		if (xpathValue == null)
			return;
		List<String> xpathValues = Arrays.asList(xpathValue.split("\\/"));
		loadElement(rootMessage, 1, xpathValues, fieldValue);
	}

	private void loadElement(final XmlIMessage xmlMessage, int index, final List<String> xmlElements,
			final Object fieldValue) {
		boolean isAttribute = false;
		if (index == (xmlElements.size() - 1)) {
			final String elementType = xmlElements.get(index);
			if ("TEXT".equalsIgnoreCase(elementType)) {
				xmlMessage.setValue(null, fieldValue);
			} else if ("TAG".equalsIgnoreCase(elementType)) {
				xmlMessage.setElementName((String) fieldValue);
			}
			return;
		} else if (index == (xmlElements.size() - 2) && "ATTR".equalsIgnoreCase(xmlElements.get(index + 1))) {
			isAttribute = true;
		}
		final String elementName = xmlElements.get(index);
		index++;
		if (elementName.matches("\\[\\d*\\]")) {
			final XmlIMessage childXmlMessage = buildChildXmlMessage(xmlMessage, index, xmlElements, fieldValue,
					elementName);
			loadElement(childXmlMessage, index, xmlElements, fieldValue);
		} else if (!isAttribute) {
			final XmlIMessage childXmlMessage = buildChildXmlMessage(xmlMessage, index, xmlElements, fieldValue,
					elementName);
			loadElement(childXmlMessage, index, xmlElements, fieldValue);
		} else {
			xmlMessage.addAttribute(elementName, fieldValue);
			return;
		}
	}

	private XmlIMessage buildChildXmlMessage(final XmlIMessage xmlMessage, int index, final List<String> xmlElements,
			final Object fieldValue, final String elementName) {
		XmlIMessage childXmlMessage = null;
		if (xmlMessage.getChildren() == null) {
			childXmlMessage = new XmlIMessage(xmlMessage.getNodeMetaData(), elementName, null);
			xmlMessage.addChildren(childXmlMessage);
			loadElement(childXmlMessage, index, xmlElements, fieldValue);
		} else {
			Optional<XmlIMessage> xmlChildMessageOptional = xmlMessage.getChildren().stream().filter(childElement -> {
				return childElement.getElementName().equalsIgnoreCase(elementName);
			}).findFirst();
			if (xmlChildMessageOptional.isPresent()) {
				childXmlMessage = xmlChildMessageOptional.get();
			} else {
				//if the element is not present and the element name suffice \\[\\d*\\] regex, this means
				//application has to get the children at specified index.
				if(elementName.matches("\\[\\d*\\]")) {
					//create the pattern to fetch the TAG index
					final Pattern tagIndexPattern = Pattern.compile("([0-9]*)");
					//create the Matcher for tagIndexPattern
					final Matcher tagIndexMatcher = tagIndexPattern.matcher(elementName);
					if(tagIndexMatcher.find()) {
						final String tagIndexStringValue = tagIndexMatcher.group(1);
						try {
							//get the integer of it and fetch the Element value from the children list.
							childXmlMessage = xmlMessage.getChildren().get(Integer.parseInt(tagIndexStringValue));
						} catch(NumberFormatException numberFormatException) {
							_logger.error("Error while checking the TAG index for {}. Received: {} Expected a number.", elementName, tagIndexStringValue);
						}
					}
				}
				if(childXmlMessage == null) {
					childXmlMessage = new XmlIMessage(xmlMessage.getNodeMetaData(), elementName, null);
					xmlMessage.addChildren(childXmlMessage);
				}
			}
		}
		return childXmlMessage;
	}

	public void build(List<MessageFieldDetail<XmlFieldMetaData>> fieldDetails, XmlIMessage xmlIMessage) {
		if (fieldDetails != null) {
			fieldDetails.stream().forEach((xmlField) -> {
				loadValueForXPath(xmlIMessage, xmlField, this);
			});
		}
	}

	private void loadValueForXPath(XmlIMessage xmlIMessage, MessageFieldDetail<XmlFieldMetaData> xmlField,
			IMessage message) {
		String fieldXPath = xmlField.getField().getxPath();
		Object fieldValue = XmlUtility.readXPathValue((XmlIMessage) xmlIMessage, fieldXPath);
		message.setValue(new MessageKey(xmlField.getField().getName()), fieldValue);
		if (fieldValue instanceof DefaultIMessage) {
			xmlField.getField().getChildren().stream().forEach((childField) -> {
				loadValueForXPath(xmlIMessage, childField, (IMessage) fieldValue);
			});
		}
	}

	public void build(JsonObject jsonObject) {
		jsonObject.forEach(entry -> {

			if (entry.getValue() instanceof JsonObject) {
				DefaultIMessage childIMessage = new DefaultIMessage(this.nodeMeataData);
				childIMessage.build((JsonObject) entry.getValue());
				this.setValue(new MessageKey(entry.getKey()), (Object) childIMessage);
			} else
				this.setValue(new MessageKey(entry.getKey()), entry.getValue());

		});
	}

	public JsonObject format() {
		JsonObject formatted = new JsonObject();
		this.values.entrySet().stream().forEach(entry -> {
			if (entry.getValue() instanceof DefaultIMessage) {
				formatted.put(entry.getKey(), ((DefaultIMessage) entry.getValue()).format());
			} else
				formatted.put(entry.getKey(), entry.getValue());
		});
		return formatted;
	}

	@Override
	public IMessageMetaData getMetaData() {
		return this.metaData;
	}

	@Override
	public INodeMetaData getNodeMetaData() {
		return this.nodeMeataData;
	}

	@Override
	public void setMetaData(IMessageMetaData metaData) {
		this.metaData = metaData;
	}

	@Override
	public Object getValue(IKey key) {
		return values.get(key.getValue());
	}

	@Override
	public void setValue(IKey key, Object value) {
		this.values.put(key.getValue(), value);
	}
}

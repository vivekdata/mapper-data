package com.opusconsulting.pegasus.runtime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.opusconsulting.pegasus.common.event.IEventConsumer;
import com.opusconsulting.pegasus.common.event.IEventPublisher;
import com.opusconsulting.pegasus.event.impl.EventManager;
import com.opusconsulting.pegasus.runtime.event.RuntimeEventSubjects;
import com.opusconsulting.pegasus.runtime.event.handler.ClientCommunicationEventHandler;
import com.opusconsulting.pegasus.runtime.event.handler.EnvStartupActivityEventHandler;
import com.opusconsulting.pegasus.runtime.event.handler.HeartBeatServerHandler;
import com.opusconsulting.pegasus.runtime.event.handler.ProcessMessageBufferEventHandler;
import com.opusconsulting.pegasus.runtime.event.handler.StartServerEventHandler;

@Configuration
public class EventHandlerConfiguration {
	@Autowired
	EventManager eventManager;

	@Bean(name={"startServerEventPublisher"})
	public IEventPublisher createStartServerEventPublisher(StartServerEventHandler startServerEventHandler) {
		return eventManager.createPublisher(RuntimeEventSubjects.ENVIRONMENT_BOOT.name(), startServerEventHandler);
	}

	@Bean(name={"startServerEventConsumer"})
	public IEventConsumer createStartServerEventConsumer(StartServerEventHandler startServerEventHandler) {
		return eventManager.createConsumer(RuntimeEventSubjects.ENVIRONMENT_BOOT.name(), startServerEventHandler);
	}
	
	@Bean(name={"envStartupActivityEventPublisher"})
	public IEventPublisher createEnvStartupActivityEventPublisher(EnvStartupActivityEventHandler envStartupActivityEventHandler) {
		return eventManager.createPublisher(RuntimeEventSubjects.ENV_STARTUP_ACTIVITY.name(), envStartupActivityEventHandler);
	}

	@Bean(name={"envStartupActivityEventConsumer"})
	public IEventConsumer createEnvStartupActivityEventConsumer(EnvStartupActivityEventHandler envStartupActivityEventHandler) {
		return eventManager.createConsumer(RuntimeEventSubjects.ENV_STARTUP_ACTIVITY.name(), envStartupActivityEventHandler);
	}
	
	@Bean(name={"clientActivityEventPublisher"})
	public IEventPublisher createClientActivityEventPublisher(ClientCommunicationEventHandler clientCommunicationEventHandler) {
		return eventManager.createPublisher(RuntimeEventSubjects.CLIENT_ACTIVITY.name(), clientCommunicationEventHandler);
	}

	@Bean(name={"clientActivityEventConsumer"})
	public IEventConsumer createClientActivityEventConsumer(ClientCommunicationEventHandler clientCommunicationEventHandler) {
		return eventManager.createConsumer(RuntimeEventSubjects.CLIENT_ACTIVITY.name(), clientCommunicationEventHandler);
	}
	
	@Bean(name={"processMessageEventPublisher"})
	public IEventPublisher createProcessMessageEventPublisher(ProcessMessageBufferEventHandler processMessageBufferEventHandler) {
		return eventManager.createPublisher(RuntimeEventSubjects.PROCESS.name(), processMessageBufferEventHandler);
	}

	@Bean(name={"processMessageEventConsumer"})
	public IEventConsumer createProcessMessageEventConsumer(ProcessMessageBufferEventHandler processMessageBufferEventHandler) {
		return eventManager.createConsumer(RuntimeEventSubjects.PROCESS.name(), processMessageBufferEventHandler);
	}
	
	@Bean(name={"heartbeatHandlerPublisher"})
	public IEventPublisher createHeartBeatEventPublisher(HeartBeatServerHandler heartbeatHandler) {
		return eventManager.createPublisher(RuntimeEventSubjects.HEARTBEAT.name(), heartbeatHandler);
	}
	
	@Bean(name={"heartbeatHandlerConsumer"})
	public IEventConsumer createHeartBeatEventConsumer(HeartBeatServerHandler heartbeatHandler) {
		return eventManager.createConsumer(RuntimeEventSubjects.HEARTBEAT.name(), heartbeatHandler);
	}
}

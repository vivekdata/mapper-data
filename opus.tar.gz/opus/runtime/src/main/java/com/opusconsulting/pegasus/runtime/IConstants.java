package com.opusconsulting.pegasus.runtime;

import com.opusconsulting.pegasus.channel.http.handler.HttpChannelHandler;

public interface IConstants {
	String SOURCE_MESSAGE = "REQUEST";
	String SOURCE_MESSAGE_NAME = "MESSAGE_NAME";

	String DESTINATION_MESSAGE = "RESPONSE";
	String DESTINATION_MESSAGE_NAME = "RESPONSE_MESSAGE_NAME";

	String EVENT_CTX_SOURCE_NODE_NAME_KEY = "SOURCE_NODE";
	String EVENT_CTX_DESTINATION_NODE_NAME_KEY = "DESTINATION_NODE";

	String FLOW_PROPS_MESSAGE_BUFFER_KEY = "messageBuffer";
	String FLOW_PROPS_NODE_NAME_KEY = "nodeName";
	String FLOW_PROPS_REQUEST_KEY = "message";
	String FLOW_PROPS_TRANSFORMED_REQUEST_KEY = "transformedMessage";

	String NODE_DETAILS_CONFIGS = "nodeDetails"; 
	String FIELD_MAPPING_CONFIGS = "mappingConfigs";
	String ROUTING_CONFIGS = "routings"; 
	String MESSAGE_IDENTIFICATION_CONFIGS = "messageFormulas"; 
	
//	String EVENT_CTX_NODE_NAME_KEY = "nodeName";
	String SERVER_MSG_PROTOCOL_CTX = "serverMessageProtocolContextValue";
	String DESTINATION_NODE_NAME = "destination_node";
	
	String VIRTUALIZATION_DETAILS = "virtualizationDetails";
	String CONTEXT_MESSAGE = "contextMessageValue";
	String JSON_FILES_NAME_SEPERATOR=",";
	
	//constants for virtualization sample feed related event context
	String EVENT_CTX_MESSAGE_NAME = "messageName";
	String EVENT_CTX_MESSAGE_TYPE_REQUEST = "messageTypeRequest";
	String EVENT_CTX_NODE_FORMAT = "format";
	String TRANSFORM_RESULT_PARAM_SEND_RESPONSE_KEY = "sendResponse";
	
	String EVENT_CTX_SERIALIZED_RESPONSE_BUFFER = "sendResponseBuffer";
	String EVENT_CTX_CONTEXT = "eventContext";
	String EVENT_CTX_CHANNEL_CONTEXT = "channelContextKey";

	// constants for HTTP GET AND DELETE REQUEST
	String IS_REQUEST_PARAM_DESERIALIZE_SERIALIZE_REQUIRED = "isRequestParamDeserializerSerializerRequired";
	String HTTP_MESSAGE_NAME_PROPS_KEY = HttpChannelHandler.HTTP_MESSAGE_NAME_PROPS_KEY;
	String IS_HTTP_REQUEST_MESSAGE_PROPS_KEY = "isRequest";
	String HTTP_REQUEST_PARAM_FIELDS_KEY = HttpChannelHandler.EVENT_CTX_REQUEST_PARAM;
	String FLOW_PROPS_TRANSFORMED_MESSAGE_FIELDS = "transformedMessageFieldValues";
	
	String EVENT_CTX_NODE_NAME_KEY = "nodeName";
	String EVENT_CTX_ADDRESS = "address";
	String EVENT_CTX_PORT = "port";
}

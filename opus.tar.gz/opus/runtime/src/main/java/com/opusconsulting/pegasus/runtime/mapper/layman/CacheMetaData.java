package com.opusconsulting.pegasus.runtime.mapper.layman;

import java.io.Serializable;

import com.opusconsulting.pegasus.runtime.IMessage;

public class CacheMetaData implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7411249844277088671L;
	IMessage message;
	String origin;
	
	public CacheMetaData(IMessage message, String origin) {
		super();
		this.message = message;
		this.origin = origin;
	}
	public IMessage getMessage() {
		return message;
	}
	public String getOrigin() {
		return origin;
	}
	
	
	
}

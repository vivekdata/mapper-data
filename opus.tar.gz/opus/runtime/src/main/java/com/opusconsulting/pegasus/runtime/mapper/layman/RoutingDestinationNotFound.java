package com.opusconsulting.pegasus.runtime.mapper.layman;

public class RoutingDestinationNotFound extends Exception {

	public RoutingDestinationNotFound(String message) {
		super(message);
	}
	
	public RoutingDestinationNotFound() {
		super();
	}
	
}

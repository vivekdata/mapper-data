package com.opusconsulting.pegasus.runtime;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

import io.netty.bootstrap.ServerBootstrap;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.logging.LogLevel;
import io.netty.handler.logging.LoggingHandler;

public class TestServer {
	static SocketChannel serverChannel;
	public static void main1(String[] args) throws InterruptedException {
		EventLoopGroup bossGroup = new NioEventLoopGroup();
        EventLoopGroup workerGroup = new NioEventLoopGroup();
        try {
        	
            ServerBootstrap b = new ServerBootstrap();
            b.group(bossGroup, workerGroup)
                    .channel(NioServerSocketChannel.class)
                    .handler(new LoggingHandler(LogLevel.INFO))
                    .childHandler(new ChannelInitializer<SocketChannel>() {

						@Override
						protected void initChannel(final SocketChannel ch) throws Exception {
							serverChannel = ch;
							ch.pipeline().addLast(new SimpleChannelInboundHandler<ByteBuf>() {
								@Override
								protected void channelRead0(ChannelHandlerContext ctx, ByteBuf msg) throws Exception {
									 byte[] data = new byte[msg.readableBytes()];
							         msg.readBytes(data);
									 System.out.println("Message To Server: " + new String(data));
								}
							});
						}
					});
            ChannelFuture bind = b.bind(6000).sync();
           
            bind.addListener(future -> {
                if(future.awaitUninterruptibly().isDone()) {
                	if(future.isSuccess()) {
                		System.out.println("Server started");
                	} else {
                		System.err.println("Failed");
                	}
                }
            });
            
            
            Thread.sleep(30000);
            bind.channel().writeAndFlush("Hello Client").addListener(future -> {
            	if(future.awaitUninterruptibly().isDone()) {
            		System.out.println("Message sent successfully." + future.isSuccess());
            		Throwable error = future.cause();
            		if(error != null) {
            			System.err.println(error);
            			error.printStackTrace();
            		}
            	}
            });
            bind.channel().closeFuture().sync();
        } finally {
        }

	}
	
	public static void main(String[] args) {
		try {
			ServerSocket serverSocket = new ServerSocket(6000);
			Socket clientSocket = serverSocket.accept();
			System.out.println("Client connected.");
			BufferedOutputStream outputStream = new BufferedOutputStream(clientSocket.getOutputStream());
			outputStream.write("Hello Client".getBytes());
			outputStream.flush();
			System.out.println("Message sent to client.");
			
			BufferedInputStream inputStream = new BufferedInputStream(clientSocket.getInputStream());
			System.out.println("Message waiting from client");
			int i = inputStream.read();
			System.out.println("Message received from client.");
			while(i != -1) {
				System.out.print((char)i);
				i = inputStream.read();
			}
			outputStream.close();
			inputStream.close();
			serverSocket.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}

package com.opusconsulting.pegasus.runtime;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.StringReader;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.bouncycastle.util.encoders.Hex;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.opusconsulting.pegasus.flow.IStepInstance;
import com.opusconsulting.pegasus.flow.IStepInstanceCreator;
import com.opusconsulting.pegasus.flow.impl.DefaultFlowContext;
import com.opusconsulting.pegasus.flow.metadata.StepInstanceInfo;
import com.opusconsulting.pegasus.format.iso.metadata.EncodingType;
import com.opusconsulting.pegasus.format.iso.metadata.FieldDataType;
import com.opusconsulting.pegasus.format.iso.metadata.FieldSizeType;
import com.opusconsulting.pegasus.format.iso.metadata.ISOFieldMetaData;
import com.opusconsulting.pegasus.format.iso.metadata.ISOMessageDetail;
import com.opusconsulting.pegasus.format.iso.metadata.MessageKind;
import com.opusconsulting.pegasus.formula.ISOMessageCodeProvider;
import com.opusconsulting.pegasus.formula.codegen.CodeMetaData;
import com.opusconsulting.pegasus.formula.codegen.FormulaCodeInfo;
import com.opusconsulting.pegasus.formula.codegen.FunctionMetaData;
import com.opusconsulting.pegasus.formula.codegen.ParamMetaData;
import com.opusconsulting.pegasus.formula.codegen.impl.FormulaCodeGenerator;
import com.opusconsulting.pegasus.formula.compiler.JavaCodeCompiler;
import com.opusconsulting.pegasus.runtime.mapper.layman.MessageKey;

public class TestEngine {
	public static void main(String[] args) {
		try {

			ClassPathXmlApplicationContext mainApplicationContext = new ClassPathXmlApplicationContext(
					new String[] { "formula-spring.xml" }, true);

			AnnotationConfigApplicationContext applicationContext = new AnnotationConfigApplicationContext();
			applicationContext.register(StepConfiguration.class);
			applicationContext.setParent(mainApplicationContext);
			applicationContext.refresh();

			FormulaCodeGenerator formulaCodeGenerator = (FormulaCodeGenerator) mainApplicationContext
					.getBean("formulaCodeGenerator");
			JavaCodeCompiler compiler = (JavaCodeCompiler) mainApplicationContext.getBean(JavaCodeCompiler.class);

			final String json = readMetaDataJson();
			ObjectMapper mapper = new ObjectMapper();
			Map<String, Object> obj = mapper.readValue(new StringReader(json), Map.class);
			// Field Meta data
			List<ISOFieldMetaData> fieldMetaDatas = buildFieldMetaData(obj);
			// message meta data
			List<ISOMessageDetail> messageMetaDatas = buildMessageMetaData(obj);
			Map<String, ICondition> msgIdentificationsFoumulas = buildFormulas(messageMetaDatas, formulaCodeGenerator,
					compiler);

			IStepInstanceCreator stepInstanceCreator = (IStepInstanceCreator) applicationContext
					.getBean("stepInstanceCreator");
			DefaultFlowContext flowContext = new DefaultFlowContext(null, true);

			// De-Serialize step
			String inputHexString = "31323130f636ed01afe0ac002000000004003f303136343636373330303030303030303230303031303030303030303030303031303030303030303030303031303030303130303630393038323530303033333231323130303631343338323531333131313231303036313030363533313138343038343032303131303132303030303032303030363533313830343036353331383034323734363637333030303030303030323030443133313135323634353632323830303930303033333252353234373230303035323631303432383638323132333435363738202020202020203430446f6d696e6f7320202020202020202020202020202020484f5553542020202020202020205553413834303834303339303030303939303030303030333531393239313135333138303420202020313034323836383230303532303030303030303030303030303030323834304330303030303039383030303030303031383430443030303030303030303030303235313634363637333030303030303030323030303033383430303132303030303030303030303030303132303030303030303030303030303132303030303030303030303030303132303030303030303030303030303132303030303030303130303030303033485950303033504f53";
			byte[] input = hexStringToByteArray(inputHexString);

			Map<String, Object> isoDeserializerProps = new HashMap<>();
			isoDeserializerProps.put("fieldDetails", fieldMetaDatas);

			StepInstanceInfo deserializerStepInstanceInfo = new StepInstanceInfo().setName("ISODeserializer")
					.setStepName("ISODeserializer").setProperties(isoDeserializerProps);
			IStepInstance deserializerStepInstance = stepInstanceCreator.create(deserializerStepInstanceInfo);
			IMessage message = deserializerStepInstance.process(flowContext, input, null);

			Object val = message.getValue(new MessageKey("DE_53"));
			System.out.println("After De-Serialize : DE-53 : " + val);

			// Message Identification step
			Map<String, Object> messageIdentificationProps = new HashMap<>();
			messageIdentificationProps.put("formulas", msgIdentificationsFoumulas);
			messageIdentificationProps.put("computeEvenIfExists", true);

			StepInstanceInfo stepInstanceInfo = new StepInstanceInfo().setName("MessageIdentification")
					.setStepName("MessageIdentification").setProperties(messageIdentificationProps);

			IStepInstance instance = stepInstanceCreator.create(stepInstanceInfo);
			instance.process(flowContext, null, null);
			System.out.println((flowContext.get("MESSAGE_NAME")==null)?"Not found":flowContext.get("MESSAGE_NAME").toString());
			
			// Serialize step
			StepInstanceInfo serializerStepInstanceInfo = new StepInstanceInfo().setName("ISOSerializer")
					.setStepName("ISOSerializer").setProperties(isoDeserializerProps);
			IStepInstance serializerStepInstance = stepInstanceCreator.create(serializerStepInstanceInfo);
			byte[] messageBytes = serializerStepInstance.process(flowContext, message, null);
			System.out.println("After Serialize : " + new String(messageBytes));
		} catch (FileNotFoundException exception) {
			exception.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private static Map<String, ICondition> buildFormulas(List<ISOMessageDetail> messageMetaDatas,
			FormulaCodeGenerator formulaCodeGenerator, JavaCodeCompiler compiler) {
		final Map<String, ICondition> formulaConditions = new HashMap<>();
		messageMetaDatas.stream().forEach(messageDetail -> {
			try {
				ICondition iConditionObj = TestEngine
						.buildCondition(messageDetail.getMessageIdentificationFormula(), formulaCodeGenerator, compiler);
				if(iConditionObj != null)
					formulaConditions.put(messageDetail.getName(), iConditionObj);
			} catch (Exception e) {
				e.printStackTrace();
			}
		});
		return formulaConditions;
	}

	private static ICondition buildCondition(String formula, FormulaCodeGenerator formulaCodeGenerator,
			JavaCodeCompiler compiler) throws Exception {
		CodeMetaData codeMetaData = new CodeMetaData();
		codeMetaData.setPackageName("com.opusconsulting.pegasus.formula");
		codeMetaData.addImport("com.opusconsulting.pegasus.runtime.ICondition");
		codeMetaData.addImport("static com.opusconsulting.pegasus.formula.ExcelFunctions.*");
		codeMetaData.addImport("com.opusconsulting.pegasus.runtime.IMessage");
		codeMetaData.addImport("java.util.Map");
		codeMetaData.addImport("com.opusconsulting.pegasus.flow.IFlowContext");
		codeMetaData.setImplementClasses(Arrays.asList("ICondition"));

		FunctionMetaData functionMetaData = new FunctionMetaData();
		functionMetaData.setName("check");
		functionMetaData.setReturnType("boolean");
		functionMetaData.setParams(Arrays.asList(new ParamMetaData("request", "IMessage"),
				new ParamMetaData("ctx", "IFlowContext"), new ParamMetaData("tag", "Map<String, Object>")));
		codeMetaData.setCallFunctionMetaData(functionMetaData);
		if(formula == null)
			return null;
			
		FormulaCodeInfo formulaCodeInfo = formulaCodeGenerator.create(formula,
				codeMetaData, new ISOMessageCodeProvider("request"));
		formulaCodeInfo.getClassName();
		System.out.println(formulaCodeInfo.getCode());

		Class<Object> conditionClass = compiler.compile(formulaCodeInfo.getClassName(), formulaCodeInfo.getCode());
		return (ICondition) conditionClass.newInstance();
	}

	private static List<ISOMessageDetail> buildMessageMetaData(Map<String, Object> obj) {
		List<Object> messages = (List<Object>) obj.get("messages");
		return messages.stream().map(message -> {
			Map<String, Object> messageData = (LinkedHashMap<String, Object>) message;
			return new ISOMessageDetail((String) messageData.get("name"), (String) messageData.get("description"),
					MessageKind.valueOf((String) messageData.get("type")),
					(String) messageData.get("messageIdentification"));
		}).collect(Collectors.toList());
	}

	private static List<ISOFieldMetaData> buildFieldMetaData(Map<String, Object> obj) {
		List<Object> fields = (List) obj.get("fields");
		return fields.stream().map(field -> {
			Map<String, Object> fieldData = (LinkedHashMap<String, Object>) field;
			FieldSizeType fieldType = FieldSizeType.valueOf((String) fieldData.get("fieldType"));
			if (FieldSizeType.Fixed.equals(fieldType)) {
				return ISOFieldMetaData.fixed((String) fieldData.get("fieldname"),
						(String) fieldData.get("description"),
						FieldDataType.valueOf((String) fieldData.get("fieldDataType")),
						Integer.parseInt((String) fieldData.get("size")),
						EncodingType.valueOf((String) fieldData.get("encodingType")));
			} else if (FieldSizeType.Variable.equals(fieldType)) {
				return ISOFieldMetaData.variable((String) fieldData.get("fieldname"),
						(String) fieldData.get("description"),
						FieldDataType.valueOf((String) fieldData.get("fieldDataType")),
						EncodingType.valueOf((String) fieldData.get("encodingType")),
						Integer.parseInt((String) fieldData.get("size")),
						fieldData.get("lengthEncodingType") != null
								? EncodingType.valueOf((String) fieldData.get("lengthEncodingType"))
								: EncodingType.ASCII);
			}
			return null;
		}).collect(Collectors.toList());
	}

	private static String readMetaDataJson() throws FileNotFoundException, IOException {
		BufferedReader fileReader = new BufferedReader(
				new FileReader(new File("D:\\workspace\\poc\\pegasus-backend\\VISA_UPDATED.json")));
		final StringBuilder jsonBuilder = new StringBuilder();
		String jsonLine = fileReader.readLine();
		while (jsonLine != null) {
			jsonBuilder.append(jsonLine);
			jsonLine = fileReader.readLine();
		}
		final String json = jsonBuilder.toString();
		return json;
	}

	private static byte[] hexStringToByteArray(String s) {
		int len = s.length();
		byte[] data = new byte[len / 2];
		for (int i = 0; i < len; i += 2) {
			String hexValue = s.substring(i, i + 2);
			int decimal = Integer.parseInt(hexValue, 16);
			data[i / 2] = (byte) decimal;
		}
		return data;
	}

	private static String byteArrayToHexString(byte[] bytes) {
		return Hex.toHexString(bytes);
	}
}

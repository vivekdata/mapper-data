package com.opusconsulting.pegasus.formula;


import org.eclipse.xtext.util.Strings;

import java.util.Arrays;

public class ExcelFunctions {
    public static String CONCAT(String... vals) {
        return Strings.concat("", Arrays.asList(vals));
    }

    public static <T> Boolean EXACT(T lhs, T rhs) {
        return lhs.equals(rhs);
    }

    public static String STR(int val) {
        return String.valueOf(val);
    }
}

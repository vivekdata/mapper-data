package com.opusconsulting.pegasus.runtime;

import java.util.concurrent.CompletableFuture;

import io.netty.bootstrap.Bootstrap;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioSocketChannel;

public class TestClient {
	public static void main(String[] args) throws InterruptedException {
		EventLoopGroup group = new NioEventLoopGroup();
        try {
            Bootstrap b = new Bootstrap();
            b.group(group)
                    .channel(NioSocketChannel.class)
                    .handler(new ChannelInitializer<SocketChannel>() {

						@Override
						protected void initChannel(final SocketChannel ch) throws Exception {
							ch.pipeline().addLast(new SimpleChannelInboundHandler<ByteBuf>() {
								@Override
								protected void channelRead0(ChannelHandlerContext ctx, ByteBuf msg) throws Exception {
									 byte[] data = new byte[msg.readableBytes()];
							         msg.readBytes(data);
									 System.out.println("Message To Client: " + new String(data));
									 ctx.channel().writeAndFlush(Unpooled.copiedBuffer("Hello Server".getBytes())).addListener(future -> {
										 if(future.awaitUninterruptibly().isDone()) {
											 System.out.println("Sent from client.");
											 Throwable error = future.cause();
											 if(error != null) {
												 error.printStackTrace();
											 }
										 }
									 });
								}
							});
						}
					});

            ChannelFuture channelFuture = b.connect("localhost", 6000).sync();

            CompletableFuture<Boolean> result = new CompletableFuture<>();
            channelFuture.addListener(future -> {
                result.complete(true);
            });
            channelFuture.channel().closeFuture().sync();
        } finally {
        }

	}
}

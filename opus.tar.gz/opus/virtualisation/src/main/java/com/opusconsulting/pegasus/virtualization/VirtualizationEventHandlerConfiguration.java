package com.opusconsulting.pegasus.virtualization;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.opusconsulting.pegasus.common.event.IEventConsumer;
import com.opusconsulting.pegasus.common.event.IEventPublisher;
import com.opusconsulting.pegasus.event.impl.EventManager;
import com.opusconsulting.pegasus.virtualization.event.VirtualizationEventSubjects;
import com.opusconsulting.pegasus.virtualization.event.handlers.MapperHostCommunicationEventHandler;
import com.opusconsulting.pegasus.virtualization.event.handlers.ProcessVirtualMessageBufferEventHandler;
import com.opusconsulting.pegasus.virtualization.event.handlers.SampleMsgFeedEventHandler;
import com.opusconsulting.pegasus.virtualization.event.handlers.StartVirtualServerEventHandler;
import com.opusconsulting.pegasus.virtualization.event.handlers.VirtualizationStartupActivityEventHandler;

@Configuration
public class VirtualizationEventHandlerConfiguration {
	@Autowired
	EventManager eventManager;

	@Bean(name={"startVirtualServerEventPublisher"})
	public IEventPublisher createStartServerEventPublisher(StartVirtualServerEventHandler startVirtualServerEventHandler) {
		return eventManager.createPublisher(VirtualizationEventSubjects.VIRTUALIZATION_BOOT.name(), startVirtualServerEventHandler);
	}

	@Bean(name={"startVirtualServerEventConsumer"})
	public IEventConsumer createStartServerEventConsumer(StartVirtualServerEventHandler startVirtualServerEventHandler) {
		return eventManager.createConsumer(VirtualizationEventSubjects.VIRTUALIZATION_BOOT.name(), startVirtualServerEventHandler);
	}
	
	@Bean(name={"vitualEnvStartupActivityEventPublisher"})
	public IEventPublisher createEnvStartupActivityEventPublisher(VirtualizationStartupActivityEventHandler vitualEnvStartupActivityEventHandler) {
		return eventManager.createPublisher(VirtualizationEventSubjects.VIRTUALIZATION_STARTUP_ACTIVITY.name(), vitualEnvStartupActivityEventHandler);
	}

	@Bean(name={"vitualEnvStartupActivityEventConsumer"})
	public IEventConsumer createEnvStartupActivityEventConsumer(VirtualizationStartupActivityEventHandler vitualEnvStartupActivityEventHandler) {
		return eventManager.createConsumer(VirtualizationEventSubjects.VIRTUALIZATION_STARTUP_ACTIVITY.name(), vitualEnvStartupActivityEventHandler);
	}
	
	@Bean(name={"processVirtualMessageEventPublisher"})
	public IEventPublisher createProcessMessageEventPublisher(ProcessVirtualMessageBufferEventHandler processVirtualMessageBufferEventHandler) {
		return eventManager.createPublisher(VirtualizationEventSubjects.PROCESS_VIRTUAL_BUFFER.name(), processVirtualMessageBufferEventHandler);
	}

	@Bean(name={"processVirtualMessageEventConsumer"})
	public IEventConsumer createProcessMessageEventConsumer(ProcessVirtualMessageBufferEventHandler processVirtualMessageBufferEventHandler) {
		return eventManager.createConsumer(VirtualizationEventSubjects.PROCESS_VIRTUAL_BUFFER.name(), processVirtualMessageBufferEventHandler);
	}
	
	@Bean(name={"virtualHostCommunicationEventPublisher"})
	public IEventPublisher createVirtualHostCommunicationEventPublisher(MapperHostCommunicationEventHandler hostCommunicationEventHandler) {
		return eventManager.createPublisher(VirtualizationEventSubjects.VIRTUAL_HOST_COMMUNICATION.name(), hostCommunicationEventHandler);
	}

	@Bean(name={"virtualHostCommunicationEventConsumer"})
	public IEventConsumer createVirtualHostCommunicationEventConsumer(MapperHostCommunicationEventHandler hostCommunicationEventHandler) {
		return eventManager.createConsumer(VirtualizationEventSubjects.VIRTUAL_HOST_COMMUNICATION.name(), hostCommunicationEventHandler);
	}
	
	@Bean(name={"virtualSampleMsgFeedProcessEventPublisher"})
	public IEventPublisher createVirtualSampleMsgFeedProcessEventPublisher(SampleMsgFeedEventHandler sampleMsgFeedEventHandler) {
		return eventManager.createPublisher(VirtualizationEventSubjects.VIRTUAL_SAMPLE_FEED.name(), sampleMsgFeedEventHandler);
	}

	@Bean(name={"virtualSampleMsgFeedProcessEventConsumer"})
	public IEventConsumer createVirtualSampleMsgFeedProcessEventConsumer(SampleMsgFeedEventHandler sampleMsgFeedEventHandler) {
		return eventManager.createConsumer(VirtualizationEventSubjects.VIRTUAL_SAMPLE_FEED.name(), sampleMsgFeedEventHandler);
	}
}

package com.opusconsulting.pegasus.virtualization.rules;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class RuleMetaDataFactory {

	@Autowired(required = false)
    List<IRuleMetaData> preDefinedMetaDatas;

    Map<String, IRuleMetaData> metaDatas = new HashMap<>();

    @PostConstruct
    void init() {
        if (preDefinedMetaDatas != null) {
            preDefinedMetaDatas.forEach(metaData -> metaDatas.put(metaData.getName(), metaData));
        }
    }

    public void register(IRuleMetaData metaData) {
        metaDatas.put(metaData.getName(), metaData);
    }

	public IRuleMetaData getRuleMetaData(String ruleName) {
		return metaDatas.get(ruleName);
	}

}

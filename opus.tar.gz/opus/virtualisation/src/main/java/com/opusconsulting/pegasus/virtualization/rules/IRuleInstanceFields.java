package com.opusconsulting.pegasus.virtualization.rules;

public interface IRuleInstanceFields {
	String FIELD_DECISION_FIELD_NAME_PROP = "fieldName";
	String FIELD_DECISION_ACTION_PROP = "action";
	String FIELD_DECISION_FIELD_VALUE_PROP = "fieldValueProvider";
	String DELAYED_RESPONSE_DELAY_PROP = "delay";
	String CONDITION_BASED_CONDITION_PROP = "condition";
	String MESSAGE_META_DATA_DECISION_MESSAGE_NAME_PROP = "messageName";
	String MESSAGE_META_DATA_DECISION_IS_REQUEST_PROP = "request";
	
}

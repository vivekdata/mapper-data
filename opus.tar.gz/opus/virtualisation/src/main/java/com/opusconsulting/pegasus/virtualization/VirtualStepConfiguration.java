package com.opusconsulting.pegasus.virtualization;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.opusconsulting.pegasus.flow.metadata.IStepMetaData;
import com.opusconsulting.pegasus.flow.metadata.impl.StepMetaData;

@Configuration
public class VirtualStepConfiguration {

    @Bean
    public static IStepMetaData createVitualizationStepMetaData() {
        return new StepMetaData().setName("VirtualRuleExecutor").setType(VirtualizationTreeRuleExecutionStep.class);
    }
}

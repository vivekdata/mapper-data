package com.opusconsulting.pegasus.virtualization.rules.impl;

import java.util.List;
import java.util.Map;

import com.opusconsulting.pegasus.virtualization.rules.IRuleInstance;

public class NoResponseRule extends AbstractTreeRuleInstance {

	public NoResponseRule(List<IRuleInstance> childRules, IRuleInstance nextInstance) {
		super(childRules, nextInstance);
	}

	@Override
	public <I> boolean execute(I result, Map<String, Object> ruleProps) {
		result = null;//TODO need to think how to make the IMessage to null so
						// serializer will not send the byte[]
		return false;
	}

}

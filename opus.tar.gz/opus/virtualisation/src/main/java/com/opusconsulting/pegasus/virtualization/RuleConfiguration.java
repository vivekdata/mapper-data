package com.opusconsulting.pegasus.virtualization;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.opusconsulting.pegasus.format.iso.metadata.VirtualizationRuleType;
import com.opusconsulting.pegasus.virtualization.rules.IRuleMetaData;
import com.opusconsulting.pegasus.virtualization.rules.RuleMetaData;
import com.opusconsulting.pegasus.virtualization.rules.impl.ConditionBasedResponseRule;
import com.opusconsulting.pegasus.virtualization.rules.impl.DelayedResponseRule;
import com.opusconsulting.pegasus.virtualization.rules.impl.FieldDecisionRule;
import com.opusconsulting.pegasus.virtualization.rules.impl.MessageMetaDataDecisionRule;
import com.opusconsulting.pegasus.virtualization.rules.impl.NoResponseRule;
import com.opusconsulting.pegasus.virtualization.rules.impl.SendResponseRule;

@Configuration
public class RuleConfiguration {

    @Bean
    public static IRuleMetaData createAddFieldRule() {
        return new RuleMetaData().setName(VirtualizationRuleType.ADD_FIELD.getRuleType()).setType(FieldDecisionRule.class);
    }
    
    @Bean
    public static IRuleMetaData createModifyFieldRule() {
        return new RuleMetaData().setName(VirtualizationRuleType.MODIFY_FIELD.getRuleType()).setType(FieldDecisionRule.class);
    }
    
    @Bean
    public static IRuleMetaData createRemoveFieldRule() {
        return new RuleMetaData().setName(VirtualizationRuleType.REMOVE_FIELD.getRuleType()).setType(FieldDecisionRule.class);
    }

    @Bean
    public static IRuleMetaData createDelayedRule() {
        return new RuleMetaData().setName(VirtualizationRuleType.DELAY_RESPONSE.getRuleType()).setType(DelayedResponseRule.class);
    }
    
    @Bean
    public static IRuleMetaData createConditionBasedRule() {
        return new RuleMetaData().setName(VirtualizationRuleType.CONDITION_BASED.getRuleType()).setType(ConditionBasedResponseRule.class);
    }
    
    @Bean
    public static IRuleMetaData createSendResponseRule() {
        return new RuleMetaData().setName(VirtualizationRuleType.SEND_RESPONSE.getRuleType()).setType(SendResponseRule.class);
    }
    
    @Bean
    public static IRuleMetaData createNoResponseRule() {
        return new RuleMetaData().setName(VirtualizationRuleType.NO_RESPONSE.getRuleType()).setType(NoResponseRule.class);
    }
    
    @Bean
	public static IRuleMetaData createMessageMetaDataDecisionRule() {
		return new RuleMetaData().setName(VirtualizationRuleType.MESSAGE_META_DATA_DECISION.getRuleType())
				.setType(MessageMetaDataDecisionRule.class);
	}
}

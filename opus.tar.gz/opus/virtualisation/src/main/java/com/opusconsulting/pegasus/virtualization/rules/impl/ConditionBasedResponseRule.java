package com.opusconsulting.pegasus.virtualization.rules.impl;

import java.util.List;
import java.util.Map;

import com.opusconsulting.pegasus.runtime.ICondition;
import com.opusconsulting.pegasus.runtime.IMessage;
import com.opusconsulting.pegasus.virtualization.rules.IRuleInstance;

public class ConditionBasedResponseRule extends AbstractTreeRuleInstance {

	ICondition condition;
	
	public ConditionBasedResponseRule(List<IRuleInstance> childRules, IRuleInstance nextInstance) {
		super(childRules, nextInstance);
	}

	@Override
	public <I> boolean execute(I result, Map<String, Object> ruleProps) {
		return condition.check((IMessage)result, null, null);
	}

	public void setCondition(ICondition condition) {
		this.condition = condition;
	}
}

package com.opusconsulting.pegasus.virtualization.rules.impl;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import com.opusconsulting.pegasus.runtime.DefaultIMessage;
import com.opusconsulting.pegasus.runtime.IMessage;
import com.opusconsulting.pegasus.runtime.IValueProvider;
import com.opusconsulting.pegasus.runtime.mapper.layman.IKey;
import com.opusconsulting.pegasus.runtime.mapper.layman.MessageKey;
import com.opusconsulting.pegasus.virtualization.rules.IRuleInstance;

public class FieldDecisionRule extends AbstractTreeRuleInstance {
	public static final String ADD_ACTION = "A";
	public static final String MODIFY_ACTION = "M";
	public static final String REMOVE_ACTION = "D";
	
	String fieldName;
	IValueProvider fieldValueProvider;
	String action;//A - ADD, M - MODIFY, R- REMOVE
	
	public FieldDecisionRule(List<IRuleInstance> childRules, IRuleInstance nextInstance) {
		super(childRules, nextInstance);
	}
	
	@Override
	public <I> boolean execute(I result, Map<String, Object> ruleProps) {
		final DefaultIMessage message = (DefaultIMessage)result;
		if(ADD_ACTION.equalsIgnoreCase(action)){
			setCompositeValue(message);
		} else if(MODIFY_ACTION.equalsIgnoreCase(action)){
			Object fieldValue = getCompositeValue(message);
			if(fieldValue != null)
				setCompositeValue(message);
		} else if(REMOVE_ACTION.equalsIgnoreCase(action)){
			removeCompositeValue(message);
		}
		return true;
	}
	
	private void removeCompositeValue(IMessage message){
		removeCompositeValue(Arrays.asList(this.fieldName.split("\\.")), 0, message);
	}
	
	private void removeCompositeValue(List<String> fields, int index, IMessage message){
		if(message == null) return;
		if(index == (fields.size()-1)){
			message.setValue(new MessageKey(fields.get(index)), null);
		} else {
			final IMessage innerMessage = message.getValue(new MessageKey(fields.get(index)));
			index++;
			removeCompositeValue(fields, index, innerMessage);
		}
	}
	
	private void setCompositeValue(IMessage message){
		Object fieldValue = fieldValueProvider.get(message, null, null);
		setCompositeValue(Arrays.asList(this.fieldName.split("\\.")), 0, message, fieldValue);
	}
	
	private void setCompositeValue(List<String> fields, int index, IMessage message, Object fieldValue){
		if(index == (fields.size()-1)){
			message.setValue(new MessageKey(fields.get(index)), fieldValue);;
		} else {
			final IKey fieldKey = new MessageKey(fields.get(index));
			IMessage innerMessage = message.getValue(fieldKey);
			index++;
			if(innerMessage == null){
				innerMessage = new DefaultIMessage(message.getNodeMetaData());
				message.setValue(fieldKey, innerMessage);
			}
			setCompositeValue(fields, index, innerMessage, fieldValue);
		}
	}
	
	private Object getCompositeValue(IMessage message){
		if (this.fieldName == null) return null;
		return getCompositeValue(Arrays.asList(this.fieldName.split("\\.")), 0, message);
	}
	
	private Object getCompositeValue(List<String> fields, int index, IMessage message){
		if(index == (fields.size()-1)){
			return message.getValue(new MessageKey(fields.get(index)));
		} else {
			final IMessage innerMessage = message.getValue(new MessageKey(fields.get(index)));
			index++;
			return getCompositeValue(fields, index, innerMessage);
		}
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public void setFieldValueProvider(IValueProvider fieldValueProvider) {
		this.fieldValueProvider = fieldValueProvider;
	}

	public void setAction(String action) {
		this.action = action;
	}
}

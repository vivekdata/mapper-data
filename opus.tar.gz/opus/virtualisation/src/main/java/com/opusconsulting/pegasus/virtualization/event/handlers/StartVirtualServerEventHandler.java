package com.opusconsulting.pegasus.virtualization.event.handlers;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import com.opusconsulting.pegasus.channel.eventbus.EventBusConfig;
import com.opusconsulting.pegasus.channel.eventbus.EventBusConsumerChannel;
import com.opusconsulting.pegasus.channel.http.HttpChannelMessage;
import com.opusconsulting.pegasus.channel.http.HttpServerChannel;
import com.opusconsulting.pegasus.channel.http.HttpServerChannelConfig;
import com.opusconsulting.pegasus.channel.http.HttpServerChannelConfig.HttpUrlInfo;
import com.opusconsulting.pegasus.channel.http.handler.HttpChannelHandler.HttpMethodType;
import com.opusconsulting.pegasus.channel.tcp.TCPChannelMessage;
import com.opusconsulting.pegasus.channel.tcp.TCPServerChannel;
import com.opusconsulting.pegasus.channel.tcp.TCPServerConfig;
import com.opusconsulting.pegasus.common.channel.IChannel;
import com.opusconsulting.pegasus.common.channel.IChannelEvent;
import com.opusconsulting.pegasus.common.event.IEventContext;
import com.opusconsulting.pegasus.common.event.IEventHandler;
import com.opusconsulting.pegasus.common.event.IEventMessage;
import com.opusconsulting.pegasus.common.event.IEventPublisher;
import com.opusconsulting.pegasus.event.impl.EventContext;
import com.opusconsulting.pegasus.event.impl.EventMessage;
import com.opusconsulting.pegasus.format.iso.metadata.EndPointDetail;
import com.opusconsulting.pegasus.format.iso.metadata.EndPointType;
import com.opusconsulting.pegasus.format.iso.metadata.EndpointProtocol;
import com.opusconsulting.pegasus.format.iso.metadata.EventbusEndPointDetails;
import com.opusconsulting.pegasus.format.iso.metadata.HttpEndPointDetail;
import com.opusconsulting.pegasus.format.iso.metadata.HttpEndPointDetail.EndPoint;
import com.opusconsulting.pegasus.runtime.IConstants;

import ch.qos.logback.core.Context;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelHandlerContext;
import io.vertx.core.Vertx;
import io.vertx.core.buffer.Buffer;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.web.RoutingContext;

@Component
public class StartVirtualServerEventHandler implements IEventHandler {
	private static final Logger _logger = LoggerFactory.getLogger(StartVirtualServerEventHandler.class);
	private static final String VIRTUAL_SERVER_TO_RECEIVE_SAMPLE_FEED_NODE = "sample_feed_node";

	private List<IChannel<?, ?>> serverChannels = new ArrayList<>();
	
	@Inject
	@Lazy
	IEventPublisher processVirtualMessageEventPublisher;
	
	@Inject
	@Lazy
	IEventPublisher virtualSampleMsgFeedProcessEventPublisher;
	
	@Lazy
	@Inject
	List<EndPointDetail> endpoints;
	
	@Autowired
	private Vertx vertx;
	
	@Override
	public void handle(IEventMessage eventMessage, IEventContext context) {
		if("START".equalsIgnoreCase(eventMessage.getData())){//this is consumer part
			boolean serverStarted = startServer(context);
			if(serverStarted){
				replyToInitiator("SERVER_STARTED", context, true);
			} else {
				if(this.serverChannels != null){
					this.serverChannels.stream().forEach(serverChannel -> {
						try {
							serverChannel.stop();
						} catch (Exception e) {
							if(serverChannel.getClass().isAssignableFrom(TCPServerChannel.class)){
								TCPServerChannel tcpServerChannel = (TCPServerChannel)serverChannel;
								_logger.error(
										"Virtual Server failed to sthut down. Server was started on {} at port {}.",
										tcpServerChannel.getConfig().getBindAddress(),
										tcpServerChannel.getConfig().getPort(), e);
							} else if(serverChannel.getClass().isAssignableFrom(HttpServerChannel.class)){
								HttpServerChannel httpServerChannel = (HttpServerChannel)serverChannel;
								_logger.error(
										"Virtual Server failed to sthut down. Server was started on {} at port {} and Base path : {}.",
										httpServerChannel.getConfig().getHostName(),
										httpServerChannel.getConfig().getPort(),
										httpServerChannel.getConfig().getBasePath(), e);
							} 
						}
					});
				}
				replyToInitiator("SERVER_STARTED_FAILED", context, false);
			}
		} else if("START_VIRTUALIZER_TO_RECEIVE_SAMPLE_FEED".equalsIgnoreCase(eventMessage.getData())){
			boolean serverStarted = startVirtualServer(context);
			if(serverStarted){
				_logger.info("Virtual Server started successfully to receive the sample message feed for testing.");
			} else {
				_logger.error("Virtual Server (to receive the sample message feed for testing) start failed.");
			}
		}else if ("RESPOND_TO_SERVER".equalsIgnoreCase(eventMessage.getData())) {
			final String nodeName = context.get(IConstants.EVENT_CTX_SOURCE_NODE_NAME_KEY);
			final byte[] responseMessageBytes = context.get(IConstants.EVENT_CTX_SERIALIZED_RESPONSE_BUFFER);
			endpoints.stream().filter(endpoint -> {
				return endpoint.getNodeName().equalsIgnoreCase(nodeName);
			}).forEach((endpoint -> {
				if (EndpointProtocol.TCP.equals(endpoint.getProtocol())) {
					final ChannelHandlerContext ctx = context.get(IConstants.EVENT_CTX_CHANNEL_CONTEXT);
					ByteBuf response = Unpooled.buffer(1024);
					response.writeBytes(responseMessageBytes);
					ctx.channel().writeAndFlush(response);
					System.out.println("Response sent back:" + new String(responseMessageBytes));
				} else {
					if (EndpointProtocol.HTTP.equals(endpoint.getProtocol())) {
						final RoutingContext ctx = context.get(IConstants.EVENT_CTX_CHANNEL_CONTEXT);
						Buffer responseMessage = Buffer.buffer(responseMessageBytes);
						ctx.response().setChunked(true).write(responseMessage).end();
						System.out.println("Response sent back:" + new String(responseMessageBytes));
					}
				}
			}));
		}
	}
	
	private boolean startVirtualServer(IEventContext context) {
		Optional<EndPointDetail> virtualSampleFeedEndpointOptional = endpoints.stream().filter(endpoint -> {
			return (EndPointType.EVENTBUS.equals(endpoint.getType()) 
					&& VIRTUAL_SERVER_TO_RECEIVE_SAMPLE_FEED_NODE.equalsIgnoreCase(endpoint.getNodeName()));
		}).findFirst();
		if(virtualSampleFeedEndpointOptional.isPresent()){
			final EventbusEndPointDetails sampleFeedEndpoint = (EventbusEndPointDetails) virtualSampleFeedEndpointOptional.get();
			return startVirtualServer(sampleFeedEndpoint);
		} else {
			_logger.error("No node configured to receive the sample message feed for the HOST type nodes. Please contact administrator.");
			return false;
		}
	}

	private boolean startVirtualServer(EventbusEndPointDetails sampleFeedEndpoint) {
		
		String address = sampleFeedEndpoint.getAddress();
		int port = sampleFeedEndpoint.getPort();
		String inboundAddress = sampleFeedEndpoint.getInboundAddress();
		String outboundAddress = sampleFeedEndpoint.getOutboundAddress();
		
		EventBusConfig eventBusConfig = new EventBusConfig();
		eventBusConfig.setHostName(address);
		eventBusConfig.setPort(port);
		eventBusConfig.setInboundAddress(inboundAddress);
		eventBusConfig.setOutboundAddress(outboundAddress);
		eventBusConfig.setPublisher(false);

		EventBusConsumerChannel<JsonObject> eventBusConsumerChannel = new EventBusConsumerChannel<JsonObject>(eventBusConfig,
				(type, message, additionalInfo) -> {
					EventContext context = new EventContext();
					context.set(IConstants.SERVER_MSG_PROTOCOL_CTX, message.getProtocolContext());
					context.set(SampleMsgFeedEventHandler.JSON_REQ_BUFFER_CTX_PARAM_KEY, message.getData());
					System.out.println("message received in the virtual server handler.");
					virtualSampleMsgFeedProcessEventPublisher.publish("PROCESS_FEED", context);
				});
		try {
			_logger.debug("Starting eventbus for communicating the sample message send-receive...");
			eventBusConsumerChannel.start();
		} catch (Exception e) {
			_logger.error("Failed to start the event bus for sample message feed. Please contact administrator.");
		}
		return true;
	}

	private boolean startServer(IEventContext context) {
		endpoints.stream().filter(endpoint -> {
			return EndPointType.CLIENT.equals(endpoint.getType());
		}).forEach((endpoint -> {
			if(EndpointProtocol.TCP.equals(endpoint.getProtocol())){
				startTCPServer(endpoint.getAddress(), endpoint.getPort(), endpoint.getNodeName());
			} else if(EndpointProtocol.HTTP.equals(endpoint.getProtocol())){
				startHttpServer(endpoint);
			}
		}));
		return true;
	}
	
	private boolean startTCPServer(String address, int port, String nodeName) {
		TCPServerConfig config = new TCPServerConfig().setPort(port);
        TCPServerChannel serverChannel = new TCPServerChannel(config);
        serverChannel.setEventHandler(new TCPServerChannelEventHandler(nodeName));
        try {
			CompletableFuture<Boolean> startServerResult = serverChannel.start();
			serverChannels.add(serverChannel);
			return startServerResult.get();
		} catch (Exception e) {
			_logger.error("Error while starting virtualization TCP server", e );
			return false;
		}
	}

	private void replyToInitiator(String message, IEventContext context, boolean success) {
        EventMessage originalMessage = context.get(ORI_REQUEST_CTX_KEY);
        EventContext replyContext = new EventContext();
        replyContext.set("endPoints", context.get("endPoints"));
        originalMessage.reply(message, success);
    }
	
	private class TCPServerChannelEventHandler implements IChannelEvent<TCPChannelMessage>{
		private String nodeName;
		
		public TCPServerChannelEventHandler(String nodeName) {
			super();
			this.nodeName = nodeName;
		}

		@Override
		public void onEvent(String type, TCPChannelMessage message, Object additionalInfo) {
            //TODO need to think
        	EventContext context = new EventContext();
        	context.set(IConstants.EVENT_CTX_SOURCE_NODE_NAME_KEY, this.nodeName);//TODO need to get it from runtime or configuration
        	context.set(IConstants.SERVER_MSG_PROTOCOL_CTX, message.getProtocolContext());
        	System.out.println("Reqeust receivevd:" + new String(message.getData()));
        	processVirtualMessageEventPublisher.publish(message.getData(), context);
        }
	}
	
	
	
	private class HttpServerChannelEventHandler implements IChannelEvent<HttpChannelMessage>{
		private HttpEndPointDetail httpEndPoint;

		public HttpServerChannelEventHandler(HttpEndPointDetail httpEndPoint) {
			super();
			this.httpEndPoint = httpEndPoint;
		}

		@Override
		public void onEvent(String type,HttpChannelMessage message, Object additionalInfo) {
			//get the HttpMethodType
			HttpMethodType httpMethodType = HttpMethodType.valueOf(type);
			EventContext context = new EventContext();
        	context.set(IConstants.EVENT_CTX_SOURCE_NODE_NAME_KEY, this.httpEndPoint.getNodeName());//TODO need to get it from runtime or configuration
        	context.set(IConstants.SERVER_MSG_PROTOCOL_CTX, message.getProtocolContext());
			
				switch (httpMethodType) {
				case GET:
					handleGetAndDeleteRequest(message, context);	
		        	break;
				case POST:
						System.out.println("Reqeust receivevd:" + message.getData().getBytes());
			        	processVirtualMessageEventPublisher.publish(message.getData().getBytes(), context);
					break;
				case PUT:
					System.out.println("Reqeust receivevd:" + message.getData().getBytes());
		        	processVirtualMessageEventPublisher.publish(message.getData().getBytes(), context);
					break;
				case DELETE:
					handleGetAndDeleteRequest(message, context);	
		        	break;
				default:
					break;
				}
        	
       
        }
	}
	
	private void handleGetAndDeleteRequest(HttpChannelMessage message, EventContext context) {
		//context.set(IConstants.EVENT_CTX_SOURCE_NODE_NAME_KEY, sourceNode);
		context.set(IConstants.SERVER_MSG_PROTOCOL_CTX, message.getProtocolContext());
		// loading the context with message props
		message.getProps().entrySet().stream().forEach(entry -> {
			context.set(entry.getKey(), entry.getValue());
		});
		context.set(IConstants.IS_REQUEST_PARAM_DESERIALIZE_SERIALIZE_REQUIRED,true);
		context.set(IConstants.IS_HTTP_REQUEST_MESSAGE_PROPS_KEY, true);
		context.set(IConstants.HTTP_MESSAGE_NAME_PROPS_KEY,
				message.getProps().get(IConstants.HTTP_MESSAGE_NAME_PROPS_KEY));

		context.set(IConstants.HTTP_REQUEST_PARAM_FIELDS_KEY, message.getProps().get(IConstants.HTTP_REQUEST_PARAM_FIELDS_KEY));
		_logger.debug("Request received on the Client Server. Process event published for same.");
		processVirtualMessageEventPublisher.publish(null, context);
	}
	
	@SuppressWarnings("unchecked")
	private void startHttpServer(EndPointDetail endpoint) {
		if(!endpoint.getClass().isAssignableFrom(HttpEndPointDetail.class)){
			_logger.error("Invalid endpoint details provided for the HTTP server start up. The endpoint should be of type HttpEndPointDetail.");
			return;
		}
		HttpEndPointDetail httpEndPoint = (HttpEndPointDetail)endpoint;
    	
    	final HttpServerChannelConfig config = new HttpServerChannelConfig();
    	config.setHostName(httpEndPoint.getAddress());
    	config.setPort(endpoint.getPort());
		//config.setContentType(HttpContentType.JSON);
    	config.setUrlInfos((List<HttpUrlInfo>) httpEndPoint.getHttpEndPoints().stream().map(httpEndPointInfo -> {
			return config.new HttpUrlInfo(httpEndPointInfo.getUrl(), httpEndPointInfo.getMessageName(),
					httpEndPointInfo.getMethod());
		}).collect(Collectors.toList()));
    	HttpServerChannel serverChannel = new HttpServerChannel(vertx, config);
    	serverChannel.setEventHandler(new HttpServerChannelEventHandler(httpEndPoint));
		
		try {
			CompletableFuture<Boolean> startServerResult = serverChannel.start();
			serverChannels.add(serverChannel);
			_logger.info("Host Server started successfully. Host listening on IP: {}, Port: {}", endpoint.getAddress(), endpoint.getPort());
		} catch (Exception e) {
			_logger.error("Error while starting host server.", e);
		}
	}
}

package com.opusconsulting.pegasus.virtualization;

import java.util.List;
import java.util.Map;

import com.opusconsulting.pegasus.flow.IFlowContext;
import com.opusconsulting.pegasus.flow.impl.AbstractStepInstance;
import com.opusconsulting.pegasus.runtime.IConstants;
import com.opusconsulting.pegasus.runtime.IMessage;
import com.opusconsulting.pegasus.virtualization.rules.IRuleInstance;

public class VirtualizationTreeRuleExecutionStep extends AbstractStepInstance {

	Map<String, List<IRuleInstance>> ruleInstances;//key is Node name, value is list of instances
	
	@Override
	public <I, R> R process(IFlowContext context, I previousStepResult, Map<String, Object> flowProps) {
		if(previousStepResult == null){
			//TODO
			return null;
		}
		if(!(previousStepResult instanceof IMessage)){
			//TODO
			return (R)previousStepResult;
		}
		final IMessage message = (IMessage)previousStepResult;
		
		//get the node name from the flow properties
		final String nodeName = (String)flowProps.get(IConstants.FLOW_PROPS_NODE_NAME_KEY);
		
		List<IRuleInstance> ruleInstanceList = ruleInstances.get(nodeName);
		
		if (ruleInstanceList != null) {
			ruleInstanceList.stream().forEach(ruleInstance -> {
				doProcess(message, flowProps, ruleInstance);
			});
		}
//		R result = doProcess(message, flowProps, rootRuleInstance);
		flowProps.put(IConstants.FLOW_PROPS_TRANSFORMED_REQUEST_KEY, message);
		return (R) message;
	}
	
	private <I, R> R doProcess(IMessage message, Map<String, Object> props, IRuleInstance ruleInstance){
		if(ruleInstance == null){
			return (R) message;
		}
		boolean canMoveToNext = ruleInstance.execute(message, props);
		if(canMoveToNext){
			for (IRuleInstance childRuleInstance : ruleInstance.getChildRules()) {
				doProcess(message, props, childRuleInstance);
			}
			return doProcess(message, props, ruleInstance.nextRule());
		}
		return (R) message;
	}

	public void setRuleInstances(Map<String, List<IRuleInstance>> ruleInstances) {
		this.ruleInstances = ruleInstances;
	}
}

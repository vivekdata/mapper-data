package com.opusconsulting.pegasus.virtualization.event.handlers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import com.opusconsulting.pegasus.common.event.IEventContext;
import com.opusconsulting.pegasus.common.event.IEventHandler;
import com.opusconsulting.pegasus.common.event.IEventMessage;
import com.opusconsulting.pegasus.common.event.IEventPublisher;
import com.opusconsulting.pegasus.common.event.IReplyEventContext;
import com.opusconsulting.pegasus.event.impl.EventContext;
import com.opusconsulting.pegasus.flow.IFlowInstance;
import com.opusconsulting.pegasus.flow.impl.FlowFactory;
import com.opusconsulting.pegasus.format.NodeFormat;
import com.opusconsulting.pegasus.format.iso.metadata.EndPointDetail;
import com.opusconsulting.pegasus.runtime.DefaultIMessage;
import com.opusconsulting.pegasus.runtime.IConstants;
import com.opusconsulting.pegasus.runtime.IMessage;
import com.opusconsulting.pegasus.runtime.flow.AbstractIWorkflow;
import com.opusconsulting.pegasus.runtime.flow.IWorkflow;
import com.opusconsulting.pegasus.runtime.mapper.layman.IMessageMetaData;
import com.opusconsulting.pegasus.runtime.mapper.layman.IMessageMetaDataImpl;
import com.opusconsulting.pegasus.runtime.mapper.layman.INodeMetaData;
import com.opusconsulting.pegasus.runtime.mapper.layman.NodeMetaData;

import io.vertx.core.buffer.Buffer;
import io.vertx.core.eventbus.Message;
import io.vertx.core.json.JsonObject;

@Component
public class SampleMsgFeedEventHandler implements IEventHandler {

	public static final String JSON_REQ_BUFFER_CTX_PARAM_KEY = "jsonBuffer";
	private static final Logger _logger = LoggerFactory.getLogger(SampleMsgFeedEventHandler.class);
	private static final String NODE_NAME_SAMPLE_FEED_JSON_KEY = "nodeName";
	private static final String MESSAGE_NAME_SAMPLE_FEED_JSON_KEY = "messageName";
	private static final String MESSAGE_TYPE_SAMPLE_FEED_JSON_KEY = "request";
	private static final String NODE_FORMAT_SAMPLE_FEED_JSON_KEY = "format";
	private static final String MESSAGE_BODY_SAMPLE_FEED_JSON_KEY = "messageBody";
	private static final String MESSAGE_REQUEST_SAMPLE_FEED_JSON_KEY = "requestBody";
	
	@Lazy
	@Inject
	IEventPublisher virtualHostCommunicationEventPublisher;
	
	@Inject
	FlowFactory flowFactory;
	
	@Lazy
	@Autowired
	List<EndPointDetail> endpoints;
	
	@Override
	public void handle(IEventMessage eventMessage, IEventContext context) {
		if(eventMessage.isReply()){
			handleResponse(eventMessage, context);
		} else {
			handleRequest(context, eventMessage);
		}
	}

	private void handleResponse(IEventMessage eventMessage, IEventContext context) {
		if("HOST_RESPONSE".equalsIgnoreCase(eventMessage.getData())){
			//get the node format
			NodeFormat format = context.get(IConstants.EVENT_CTX_NODE_FORMAT);
			//get the response bytes
			byte[] messageBuffer = context.get(MapperHostCommunicationEventHandler.RESPONSE_BUFFER);
			JsonObject jsonRespnse = null;
			if(NodeFormat.ISO87.equals(format) || NodeFormat.ISO93.equals(format)){
				jsonRespnse = handleIsoSampleFeedsResponse(messageBuffer, context);
			} else {
				jsonRespnse = new JsonObject();
				jsonRespnse.put(MESSAGE_BODY_SAMPLE_FEED_JSON_KEY, new String(messageBuffer));
			}
			sendResponseBack(jsonRespnse, context);
		}
	}

	private JsonObject handleIsoSampleFeedsResponse(byte[] messageBuffer, IEventContext context) {
		//get the node name
		final String nodeName = context.get(IConstants.EVENT_CTX_DESTINATION_NODE_NAME_KEY);
		// de-serialize buffer
		final IFlowInstance deserializeFlow = flowFactory
				.createInstance(AbstractIWorkflow.prepareMetaDataName(nodeName, IWorkflow.DESERIALIZE));
		final Map<String, Object> flowProps = new HashMap<>();
		flowProps.put(IConstants.FLOW_PROPS_MESSAGE_BUFFER_KEY, messageBuffer);
		flowProps.put(IConstants.FLOW_PROPS_NODE_NAME_KEY, nodeName);
		final CompletableFuture<IMessage> deserializedResult = deserializeFlow.process(flowProps);
		try {
			final IMessage deserializedBuffer = deserializedResult.get();
			_logger.debug("Deserializing message bytes completed.");
			return ((DefaultIMessage)deserializedBuffer).format();
		} catch (InterruptedException | ExecutionException e) {
			_logger.error("Error occured while processing the response data buffer for the sample message feed from host.", e);
			return new JsonObject();
		}
	}

	private void sendResponseBack(JsonObject jsonRespnse, IEventContext context) {
		IReplyEventContext replyContext = (context instanceof IReplyEventContext)?(IReplyEventContext)context:null;
		if(replyContext != null && replyContext.getOriginalContext() != null){
			IEventContext originalContext = replyContext.getOriginalContext();
			Message<JsonObject> eventBusMessage = originalContext.get(IConstants.SERVER_MSG_PROTOCOL_CTX);
			if(eventBusMessage == null){
				_logger.error("No response router found in the event context. Please check with logs for any error.");
				return;
			}
			_logger.debug("building JSON response...");
			final JsonObject finalResponse = buildFinalJsonResponse(jsonRespnse, context);
			_logger.debug("sending response back...");
			Buffer responseBuffer = finalResponse.toBuffer();
			_logger.debug("JSON Formatted Buffer: {}", responseBuffer);
			eventBusMessage.reply(new JsonObject(responseBuffer));
		} else {
			_logger.error("Problem with the event context. It should be of reply context.");
			return;
		}
	}

	private JsonObject buildFinalJsonResponse(JsonObject jsonRespnse, IEventContext context) {
		final JsonObject finalResponse = new JsonObject();
		finalResponse.put("nodeName", (String)context.get(IConstants.EVENT_CTX_DESTINATION_NODE_NAME_KEY));
		finalResponse.put("messageName", (String)context.get(IConstants.EVENT_CTX_MESSAGE_NAME));
		finalResponse.put("request", false);
		finalResponse.put("format", ((NodeFormat)context.get(IConstants.EVENT_CTX_NODE_FORMAT)).name());
		if(jsonRespnse.containsKey(MESSAGE_BODY_SAMPLE_FEED_JSON_KEY))
			finalResponse.put("messageBody", (String)jsonRespnse.getValue(MESSAGE_BODY_SAMPLE_FEED_JSON_KEY));
		else
			finalResponse.put("messageBody", jsonRespnse);
		return finalResponse;
	}

	private void handleRequest(IEventContext context, IEventMessage eventMessage) {
		JsonObject jsonDataObject = context.get(JSON_REQ_BUFFER_CTX_PARAM_KEY);
		try{
			//get the node name
			final String nodeName = jsonDataObject.getString(NODE_NAME_SAMPLE_FEED_JSON_KEY);
			//get the message name
			final String messageName = jsonDataObject.getString(MESSAGE_NAME_SAMPLE_FEED_JSON_KEY);
			//get the message type Request/Response
			boolean request = jsonDataObject.getBoolean(MESSAGE_TYPE_SAMPLE_FEED_JSON_KEY);
			//get the node format
			NodeFormat format = NodeFormat.valueOf(jsonDataObject.getString(NODE_FORMAT_SAMPLE_FEED_JSON_KEY));
			byte[] dataBytes;
			if(NodeFormat.ISO87.equals(format) || NodeFormat.ISO93.equals(format)){
				dataBytes = handleIsoSampleFeeds(nodeName, messageName, request, jsonDataObject);
			} else {
				dataBytes = handleNonIsoSampleFeeds(jsonDataObject);
			}
			sendReceiveSampleFeed(dataBytes, eventMessage, nodeName, messageName, request, format);
			
		} catch(Exception e){
			_logger.error("Error occured while processing the data buffer for the sample message feed.", e);
		}
	}

	private byte[] handleNonIsoSampleFeeds(JsonObject jsonDataObject) {
		final String messageBodyPayload = jsonDataObject.getString(MESSAGE_REQUEST_SAMPLE_FEED_JSON_KEY);
		return messageBodyPayload.getBytes();
	}

	private byte[] handleIsoSampleFeeds(String nodeName, String messageName, boolean request,
			JsonObject jsonDataObject) {
		// convert the JSON message body to IMessage for serialization
		final INodeMetaData nodeMetaData = new NodeMetaData(nodeName);
		final IMessageMetaData metaData = new IMessageMetaDataImpl(messageName, request);
		final DefaultIMessage message = new DefaultIMessage(nodeMetaData);
		message.setMetaData(metaData);	
		message.build(jsonDataObject.getJsonObject(MESSAGE_BODY_SAMPLE_FEED_JSON_KEY));		
		// serialize buffer
		final Map<String, Object> flowProps = new HashMap<>();
		flowProps.put(IConstants.FLOW_PROPS_TRANSFORMED_REQUEST_KEY, message);
		flowProps.put(IConstants.FLOW_PROPS_NODE_NAME_KEY, nodeName);
		final IFlowInstance serializeFlow = flowFactory
				.createInstance(AbstractIWorkflow.prepareMetaDataName(nodeName, IWorkflow.SERIALIZE));
		final CompletableFuture<byte[]> serializedResult = serializeFlow.process(flowProps);
		try {
			byte[] serializedBuffer = serializedResult.get();
			_logger.debug("Serializing to message bytes completed at virtualizer.");
			return serializedBuffer;
		} catch (InterruptedException | ExecutionException e) {
			_logger.error("Error occured while building sample message bytes.", e);
			return null;
		}
	}

	private void sendReceiveSampleFeed(final byte[] messageBuffer, IEventMessage originalEventMessage,
			String nodeName, String messageName, boolean request, NodeFormat format) {
		if(messageBuffer == null){
			_logger.error("Message buffer is empty or null. Please check with the logs for any error.");
			return;
		}
		EventContext hostCommunicationContext = new EventContext();
		hostCommunicationContext.set(ORI_REQUEST_CTX_KEY, originalEventMessage);
		hostCommunicationContext.set(IConstants.EVENT_CTX_DESTINATION_NODE_NAME_KEY, nodeName);
		hostCommunicationContext.set(IConstants.EVENT_CTX_MESSAGE_NAME, messageName);
		hostCommunicationContext.set(IConstants.EVENT_CTX_MESSAGE_TYPE_REQUEST, request);
		hostCommunicationContext.set(IConstants.EVENT_CTX_NODE_FORMAT, format);
		hostCommunicationContext.set(MapperHostCommunicationEventHandler.SERIALIZED_BUFFER, messageBuffer);
		virtualHostCommunicationEventPublisher.publish(MapperHostCommunicationEventHandler.SEND_RECEIVE_EVT_DATA,
				hostCommunicationContext);
	}
	
}

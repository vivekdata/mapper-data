package com.opusconsulting.pegasus.virtualization.event.handlers;

import com.opusconsulting.pegasus.common.event.*;
import com.opusconsulting.pegasus.event.impl.EventContext;
import com.opusconsulting.pegasus.flow.IFlowInstance;
import com.opusconsulting.pegasus.flow.impl.FlowFactory;
import com.opusconsulting.pegasus.flow.impl.FlowMetaDataFactory;
import com.opusconsulting.pegasus.runtime.IConstants;
import com.opusconsulting.pegasus.runtime.flow.AbstractIWorkflow;
import com.opusconsulting.pegasus.runtime.flow.IWorkflow;
import com.opusconsulting.pegasus.runtime.flows.EnvStartUpFlow;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@Component
public class VirtualizationStartupActivityEventHandler implements IEventHandler {

	@Inject
	FlowMetaDataFactory flowMetaDataFactory;
	
	@Inject
	FlowFactory flowFactory;
	
	@Inject
	List<AbstractIWorkflow> workflows;
	
	@Inject
	@Lazy
	IEventPublisher startVirtualServerEventPublisher;
	
	@PostConstruct
	public void init(){
		//initialize Environment start up flow only
		if (workflows != null) {
			workflows.stream().filter((workflow) -> {
				return workflow instanceof EnvStartUpFlow;
			}).forEach((workflow) -> {
				workflow.registerToFactory(null);
			});
		}
		flowFactory.init();
	}
	
	private static final Logger _logger = LoggerFactory.getLogger(VirtualizationStartupActivityEventHandler.class);
	
	@Override
	public void handle(IEventMessage eventMessage, IEventContext context) {
		if(eventMessage.isReply()){
			if("PROCESS_READ_DATA".equalsIgnoreCase(eventMessage.getData())){
				boolean success = processEventReply(eventMessage, context);
				if(success){
					//TODO may pass end-point details from context
					EventContext serverStartContext = new EventContext();
					serverStartContext.set(ORI_REQUEST_CTX_KEY, eventMessage);
					startVirtualServerEventPublisher.publish("START", serverStartContext);
				} else{
					System.exit(0);
				}
			} else if("SERVER_STARTED".equalsIgnoreCase(eventMessage.getData())){
				System.out.println("----------- Server started successfully ------------------");
				EventContext sampleServerStartContext = new EventContext();
				sampleServerStartContext.set(ORI_REQUEST_CTX_KEY, eventMessage);
				startVirtualServerEventPublisher.publish("START_VIRTUALIZER_TO_RECEIVE_SAMPLE_FEED", sampleServerStartContext);
			} else if("SERVER_STARTED_FAILED".equalsIgnoreCase(eventMessage.getData())){
				//TODO some clean up activity if any.
			}
		} else {
			processEventMessage(eventMessage, context);
		}
	}

	private boolean processEventReply(IEventMessage eventMessage, IEventContext context) {
		if(ReplyType.Failure.equals(eventMessage.getReplyType())){
			return false;
		}
		// TODO take the pojo values from reply context and prepare the virtualization flow instance
		final Map<String, Object> workflowData = new HashMap<>();
		workflowData.put(IConstants.NODE_DETAILS_CONFIGS, context.get(IConstants.NODE_DETAILS_CONFIGS));
		workflowData.put(IConstants.VIRTUALIZATION_DETAILS, context.get(IConstants.VIRTUALIZATION_DETAILS));
		//initialize TreeRuleExecutionFlow only
		if (workflows != null) {
			workflows.stream().filter((workflow) -> {
//				return workflow instanceof TreeRuleExecutionFlow;
				return !(workflow instanceof EnvStartUpFlow);
			}).forEach((workflow) -> {
				workflow.registerToFactory(workflowData);
			});
		}
		flowFactory.init();
		return true;
	}

	private void processEventMessage(IEventMessage eventMessage, IEventContext context) {
		// TODO prepare Startup flow instance and start the flow
		if("BOOT".equalsIgnoreCase(eventMessage.getData())){
			try {
				final Map<String, Object> flowResultValue = executeStartupflow(context);
				if(flowResultValue == null){
					eventMessage.reply("FAILED_TO_READ", false);
				} else {
					IEventContext replyContext = new EventContext();
					flowResultValue.entrySet().forEach((entry) -> {
						replyContext.set(entry.getKey(), entry.getValue());
					});
					eventMessage.reply("PROCESS_READ_DATA", true, replyContext);
				}
			} catch (InterruptedException e) {
				_logger.error("Interruption occured while executing virtualization server startup flow", e);
				eventMessage.reply("Failed", false);
			} catch (ExecutionException e) {
				_logger.error("Error while executing virtualization server startup flow", e);
				eventMessage.reply("Failed", false);
			}
		}
	}

	private Map<String, Object> executeStartupflow(IEventContext context) throws InterruptedException, ExecutionException {
		IFlowInstance startUpFlowInstance = flowFactory.createInstance(AbstractIWorkflow.prepareMetaDataName("", IWorkflow.STARTUP));
		
		final Map<String, Object> startupProps = new HashMap<>();
		startupProps.put("nodeJSONFilePath", context.get("nodeJSONFilePath"));
		startupProps.put("workFlowJSONFilePath", context.get("workFlowJSONFilePath"));
		startupProps.put("virtulizationJSONFilePath", context.get("virtulizationJSONFilePath"));
		final CompletableFuture<Map<String, Object>> flowResult = startUpFlowInstance.process(startupProps);
		return flowResult.get();
	}
}
